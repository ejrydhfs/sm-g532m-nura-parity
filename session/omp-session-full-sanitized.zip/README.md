# Session archive

Generated 2026-10-26T04:58:24.867Z from session `01a16c5e-220c-73f9-92c9-04fda142dcdd`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

124 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. A live snapshot of running/recent jobs for Main, RemCamera, RemCcci, RemWcn, RemCamera.RemDphy, RemCamera.RemImgsys, RemCamera.RemIsp, RemCamera.RemOtp, RemWcn.FmI2s, RemWcn.WlanMac, RemWcn.FmI2sAudio, RemWcn.WmtPsm, RemCcci.CcciMpu, RemCcci.CcciDump, RemCcci.CcciDts, RemCcci.CcciRpc, RemInternals, RemInternals.Rem2Clkbuf, RemInternals.Rem2Cldma, RemInternals.Rem2Aee, RemInternals.Rem2Iopipe is also included. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (142)

- `AudioCoordinator` — 405 entries, 1192620 bytes
- `AudioCoordinator/AudioCoordinator.AudioAccdet` — 351 entries, 1370055 bytes
- `AudioCoordinator/AudioCoordinator.AudioAfe` — 506 entries, 1779350 bytes
- `AudioCoordinator/AudioCoordinator.AudioCodec` — 476 entries, 1403632 bytes
- `AudioCoordinator/AudioCoordinator.AudioJack` — 372 entries, 1387458 bytes
- `AudioGap` — 279 entries, 869846 bytes
- `AudioGap/AudioGap.GapClk` — 167 entries, 357521 bytes
- `AudioGap/AudioGap.GapExtAmp` — 345 entries, 688976 bytes
- `AudioGap/AudioGap.GapHpImp` — 369 entries, 1228984 bytes
- `AudioGap/AudioGap.GapSpkProt` — 392 entries, 1072975 bytes
- `AudioGap/AudioGap.GapVoice` — 288 entries, 1167533 bytes (killed)
- `AudioGapDS` — 108 entries, 512089 bytes
- `AudioGapDS/AudioGapDS.HpImpLeaf` — 273 entries, 1282536 bytes (killed)
- `AudioGapDS/AudioGapDS.VoiceLeaf` — 227 entries, 852296 bytes
- `AudioGapDS2` — 285 entries, 988631 bytes
- `Bma254Parity` — 302 entries, 1051036 bytes
- `Bma254ParityMimo` — 250 entries, 733784 bytes
- `CameraCoordinator` — 373 entries, 1192235 bytes
- `CameraCoordinator/CameraCoordinator.ImgsysDriver` — 234 entries, 661005 bytes
- `CameraCoordinator/CameraCoordinator.Imx219Driver` — 362 entries, 1043553 bytes
- `CameraCoordinator/CameraCoordinator.LensCalDriver` — 290 entries, 1077109 bytes
- `CameraCoordinator/CameraCoordinator.S5k5e3yxDriver` — 344 entries, 1014103 bytes
- `CameraCoordinator/CameraCoordinator.SeninfDriver` — 588 entries, 1264308 bytes
- `CameraGap` — 310 entries, 1187280 bytes
- `CameraGap/CameraGap.CameraDphy` — 234 entries, 831278 bytes (killed)
- `CameraGap/CameraGap.CameraImgsys` — 301 entries, 694753 bytes
- `CameraGap/CameraGap.CameraIsp` — 167 entries, 1652964 bytes (killed)
- `CameraGap/CameraGap.CameraOtp` — 232 entries, 896125 bytes (killed)
- `CameraGap/CameraGap.CameraUcam` — 239 entries, 879055 bytes (killed)
- `CameraGapDS` — 164 entries, 530979 bytes
- `CameraGapDS/CameraGapDS.IspPipeline` — 207 entries, 1241686 bytes
- `CameraGapDS/CameraGapDS.OtpLens` — 214 entries, 858219 bytes
- `CameraGapDS/CameraGapDS.SeninfDphy` — 174 entries, 729361 bytes
- `CameraGapDS/CameraGapDS.UserspaceCam` — 240 entries, 1032268 bytes
- `CameraGapDS2` — 100 entries, 447795 bytes
- `CameraGapDS2/CameraGapDS2.DphyLeaf` — 90 entries, 704467 bytes
- `CameraGapDS2/CameraGapDS2.IspLeaf` — 216 entries, 673726 bytes
- `CameraGapDS2/CameraGapDS2.OtpLeaf` — 184 entries, 862290 bytes
- `CameraGapDS2/CameraGapDS2.UapiLeaf` — 150 entries, 418544 bytes
- `CameraGapDS2/CameraGapDS2.UcamLeaf` — 194 entries, 646806 bytes
- `CcciCoordinator` — 387 entries, 1017029 bytes
- `CcciCoordinator/CcciCoordinator.C2kDual` — 372 entries, 1026466 bytes
- `CcciCoordinator/CcciCoordinator.CcciCldma` — 442 entries, 1552926 bytes
- `CcciCoordinator/CcciCoordinator.CcciCore` — 608 entries, 2411377 bytes
- `CcciCoordinator/CcciCoordinator.CcciUtil` — 513 entries, 2067347 bytes
- `CcciCoordinator/CcciCoordinator.CcmniNet` — 419 entries, 1326072 bytes
- `CcciGap` — 414 entries, 1092449 bytes
- `CcciGap/CcciGap.GapCldma` — 204 entries, 849281 bytes
- `CcciGap/CcciGap.GapClock` — 256 entries, 694471 bytes
- `CcciGap/CcciGap.GapDump` — 308 entries, 976978 bytes
- `CcciGap/CcciGap.GapMpu` — 289 entries, 689795 bytes
- `CcciGap/CcciGap.GapRpc` — 266 entries, 764046 bytes
- `CcciGapDS` — 168 entries, 732152 bytes
- `CcciGapDS/CcciGapDS.CcciGapCldma` — 170 entries, 807303 bytes
- `CcciGapDS/CcciGapDS.CcciGapClock` — 178 entries, 614737 bytes
- `CcciGapDS/CcciGapDS.CcciGapDump` — 228 entries, 683951 bytes
- `CcciGapDS/CcciGapDS.CcciGapMpu` — 208 entries, 737019 bytes
- `CcciGapDS/CcciGapDS.CcciGapRpc` — 179 entries, 629899 bytes
- `CcciGapDS2` — 82 entries, 352035 bytes
- `CcciGapDS2/CcciGapDS2.CcciCldma` — 228 entries, 636769 bytes
- `CcciGapDS2/CcciGapDS2.CcciDump` — 252 entries, 859771 bytes
- `CcciGapDS2/CcciGapDS2.CcciMpu` — 226 entries, 700190 bytes
- `CcciGapDS2/CcciGapDS2.CcciRpc` — 261 entries, 765535 bytes
- `DisplayParity` — 332 entries, 1148286 bytes
- `HapticsParity` — 229 entries, 783591 bytes
- `I2cFinal` — 8 entries, 16026 bytes
- `I2cParity` — 184 entries, 629183 bytes
- `IommuSmiFinal` — 8 entries, 15980 bytes
- `IommuSmiParity` — 278 entries, 709102 bytes
- `Mt6328Parity` — 484 entries, 1596015 bytes
- `Mt6328ParityMimo` — 406 entries, 958839 bytes
- `MtkSdFinal` — 8 entries, 15650 bytes
- `MtkSdParity` — 451 entries, 1265483 bytes
- `MtkSdParityMimo` — 235 entries, 715784 bytes
- `MusbPhyFinal` — 8 entries, 15642 bytes
- `MusbPhyParity` — 394 entries, 1267983 bytes
- `MusbPhyParityMimo` — 228 entries, 703688 bytes
- `PanfrostFinal` — 8 entries, 15912 bytes
- `PanfrostParity` — 252 entries, 688661 bytes
- `PinctrlParity` — 422 entries, 1112368 bytes
- `RemCamera` — 460 entries, 1448944 bytes
- `RemCamera/RemCamera.RemDphy` — 540 entries, 1878722 bytes
- `RemCamera/RemCamera.RemImgsys` — 553 entries, 1650796 bytes
- `RemCamera/RemCamera.RemIsp` — 600 entries, 2771117 bytes
- `RemCamera/RemCamera.RemOtp` — 551 entries, 1828285 bytes
- `RemCcci` — 360 entries, 965585 bytes
- `RemCcci/RemCcci.CcciDts` — 298 entries, 785222 bytes
- `RemCcci/RemCcci.CcciDump` — 597 entries, 1645198 bytes
- `RemCcci/RemCcci.CcciMpu` — 417 entries, 1386028 bytes
- `RemCcci/RemCcci.CcciRpc` — 470 entries, 1392603 bytes
- `RemInternals` — 641 entries, 1496109 bytes
- `RemInternals/RemInternals.Rem2Aee` — 530 entries, 1518805 bytes
- `RemInternals/RemInternals.Rem2Cldma` — 288 entries, 1000117 bytes
- `RemInternals/RemInternals.Rem2Clkbuf` — 329 entries, 1382148 bytes
- `RemInternals/RemInternals.Rem2Iopipe` — 454 entries, 1569309 bytes
- `RemWcn` — 510 entries, 1223798 bytes
- `RemWcn/RemWcn.FmI2s` — 398 entries, 1182973 bytes
- `RemWcn/RemWcn.FmI2sAudio` — 611 entries, 2234449 bytes
- `RemWcn/RemWcn.WlanMac` — 1098 entries, 4910395 bytes
- `RemWcn/RemWcn.WmtPsm` — 651 entries, 2355485 bytes
- `S2mu005Final` — 8 entries, 15803 bytes
- `S2mu005Parity` — 372 entries, 1095929 bytes
- `S2mu005ParityMimo` — 374 entries, 1200756 bytes
- `SocPowerFinal` — 8 entries, 16114 bytes
- `SocPowerParity` — 314 entries, 857577 bytes
- `ThermalWdtFinal` — 8 entries, 16115 bytes
- `ThermalWdtParity` — 269 entries, 748156 bytes
- `UartTimerFinal` — 8 entries, 15810 bytes
- `UartTimerParity` — 218 entries, 699354 bytes
- `VcodecCoordinator` — 412 entries, 1235400 bytes
- `VcodecCoordinator/VcodecCoordinator.VcodecCore` — 366 entries, 1067551 bytes
- `VcodecCoordinator/VcodecCoordinator.VcodecVdec` — 286 entries, 1054242 bytes
- `VcodecCoordinator/VcodecCoordinator.VcodecVenc` — 137 entries, 393124 bytes
- `VcodecGap` — 373 entries, 1122646 bytes
- `VcodecGap/VcodecGap.VcodecCmds` — 234 entries, 700601 bytes
- `VcodecGap/VcodecGap.VcodecCpuOpp` — 247 entries, 800716 bytes
- `VcodecGap/VcodecGap.VcodecDvfs` — 214 entries, 632219 bytes
- `VcodecGap/VcodecGap.VcodecHiber` — 190 entries, 583329 bytes
- `WcnCoordinator` — 461 entries, 1168856 bytes
- `WcnCoordinator/WcnCoordinator.WcnBt` — 573 entries, 1773145 bytes
- `WcnCoordinator/WcnCoordinator.WcnFm` — 545 entries, 1880171 bytes
- `WcnCoordinator/WcnCoordinator.WcnGps` — 246 entries, 770626 bytes
- `WcnCoordinator/WcnCoordinator.WcnWlan` — 482 entries, 1536150 bytes
- `WcnCoordinator/WcnCoordinator.WcnWmt` — 648 entries, 3257318 bytes
- `WcnGap` — 207 entries, 670759 bytes
- `WcnGap/WcnGap.FmI2s` — 379 entries, 1016401 bytes
- `WcnGap/WcnGap.FmRds` — 408 entries, 1279240 bytes
- `WcnGap/WcnGap.GpsChar` — 245 entries, 818242 bytes
- `WcnGap/WcnGap.WlanMac` — 411 entries, 1339934 bytes
- `WcnGap/WcnGap.WmtGap` — 416 entries, 1969807 bytes
- `WcnGapDS` — 130 entries, 430955 bytes
- `WcnGapDS/WcnGapDS.FmI2sGap` — 239 entries, 733129 bytes
- `WcnGapDS/WcnGapDS.GpsRdsReview` — 196 entries, 807057 bytes
- `WcnGapDS/WcnGapDS.WlanGap` — 292 entries, 1259302 bytes
- `WcnGapDS/WcnGapDS.WmtGap` — 272 entries, 748784 bytes
- `WcnGapDS2` — 171 entries, 537157 bytes
- `WcnGapDS2/WcnGapDS2.FmI2sLeaf` — 174 entries, 719557 bytes
- `WcnGapDS2/WcnGapDS2.WlanMacLeaf` — 171 entries, 727548 bytes
- `WcnGapDS2/WcnGapDS2.WmtGapLeaf` — 217 entries, 777450 bytes
- `ZinitixFinal` — 8 entries, 15895 bytes
- `ZinitixParity` — 408 entries, 1241232 bytes
- `ZinitixParityMimo` — 283 entries, 909283 bytes

## Totals

534 files, 377844672 bytes.
