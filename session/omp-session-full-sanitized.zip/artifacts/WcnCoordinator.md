{
  "subsystem": "wcn",
  "status": "complete",
  "series": {
    "consolidated_patch": "$M/patches/wcn-subsystem.patch (15592 insertions, 52 files, no binary hunks)",
    "applies_to": "$M/src/nura-linux HEAD 046883c0c (verified pristine)",
    "scaffold": "$M/patches/wcn-base.patch",
    "per_leaf": [
      "$M/patches/wcn-wmt.patch",
      "$M/patches/wcn-wlan.patch",
      "$M/patches/wcn-bt.patch",
      "$M/patches/wcn-gps.patch",
      "$M/patches/wcn-fm.patch"
    ]
  },
  "leaves": [
    {
      "driver": "WMT/CONSYS core",
      "worktree": "$M/worktrees/wcn-wmt",
      "patch": "$M/patches/wcn-wmt.patch",
      "report": "$M/logs/wcn-wmt.md",
      "insertions": 6532,
      "objects": 13,
      "compile": "clean, 0 warnings, LD [M] mtk_wcn_wmt.o"
    },
    {
      "driver": "WLAN (AHB HIF + firmware bring-up)",
      "worktree": "$M/worktrees/wcn-wlan",
      "patch": "$M/patches/wcn-wlan.patch",
      "report": "$M/logs/wcn-wlan.md",
      "insertions": 1809,
      "objects": 3,
      "compile": "clean, 0 warnings"
    },
    {
      "driver": "Bluetooth (BTIF + HCI over STP)",
      "worktree": "$M/worktrees/wcn-bt",
      "patch": "$M/patches/wcn-bt.patch",
      "report": "$M/logs/wcn-bt.md",
      "insertions": 2988,
      "objects": 4,
      "compile": "clean, W=1 clean"
    },
    {
      "driver": "GPS (GNSS over STP)",
      "worktree": "$M/worktrees/wcn-gps",
      "patch": "$M/patches/wcn-gps.patch",
      "report": "$M/logs/wcn-gps.md",
      "insertions": 505,
      "objects": 1,
      "compile": "clean, W=1 clean, checkpatch 0 errors"
    },
    {
      "driver": "FM (V4L2 radio + MT6627)",
      "worktree": "$M/worktrees/wcn-fm",
      "patch": "$M/patches/wcn-fm.patch",
      "report": "$M/logs/wcn-fm.md",
      "insertions": 3222,
      "objects": 3,
      "compile": "clean, 0 warnings, LD [M] mtk_wcn_fm.o"
    }
  ],
  "integration": {
    "worktree": "$M/worktrees/wcn-integration",
    "conflicts": "none - all five patches touch disjoint paths and applied on first attempt over the scaffold",
    "pristine_verify_worktree": "$M/worktrees/wcn-verify",
    "object_build": "24/24 subsystem objects from pristine HEAD + consolidated patch, 0 errors, 0 warnings ($M/logs/wcn-build-objects.log)",
    "module_links": "6 x LD [M]: mtk_btif, mtk_wcn_wmt, mtk_wcn_wlan, mtk_wcn_bt, mtk_wcn_gps, mtk_wcn_fm",
    "symbol_audit": "0 unresolved mtk_wcn_*/mtk_btif_* symbols across modules; 43 WMT/STP/CONSYS + 10 BTIF GPL exports; every frozen-header prototype implemented",
    "dts_validation": "canonical fragment built successfully into mt6737t-samsung-grandpplte.dtb (clean DTC); two corrections required vs leaf reports: use &{/soc} (mt6735.dtsi has no soc label) and 2-cell-address reg entries <0 ADDR 0 SIZE>"
  },
  "complete_vs_deferred": {
    "complete": "STP engine, WMT op/ctrl/function engines, CONSYS MT6735 power/clock/reset/EMI/chip-id, WMT patch download + /dev/stpwmt launcher ABI + /dev/wmtWifi, AHB/PDMA WLAN HIF + firmware download, BTIF controller (PIO+APDMA) + HCI-over-STP, GNSS-over-STP, V4L2 FM with MT6627 tune/RDS/patch download",
    "deferred": "WLAN 802.11 MAC/mgmt (gen2 nic/+mgmt/, ~130k lines; no cfg80211/netdev registered by design), WMT PSM power-save/coredump/coex/loopback, GPS vendor chardev ioctls, FM RDS group decoder (raw records delivered) and FM I2S/ASoC audio routing (no MT6735 codec driver)",
    "firmware_no_blobs_added": "userspace must supply WMT_SOC.cfg + ROMv2_lm_patch_* (WMT launcher), WIFI_RAM_CODE_6735 (WLAN), mt6627/mt6627_fm_v{1..5}_{patch,coeff}.bin (FM)",
    "hardware_unverified": "all power/reset timings, EMI remap, patch download on silicon, BTIF sustained load, GPS LNA pinctrl - full list in report §5"
  },
  "report": "$M/logs/wcn-coordinator.md",
  "config_fragment": "CONFIG_BT=m, CONFIG_GNSS=y, CONFIG_MEDIA_SUPPORT=y, CONFIG_MEDIA_RADIO_SUPPORT=y, CONFIG_VIDEO_DEV=y, CONFIG_MTK_BTIF=m, CONFIG_MTK_WCN_{WMT,WLAN,BT,GPS,FM}=m (nura.config not modified; RFKILL/CRC32 selected)",
  "checks_main_should_run": [
    "full arm64 build of the integrated series (resolves modpost/Module.symvers for the six modules)",
    "apply the DTS fragment from report §4 to the board DTS and build the dtb",
    "checkpatch gate on the applied series"
  ]
}