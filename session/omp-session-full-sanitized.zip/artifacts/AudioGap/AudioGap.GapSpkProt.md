{
  "task": "audio-gap-spkprot (speaker protection, SPKL IRQ, HP DC compensation)",
  "status": "complete",
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/audio-gap-spkprot.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/audio-gap-spkprot.md",
  "files_changed": [
    "sound/soc/codecs/mt6331.c",
    "sound/soc/codecs/mt6331.h",
    "drivers/mfd/mt6397-core.c",
    "include/linux/mfd/mt6397/core.h"
  ],
  "implemented": [
    "Class D/AB/receiver speaker sequences with vendor control Audio_Speaker_class_Switch (CALSSD/CLASSAB/RECEIVER) applied by Speaker Amp DAPM PRE_PMU/PRE_PMD; invalid mode -> -EINVAL",
    "Audio_Speaker_OC_Falg (SPK_CON6 bits 14/15 after TOP_CKPDN_CON2_CLR), Audio_Speaker_CurrentSensing (SPK_CON12 bit15, 0x9300/0x1300 mask 0xff00), Audio_Speaker_CurrentPeakDetector (SPK_CON12 bit14)",
    "Existing Speaker PGA Gain control kept by name but made software-backed like vendor Speaker_pga_gain so AB/receiver open/close no longer lose the user level",
    "SPKL_D/SPKL_AB IRQ resources 45/46 on the mt6328-codec MFD cell, optional threaded IRQs reading INT_STATUS2, logging, latching spk_d_oc/spk_ab_oc, W1C-clearing only own bit; missing/invalid resource does not fail probe",
    "HP DC compensation: HPL/HPR trim formula + ramp, EnableDcCompensation(true) at HP power-up, RestoreDcOffsetToZero (step 3) + disable at HP power-down, Audio HPL_SPK Offset / Audio HPR_SPK Offset controls with 1844..2252 validation",
    "MT6397_IRQ_NR raised 32 -> 48 (coordinator-approved cross-file prerequisite; no existing enumerator renumbered)"
  ],
  "build": {
    "command": "make ARCH=arm64 LLVM=1 -j2 sound/soc/codecs/mt6331.o drivers/mfd/mt6397-core.o drivers/mfd/mt6397-irq.o",
    "result": "exit 0, all three objects built (clean rebuild)",
    "config": "cp $M/nura.config .config; ./scripts/config --enable SOUND --module SND --module SND_SOC --module SND_SOC_MEDIATEK --module SND_SOC_MT6331; make ARCH=arm64 LLVM=1 olddefconfig"
  },
  "patch_verified": "git diff --binary | cmp to file OK; git apply --check -R OK; 4 files",
  "dts": "none required (IRQ comes from MFD cell; optional resources, no DT property)",
  "notes": [
    "IRQ domain size was the blocker: INT_STATUS2 hwirqs 45/46 exceeded MT6397_IRQ_NR=32, so mfd-core produced start=0 IRQs; fixed by the approved MT6397_IRQ_NR=48 change and documented as a dependency",
    "No automatic OC recovery invented (downstream only polls GetSpeakerOcFlag)",
    "Plain headphone Audio HPL/HPR Offset controls are out of this task's scope"
  ]
}