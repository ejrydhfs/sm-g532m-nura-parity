{
  "deliverables": {
    "patch": "$M/patches/audio-gap-extamp.patch",
    "report": "$M/logs/audio-gap-extamp.md"
  },
  "files_changed": [
    "sound/soc/codecs/mt6331.c (+148 lines; mt6331.h intentionally unchanged - the amp has no register interface in any available source)"
  ],
  "compile": {
    "cmd": "cp $M/nura.config .config; ./scripts/config --enable SOUND --module SND --module SND_SOC --module SND_SOC_MEDIATEK --module SND_SOC_MT6331; make ARCH=arm64 LLVM=1 olddefconfig; make ARCH=arm64 LLVM=1 -j2 sound/soc/codecs/mt6331.o",
    "result": "CC [M] sound/soc/codecs/mt6331.o - clean, no warnings"
  },
  "implementation": [
    "priv->ext_amp = devm_gpiod_get_optional(dev, \"ext-amp\", GPIOD_OUT_LOW) in platform probe; absent property => feature absent, probe still succeeds, control reports 0 and put(1) returns -ENODEV (no fake success)",
    "mt6331_ext_amp_enable(): gpiod=0, usleep_range(1000,20000), gpiod=1, msleep(25) - vendor:2206/2211/2225/2228",
    "mt6331_ext_amp_disable(): gpiod=0, udelay(500) - vendor:2252/2255 (all three delays are vendor values, outside the CONFIG_MTK_LEGACY ifdefs; none invented)",
    "New endpoint widget SND_SOC_DAPM_SPK(\"Ext Spk Amp\", mt6331_ext_amp_event) fed by \"Speaker Amp\"; POST_PMU => enable, PRE_PMD => disable",
    "Vendor control SOC_SINGLE_BOOL_EXT(\"Ext Speaker Amp\") - downstream really exposes \"Ext_Speaker_Amp_Switch\" (vendor:3165, get/set vendor:2365-2387); get reports the real pin level, set runs the same sequence"
  ],
  "key_decision": {
    "requested": "SND_SOC_DAPM_SUPPLY with PRE_PMU/POST_PMD",
    "delivered": "SND_SOC_DAPM_SPK with POST_PMU/PRE_PMD, plus a documented justification",
    "why": "dapm_up_seq places supply at 3 (before DAC=8 and out_drv=12) and dapm_down_seq at 14 (after out_drv=5) - soc-dapm.c:74-153 - which would assert the amp before the internal speaker amp and deassert it only after the internal amp is already off, i.e. the inverse of the required gating. snd_soc_dapm_spk is up_seq 13 / down_seq 4, so the pin goes high after the Speaker Amp out_drv group runs and low before it powers down. SND_SOC_DAPM_SUPPLY_S subseq cannot change the type slot (soc-dapm.c:1781-1804)."
  },
  "userspace_helper": "NOT required - proven DAPM path AIF_RX/AIF_RX2 -> DAC (PRE_PMU) -> Speaker Amp (PRE_PMU) -> Ext Spk Amp (POST_PMU, GPIO117 high); teardown reverse order. No tools/ helper added.",
  "dts_fragment": "In report under DTS-FRAGMENT: &pio extamp_default group (PINMUX_GPIO117__FUNC_GPIO117, bias-pull-up, output-low) + &mt6328 codec node with ext-amp-gpios = <&pio 117 GPIO_ACTIVE_HIGH>, pinctrl-0 = <&extamp_default>. No DTS file touched.",
  "unverified": [
    "[INFERENCE] shipped vendor build used the CONFIG_MTK_LEGACY mt_set_gpio path (ROM extamp pinctrl states are empty, rom_dtb_0.dts:2405-2413); both branches carry the same delays",
    "[INFERENCE] 'enable last, disable first' anti-pop order; downstream's ordering lives in the closed HAL (only call site of Ext_Speaker_Amp_Change is the userspace switch, vendor:3165)",
    "[INFERENCE] pull direction (vendor programs only pull-enable, vendor:2196); fragment uses bias-pull-up",
    "Vendor AW8736_MODE3/MODE4 2us toggle and the second ext-amp pin are not implemented: MODE_CTRL is undefined tree-wide so those macros were never compiled, and the board DT has no second extspkamp2-gpio (pin is NULL_PIN_DEFINITION)"
  ],
  "worktree_state": "Only sound/soc/codecs/mt6331.c modified on top of the staged baseline; no commits, no other worktrees touched",
  "suggested_main_checks": [
    "git apply --check the patch on a clean baseline worktree",
    "make ARCH=arm64 LLVM=1 sound/soc/codecs/mt6331.o",
    "when the board DT node lands, boot-test: cat /sys/kernel/debug/asoc/.../dapm/Ext%20Spk%20Amp power state during playback, and amixer cget 'name=Ext Speaker Amp'"
  ]
}