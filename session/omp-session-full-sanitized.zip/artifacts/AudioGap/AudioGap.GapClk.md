{
  "status": "complete",
  "files": [
    "include/dt-bindings/clock/mediatek,mt6735-audiosys.h (new)",
    "drivers/clk/mediatek/clk-mt6735-audiosys.c (new)",
    "drivers/clk/mediatek/Kconfig",
    "drivers/clk/mediatek/Makefile"
  ],
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/audio-gap-clk.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/audio-gap-clk.md",
  "summary": "Added mediatek,mt6735-audiosys gate provider (10 gates @0x0 bits 2,6,8,9,18,19,24,25,26,27) using mtk_clk_gate_ops_no_setclr (exact downstream CLK_GATE_NO_SETCLR_REG semantics) and CLK_IGNORE_UNUSED per downstream. Gate-only mtk_clk_simple_probe path maps via device_node_to_regmap/of_iomap, so it does not request_mem_region and coexists with the AFE's devm_platform_ioremap_resource on 0x11220000. Compile-tested clk-mt6735-audiosys.o and clk-mt6735-topckgen.o with 0 warnings. Patch verified with git apply --check against HEAD context (baseline patch does not touch drivers/clk). Matrix: 20/21 AFE clock-names resolvable in Nura; top_ad_apll1_clk unavailable (no Nura topckgen id/driver clock) and omitted from the DTS fragment.",
  "checks_for_main": [
    "make ARCH=arm64 LLVM=1 -j2 drivers/clk/mediatek/clk-mt6735-audiosys.o drivers/clk/mediatek/clk-mt6735-topckgen.o",
    "git apply --check patches/audio-gap-clk.patch on baseline tree"
  ]
}