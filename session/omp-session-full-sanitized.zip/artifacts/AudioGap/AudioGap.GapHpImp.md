{
  "task": "audio-gap-hpimp",
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/audio-gap-hpimp.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/audio-gap-hpimp.md",
  "files_changed": [
    "sound/soc/codecs/mt6331.c",
    "sound/soc/codecs/mt6331.h",
    "sound/soc/mediatek/mt6735/mt6735-afe-pcm.c",
    "sound/soc/mediatek/mt6735/mt6735-afe-regs.h"
  ],
  "compile": {
    "commands": "cp $M/nura.config .config; ./scripts/config --enable SOUND --enable SND --enable SND_SOC --enable SND_SOC_MEDIATEK --enable SND_SOC_MT6735 --enable SND_SOC_MT6331 --enable SND_SOC_MT6735_MT6331; make ARCH=arm64 LLVM=1 olddefconfig; make ARCH=arm64 LLVM=1 -j2 sound/soc/codecs/mt6331.o sound/soc/mediatek/mt6735/mt6735-afe-pcm.o",
    "result": "both objects CC, no warnings (clang 23.1.1, LLVM=1)"
  },
  "key_findings": {
    "efuse_hp_trim": "EFUSE_HP_TRIM is never defined (mt_soc_pcm_common.h:106 commented out; no -DEFUSE_HP_TRIM anywhere). Decoded 8 trim fields are read/stored/logged only; AUDDEC_ANA_CON2 is not programmed, matching downstream SetDcCompenSation()'s #ifndef branch.",
    "auxadc": "Channel 9 uses the same PMIC AUXADC block as baseline accdet (RQST0_SET 0x0e8a, CON0 0x0e94 bit15, CON12 0x0eb0 bit7, TOP_CLKSQ bit8, ADC9 0x0e12 ready bit15 / data [11:0]); ch9 returns raw 12-bit code (pmic_auxadc.c:434-436).",
    "sram": "AFE internal SRAM 0x11221000, 0x8000 bytes (AudDrv_Afe.h:375-377) at AFE ioremap base+0x1000; AFE control writes 16-bit words under runtime PM."
  },
  "deviations": [
    "Efuse read at component probe (logged once) and retried from first DL power-up instead of only first open (mt_soc_afe_control.c:468).",
    "Downstream unbounded OTP/AUXADC polls replaced by regmap_read_poll_timeout (1 ms x 20; timeout is a safety bound, [INFERENCE]).",
    "OpenHeadPhoneImpedanceSetting body is inside #if 0 downstream; the intended body is ported. GetDLStatus() guard omitted (no cross-component stream query) - userspace must not run during playback.",
    "Vendor 1 s settle, 5 s calibration wait, and the DC sweep/Calculate_HP_Impedance moved to userspace; kcontrol get returns last written value, not resistance.",
    "AFE SRAM fill implemented, but no PCM/memif is rebased onto the internal SRAM, so the DC level is not actually clocked to the codec - documented kernel-side parity gap."
  ],
  "dts_fragment": "none required",
  "checks_main_should_run": [
    "git apply --check of audio-gap-hpimp.patch on the baseline index/worktree",
    "spot-check ALSA control enumeration names: 'Audio HP ImpeDance Setting', 'Audio_HP_ImpeDance', 'Audio AUXADC Data', 'HP Impedance DC Value'"
  ]
}