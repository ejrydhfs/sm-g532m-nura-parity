{
  "subsystem": "audio",
  "status": "complete",
  "leaf_drivers": [
    {
      "name": "mt6735 AFE platform + DL1/DL2/VUL FE DAIs + I2S0 BE DAI",
      "worktree": "worktrees/audio-mt-soc",
      "patch": "patches/audio-mt-soc.patch",
      "report": "logs/audio-mt-soc.md"
    },
    {
      "name": "MT6331-named MT6328 PMIC audio codec (component, DAPM, controls, tx/tx2/rx DAIs, set_jack)",
      "worktree": "worktrees/audio-codec",
      "patch": "patches/audio-codec.patch",
      "report": "logs/audio-codec.md"
    },
    {
      "name": "MT6328 ACCDET (plug, cable type, mic ADC, buttons, notifier API)",
      "worktree": "worktrees/audio-accdet",
      "patch": "patches/audio-accdet.patch",
      "report": "logs/audio-accdet.md"
    },
    {
      "name": "MT6735 machine card + ASoC headset jack integration",
      "worktree": "worktrees/audio-jack",
      "patch": "patches/audio-jack.patch",
      "report": "logs/audio-jack.md"
    }
  ],
  "integration": {
    "worktree": "worktrees/audio-integration",
    "patch": "patches/audio-integration.patch",
    "files": 23,
    "insertions": 5677,
    "dts_changes": "none (fragment consolidated in coordinator report)",
    "conflicts_resolved": [
      "drivers/mfd/mt6397-core.c: kept both mt6328-codec and mt6328-accdet MFD cells",
      "sound/soc/mediatek/Kconfig: kept SND_SOC_MT6735 and SND_SOC_MT6735_MT6331",
      "sound/soc/mediatek/Makefile: single obj-$(CONFIG_SND_SOC_MT6735) += mt6735/",
      "sound/soc/mediatek/mt6735/Makefile: merged AFE objects + machine object"
    ],
    "coordinator_fixes": [
      "DL2 link moved to the second codec playback DAI mt-soc-codec-tx-dai2 (ROM MT_SOC_CODEC_TXDAI2_NAME) removing stream serialisation",
      "accdet.h switched from IS_ENABLED to IS_REACHABLE to avoid builtin-consumer/module-driver link failure",
      "SND_SOC_MT6735_MT6331 now depends on SND_SOC_MT6331 (depends, not select, because SND_SOC_MT6331 depends on MFD_MT6397)"
    ]
  },
  "compile": {
    "toolchain": "clang 23 (/usr/bin/clang) with $M/bin + $M/llvmpkg/usr/bin LLVM shims",
    "recipe": "cp $M/nura.config .config; scripts/config --enable SOUND --enable SND --module SND_SOC --module SND_SOC_MEDIATEK --module SND_SOC_MT6735 --module SND_SOC_MT6735_MT6331 --module SND_SOC_MT6331 --module MTK_ACCDET; make ARCH=arm64 LLVM=1 olddefconfig; make ARCH=arm64 LLVM=1 -j2 <objects>",
    "objects": [
      "sound/soc/mediatek/mt6735/mt6735-afe-pcm.o",
      "sound/soc/mediatek/mt6735/mt6735-afe-clk.o",
      "sound/soc/mediatek/mt6735/mt6735-dai-pcm.o",
      "sound/soc/mediatek/mt6735/mt6735-dai-i2s.o",
      "sound/soc/mediatek/mt6735/mt6735-mt6331.o",
      "sound/soc/codecs/mt6331.o",
      "drivers/misc/mediatek/accdet/accdet.o",
      "drivers/mfd/mt6397-core.o"
    ],
    "result": "PASS, exit 0, no warnings; directory-level build of sound/soc/mediatek/, sound/soc/codecs/, drivers/misc/mediatek/accdet/ also PASS",
    "caveat": "final .ko modpost needs vmlinux.o/Module.symvers from a full build; cross-module symbols verified statically with llvm-nm (accdet exports match machine undefined list, no duplicate definitions)"
  },
  "deferred": [
    "voice MD1/MD2 + BT, MRG, HDMI, FM, TDM, AWB, loopback, BT CVSD, offload/compress, HP impedance (need modem/BT/firmware peers)",
    "VOW, speaker protection/SPKL IRQ, OTP/efuse HP trim, DC compensation",
    "AFE internal-SRAM buffers, side tone, HW gain, ASRC, 2nd I2S",
    "/dev/accdet ioctls, Samsung jack sysfs, debugfs/proc HAL controls",
    "AP GPIO EINT plug path (MT6735 mtk_eint_hw has no db_time for the ROM 256 ms debounce); PMIC ACCDET comparator used instead",
    "external speaker amp (AW8736, GPIO117) board glue"
  ],
  "gaps": [
    "No mediatek,mt6735-audiosys clock provider in this kernel: 21 aud_* clocks fetched with devm_clk_bulk_get_optional(); bit clock/MCLK rates for I2S0 and the PMIC codec bus unproven - largest bring-up blocker",
    "No hardware validation: all sequences are downstream-cited or ROM-disassembly-confirmed, none silicon-verified",
    "Final module link/modpost requires a full kernel build",
    "Naming: driver is called mt6331 (ROM naming) but binds mediatek,mt6328-codec and implements only the MT6328 register map; mt6331.dtsi must not be wired to it"
  ]
}