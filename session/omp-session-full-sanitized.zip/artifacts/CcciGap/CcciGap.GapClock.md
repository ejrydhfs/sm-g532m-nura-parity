{
  "summary": "Closed both CCCI clock/power gaps in worktree ccci-gap-clock: (1) added MT6735_POWER_DOMAIN_MD2 (SPM_C2K_PWR_CON 0x2d4, PWR_STATUS_MD2 BIT(22), SRAM PDN bit 8, TOPAXI mask bits 29..31) to the MT6735 scpsys driver and made the C2K/MD3 driver hold it on with runtime PM while keeping the optional scp-sys-md2-main clock path; (2) taught ccci_boot_smem_setup() to split a single reserved-memory carve-out plus mediatek,md_smem_size into image/smem halves exactly like downstream (image = round_up(total - smem, 0x4000), smem at base + image), keeping the existing two-region and coherent-fallback paths. Six files changed, no DTS edits, no shared-header changes.",
  "files": [
    "drivers/pmdomain/mediatek/mtk-pm-domains.h",
    "drivers/pmdomain/mediatek/mt6735-pm-domains.h",
    "include/dt-bindings/power/mediatek,mt6735-power-controller.h",
    "include/linux/soc/mediatek/infracfg.h",
    "drivers/misc/mediatek/ccci_c2k/ccci_c2k_hw.c",
    "drivers/misc/mediatek/ccci/ccci_boot.c"
  ],
  "compile_rc": 0,
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/ccci-gap-clock.md — full parity matrix, ROM evidence (spm_mtcmos_ctrl_mdsys2 @0xc0353124 disassembly showing 0x2d4 / BIT22 / 0xE0000000, symbols spm_is_md2_sleep, md2_sys_*_op, get_md1_md3_resv_smem_info; strings mediatek,md_smem_size), downstream file:line citations, DTS-FRAGMENT for the MD2 domain + C2K power-domains + single carve-out, and hardware-unverified notes. Compile: make ARCH=arm64 LLVM=1 -j2 drivers/pmdomain/mediatek/mtk-pm-domains.o drivers/misc/mediatek/ccci/ccci_boot.o drivers/misc/mediatek/ccci_c2k/ccci_c2k_hw.o => exit 0, zero warnings (W=1 forced rebuild also clean for changed code; only pre-existing kernel-doc warnings at ccci_boot.c:680, untouched by this diff).",
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/ccci-gap-clock.patch (267 lines, 6 files, staged-not-committed; git apply --check -R passes)",
  "deferred": [
    "SCP_SYS_MD2 vendor clock gate itself has no mainline clock provider: modelled as the MD2 power domain, same substitution the tree already uses for SCP_SYS_MD1; optional clock property still honoured if a provider appears [INFERENCE]",
    "No hardware attached: MD2 power-up/readback and MD3 boot not exercised"
  ],
  "notes": "DT is required for the new domain: power-domain@MT6735_POWER_DOMAIN_MD2 under &spm with mediatek,infracfg, plus power-domains = <&spm MT6735_POWER_DOMAIN_MD2> on the C2K/MD3 node (exact text in report §8, not applied). No new cross-leaf interface; include/linux/ccci.h untouched."
}