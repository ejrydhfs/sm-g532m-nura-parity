{
  "leaf": "VDEC DVFS (ENABLE_MMDVFS_VDEC monitor) for MT6735 vcodec",
  "patch_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/vcodec-gap-dvfs.patch",
  "report_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/vcodec-gap-dvfs.md",
  "files_changed": [
    "drivers/misc/mediatek/vcodec/vcodec.h",
    "drivers/misc/mediatek/vcodec/vcodec-core.c",
    "drivers/misc/mediatek/vcodec/vcodec-vdec.c"
  ],
  "compile_result": "olddefconfig exit 0; mandated make of vcodec-core.o, vcodec-vdec.o, vcodec-venc.o exit 0 with no diagnostics; identical W=1 run exit 0 with 0 warnings; checkpatch --strict 0/0/0 on all three files.",
  "blocked_items": [
    "VCORE/SMI bandwidth vote (downstream mmdvfs_set_step(SMI_BWC_SCEN_VP, level), D1:139/143; ROM mmdvfs_set_step @ 0xc04cacdc called from SendDvfsRequest @ 0xc039628c/0xc0396368) is not implementable: Nura contains no MMDVFS/vcorefs/SMI-BWC framework (greps in report §2.4; downstream entry points mmdvfs_mgr.c:233-302 -> vcorefs_request_dvfs_opp(KIR_MM, OPPI_PERF)). Clock half only."
  ],
  "notes": "Implemented: clk_set_parent on TOP_VDEC_SEL with DT parent handles (vdec_sel/vdec_sel_high=vdec_sel parent 1 syspll1_d2 273MHz/vdec_sel_low=parent 3 syspll1_d4 136.5MHz), wrapped in clk_prepare_enable/clk_disable_unprepare exactly as D1:127-153 and ROM SendDvfsRequest @ 0xc0396240; optional devm_clk_get_optional with single dev_info and boot-parent fallback. VDEC power_on clock set switched from devm_clk_bulk_get_all to explicit devm_clk_bulk_get(smi_common, vdec, smi_larb1). Full D1 monitor state machine (4000ms/50%/90%/1ms overhead, ktime_get) behind a private mutex; new optional dvfs_begin/dvfs_monitor_start/dvfs_adjustment/dvfs_idle ops invoked from core at INC_DEC_EMI_USER (native+compat), post-LOCKHW, post-UNLOCKHW power-off, and last close; eng->lock held, no re-lock, JPEG early-return/secure path/owner-publish order untouched; VENC ops NULL and vcodec-venc.c untouched. VENC DVFS proven non-applicable (0 VencDvfs symbols/strings; no encoder DVFS in D1). Pre-existing Nura topckgen rate model reports 2x vendor rates for syspll1_d2/d4 while mux positions are correct - documented as a shared-clock follow-up, no clk_get_rate use. Report §6 carries the updated vdec DTS fragment with the three extra clocks and clock-names; shared DTS unedited. git status shows only the three intended files modified on top of the staged baseline; patch regenerated (545 lines, +385/-23)."
}