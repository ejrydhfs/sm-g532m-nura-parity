{
  "blocked_items": [],
  "compile_result": "PASS (final, after third review fix): CPU_FREQ=y W=1 vcodec-core.o + vcodec-vdec.o + vcodec-venc.o exit 0, 0 warnings; CPU_FREQ=n W=1 vcodec-core.o exit 0 with no freq_qos_*/cpufreq_cpu_* undefined refs; vcodec-mt6735.o LD [M] exit 0; checkpatch --strict 0 errors/0 warnings/0 checks (1412 lines); .config restored to CPU_FREQ=y.",
  "files_changed": [
    "drivers/misc/mediatek/vcodec/vcodec-core.c"
  ],
  "leaf": "VcodecGap.VcodecCpuOpp",
  "notes": "VCODEC_SET_CPU_OPP_LIMIT in vcodec-core.c only. Final mask handling: u32 mask from the 32-bit ABI field, skip cpu>=32 for nonzero masks (no UB with NR_CPUS>64), negative limited_cpu -> -EINVAL. Prior corrections retained: re-enable releases every active policy not visited by the call (per-slot visited flag, mask 0 = all); per-policy FREQ_QOS_MAX add/update on policy->constraints; FREQ_QOS_MAX_DEFAULT_VALUE + remove + cpufreq_cpu_put on disable/release; mutex-serialized NR_CPUS-bounded table; release at last close and module exit; -EOPNOTSUPP with CPU_FREQ=n; native + compat dispatch; removed from vcodec_unsupported_cmds. Evidence: downstream D1:1533-1555 commented-out cpu_opp_limit(), 0 hits in ROM symbols.txt, ROM strings 27338-27342. Report §6 DTS-FRAGMENT: none.",
  "patch_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/vcodec-gap-cpuopp.patch",
  "report_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/vcodec-gap-cpuopp.md"
}