{
  "leaf": "vcodec hibernation IRQ re-sensitization (vcodec_pm_restore_noirq parity)",
  "patch_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/vcodec-gap-hibernation.patch",
  "report_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/vcodec-gap-hibernation.md",
  "files_changed": [
    "drivers/misc/mediatek/vcodec/vcodec-vdec.c",
    "drivers/misc/mediatek/vcodec/vcodec-venc.c"
  ],
  "compile_result": "exit 0; vcodec-core.o, vcodec-vdec.o, vcodec-venc.o all CC'd; 0 warnings with default and with W=1",
  "blocked_items": [],
  "notes": "Both engine platform_drivers now register a dev_pm_ops .restore_noirq callback that calls irq_set_irq_type(irq, IRQ_TYPE_LEVEL_LOW) and returns 0, logging failures via dev_err, matching ROM vcodec_pm_restore_noirq @0xc0396198 (mt_irq_set_sens(...,1)+mt_irq_set_polarity(...,0) for both IRQs) and D1:2376-2386 / registration D1:2547. No mask-state change: verified irq disable depth survives hibernation restore (desc/depth are part of the restored image; suspend_device_irqs in kernel/irq/pm.c:94-96/126-141, __disable_irq manage.c:675-679, resume_device_irqs pm.c:246-249 -> resume_irq pm.c:144-172 -> __enable_irq manage.c:769-799), so no local bool added. Callback context verified: process context via hibernation_snapshot hibernate.c:482 PMSG_RESTORE -> dpm_resume -> dpm_resume_noirq, dpm_list_mtx dropped, device IRQs still suspended because resume_device_irqs() runs after all restore_noirq callbacks (drivers/base/power/main.c:449-450, 727-800, 825-884). irq_set_irq_type is non-sleeping here because the IRQ is routed through mediatek,mt6735-sysirq (mt6735.dtsi:30, irq-mtk-sysirq.c:26-69: no bus_lock, raw spinlock + MMIO), and it programs INTPOL low exactly like MT_LEVEL_SENSITIVE+MT_POLARITY_LOW; a direct-GIC SPI would return -EINVAL (irq-gic.c:301-304) and is logged. Callbacks use pm_sleep_ptr + __maybe_unused so the module builds with CONFIG_PM_SLEEP=n. Report §6 says DTS-FRAGMENT: none; git diff touches only the two engine files (79 insertions)."
}