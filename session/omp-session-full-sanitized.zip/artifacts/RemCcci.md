{
  "area": "ccci",
  "status": "partial",
  "summary": "Four remaining CCCI leaves delivered and integrated on top of the pre-delivered cldma/clock gap patches; the merged subsystem compiles, links into vmlinux, and the new userspace dump tool builds and self-checks. MPU/security and carve-out/DTS recovery are closed; RPC and AEE/DHL are partial only where external providers or frozen-API changes are required, with exact missing inputs documented.",
  "leaves": [
    {
      "leaf": "mpu",
      "worktree": "worktrees/rem-ccci-mpu",
      "status": "done",
      "patch": "patches/rem-ccci-mpu.patch",
      "report": "logs/rem-ccci-mpu.md",
      "diffstat": "6 files, +1024/-10",
      "notes": "EMI MPU via ATF SMC 0x82000209 (downstream mt_secure_api.h:38, ROM mt_secure_call @0xc064c6f8), full MT6735 region/permission table, RMPU BANK0/BANK4 0x300..0x31c, DSP region from check-header v3, AP re-protection, ccci_init_security; ccci_md_set_dsp_mpu_protection() implemented (0-based md->id)."
    },
    {
      "leaf": "rpc",
      "worktree": "worktrees/rem-ccci-rpc",
      "status": "partial",
      "patch": "patches/rem-ccci-rpc.patch",
      "report": "logs/rem-ccci-rpc.md",
      "diffstat": "5 files, +1639/-6",
      "notes": "Wire format/response framing/RX demux/registration API and services 0x2002,0x4001-0x4006,0x4009-GPIO,0x400a-0x400c,0x4321 done; 0x400b calls the MPU leaf; time verified in boot. Deferred: 0x2001 (MASP/HACC absent), 0x4007/0x4009 ADC raw (no RAW IIO channel + EFUSE cali source), 0x4008 count==4 (clk-buf driver absent)."
    },
    {
      "leaf": "dump",
      "worktree": "worktrees/rem-ccci-dump",
      "status": "partial",
      "patch": "patches/rem-ccci-dump.patch",
      "report": "logs/rem-ccci-dump.md",
      "diffstat": "13 files, +2295/-22",
      "notes": "Exception record decode, AEE ABI aee_dump_ccci_debug_info (1-based, ROM 0xc0508b54), packet capture, stages EX_INIT/EX_DHL_DL_RDY/CLEARQ_DONE(2s flush)/ALLQ_RESET/MD_WDT/MD_NO_RESPONSE, DHL META gate, SBP cfg, debugfs + /dev/ccci_dump; userspace tools/mediatek/ccci/ccci-dump builds and make check passes. Deferred: DHL RX-alive window needs frozen cldma_stop_for_ee API, AEE DB client absent, legacy SBP WM_ID load-type data absent."
    },
    {
      "leaf": "dts",
      "worktree": "worktrees/rem-ccci-dts",
      "status": "done",
      "patch": "patches/rem-ccci-dts.patch",
      "report": "logs/rem-ccci-dts.md",
      "diffstat": "1 file, +21/-0",
      "notes": "Reg-less reserved-memory carve-out resolution via of_reserved_mem_region_to_resource(); exact fragments (MD1 carve-out 0x3830000/0x2000000/0x40000000..0xC0000000 + smem 0x30000, mdcldma node, EINT nodes) validated with dtc. MD3 and MD1<->MD3 carve-out sizes absent from every source (documented)."
    }
  ],
  "integration": {
    "worktree": "worktrees/ccci-gap-integration",
    "head": "e640c6687",
    "patch": "patches/rem-ccci-integration.patch",
    "patch_diffstat": "26 files, +5432/-93",
    "full_patch": "patches/rem-ccci-integration-full.patch",
    "full_patch_diffstat": "27 files, +5541/-93",
    "applies": {
      "leaf_combined_on_scaffold": true,
      "full_on_integration_baseline": true,
      "each_leaf_standalone_on_scaffold": true
    },
    "conflict_resolutions": [
      "ccci_priv.h: kept both ccci_exception.h and ccci_mpu.h includes and both struct field blocks",
      "ccci/Makefile: one object list with mpu/rpc/exception entries",
      "ccci_core.c: merged init/exit ordering; RPC RX has exactly one owner",
      "ccci_boot.c: reserved-mem helper + clock carve-out split + MPU translations + DSP slot + dump SBP layers all retained"
    ],
    "dts_edits": "none (fragments returned in coordinator report section 7)"
  },
  "build": {
    "config": "nura.config + scripts/config -e MTK_CCCI -e MTK_CCMNI -e MTK_CCCI_C2K -e MTK_CCCI_UTIL -e MTK_CCCI_CLDMA + olddefconfig (all =y)",
    "objects": "drivers/misc/mediatek/ccci/built-in.a rc=0, 12 members, only pre-existing ccci_ringbuf.c:209 warning",
    "userspace": "make -C tools/mediatek/ccci rc=0; make check rc=0",
    "vmlinux": "make ARCH=arm64 LLVM=1 -j8 vmlinux rc=0 in 688s, 0 errors; vmlinux 250598016 bytes",
    "symbols_linked_once": [
      "ccci_md_set_dsp_mpu_protection",
      "ccci_rpc_handle",
      "ccci_rpc_register_service",
      "aee_dump_ccci_debug_info",
      "ccci_exception_trigger",
      "ccci_cldma_set_exception_mode",
      "ccci_cldma_hw_reset",
      "ccci_mpu_set_mem_remap",
      "ccci_init_security"
    ],
    "logs": [
      "logs/rem-ccci-integration_olddefconfig.log",
      "logs/rem-ccci-integration_objects.log",
      "logs/rem-ccci-integration_build.log",
      "logs/rem-ccci-rpc_build.log"
    ]
  },
  "remaining_gaps": [
    "MASP/asfv2 HACC driver + key material for RPC 0x2001",
    "RAW auxadc provider: mediatek,mt6735-auxadc compatible + IIO_CHAN_INFO_RAW in mt6577_auxadc.c, and ADC_CALI_EN_A_REG (EFUSEC_BASE+0x548) offset source for MT6735, for RPC 0x4007/0x4009",
    "MTK clk-buffer driver (clk_buf_get_swctrl_status) for RPC 0x4008 count==4",
    "frozen-API addition void ccci_cldma_stop_for_ee(struct ccci_cldma *cd, u16 stop_mask) with NONSTOP_QUEUE_MASK 0xF0 for the DHL RX-alive window (proposal in logs/rem-ccci-dump.md section 7)",
    "AEE/aed client aed_md_exception_api (ROM 0xc0628298) absent from tree",
    "modem load-type source for legacy SBP WM_ID (feature_4_val[1])",
    "MD3 (mediatek,reserve-memory-ccci_md3_ccif) and MD1<->MD3 (mediatek,reserve-memory-ccci_share) carve-out sizes absent from downstream DTS and ROM DTB",
    "mediatek,infracfg-ao DT property must be applied for RMPU and CLDMA reset"
  ],
  "deliverables": [
    "patches/rem-ccci-mpu.patch",
    "patches/rem-ccci-rpc.patch",
    "patches/rem-ccci-dump.patch",
    "patches/rem-ccci-dts.patch",
    "patches/rem-ccci-integration.patch",
    "patches/rem-ccci-integration-full.patch",
    "logs/rem-ccci-mpu.md",
    "logs/rem-ccci-rpc.md",
    "logs/rem-ccci-dump.md",
    "logs/rem-ccci-dts.md",
    "logs/rem-ccci-coordinator.md"
  ],
  "notes": [
    "Contract-name aliases ccci-gap-{mpu,rpc,dump,dts}.{patch,md} are symlinks to the rem-ccci deliverables.",
    "Integration worktree left dirty and uncommitted; leaf worktrees left dirty at 509789971.",
    "No device attached: all register writes, IRQs and timings are source-derived and documented as hardware-unverified."
  ]
}