{
  "subsystem": "vcodec (MT6735 VENC + VDEC + shared hardware-service core)",
  "status": "complete",
  "leaves": [
    {
      "driver": "shared core",
      "worker": "VcodecCore",
      "worktree": "$M/worktrees/vcodec-core",
      "files": [
        "drivers/misc/mediatek/vcodec/vcodec-core.c",
        "include/uapi/linux/vcodec.h",
        "Documentation/devicetree/bindings/media/mediatek,mt6735-vcodec.yaml",
        "drivers/misc/mediatek/vcodec/{Kconfig,Makefile}",
        "drivers/misc/mediatek/{Kconfig,Makefile}",
        "drivers/misc/{Kconfig,Makefile} edits"
      ],
      "patch": "$M/patches/vcodec-core.patch",
      "report": "$M/logs/vcodec-core.md"
    },
    {
      "driver": "VDEC",
      "worker": "VcodecVdec",
      "worktree": "$M/worktrees/vcodec-vdec",
      "files": [
        "drivers/misc/mediatek/vcodec/vcodec-vdec.c"
      ],
      "patch": "$M/patches/vcodec-vdec.patch",
      "report": "$M/logs/vcodec-vdec.md"
    },
    {
      "driver": "VENC",
      "worker": "VcodecVenc",
      "worktree": "$M/worktrees/vcodec-venc",
      "files": [
        "drivers/misc/mediatek/vcodec/vcodec-venc.c"
      ],
      "patch": "$M/patches/vcodec-venc.patch",
      "report": "$M/logs/vcodec-venc.md"
    }
  ],
  "integration": {
    "worktree": "$M/worktrees/vcodec-integration",
    "patch": "$M/patches/vcodec-integration.patch",
    "combined_stat": "12 files changed, 2380 insertions",
    "conflicts": "none (all three patches git apply --check clean; combined series applies cleanly to pristine nura-linux HEAD 046883c0c)",
    "shared_dts_modified": false,
    "dts_fragment": "vdec@16020000 (reg vdec+gcon, IRQ SPI 179 level-low, clocks mmsys SMI_COMMON + vdecsys VDEC + SMI_LARB1 + topckgen VDEC_SEL, power-domains DIS+VDE, reset VDEC) and venc@17002000 (IRQ SPI 180, clocks mmsys SMI_COMMON + vencsys VENC + SMI_LARB3, power-domains DIS+VEN); mt6735.dtsi must add #include <dt-bindings/reset/mediatek,mt6735-vdecsys.h>; /dev/Vcodec needs a udev/ueventd rule (mode 0660, group media/video)."
  },
  "compile_results": {
    "leaf_objects": "vcodec-core.o, vcodec-vdec.o, vcodec-venc.o each exit 0, zero warnings (W=1 also clean)",
    "integration_objects": "make ARCH=arm64 LLVM=1 W=1 -j2 with CONFIG_MTK_VCODEC_MT6735=m: exit 0, 0 warnings ($M/logs/vcodec-integration-build.log)",
    "module_object": "LD [M] drivers/misc/mediatek/vcodec/vcodec-mt6735.o exit 0 (all three objects link, no duplicate/undefined cross-file symbols)",
    "compat_n": "CONFIG_COMPAT=n build of vcodec-core.o exit 0 (compat code fully guarded)",
    "modpost": "vcodec-mt6735.ko modpost blocked only by missing vmlinux.o/Module.symvers (no full build in leaf scope); all core-kernel symbols used are EXPORT_SYMBOL(_GPL)",
    "checkpatch": "0 errors / 0 warnings / 0 checks on all 5 sources"
  },
  "architecture_decision": "Not V4L2 mem2mem: on MT6735 the kernel programs no codec data registers; downstream D1 has only ISR status/ack accesses and userspace mmaps the register windows to run the vendor codec libraries (D1:2165-2212). ROM has no VPU/SCP symbols and no request_firmware; nura.config has MEDIA_SUPPORT=n and the Nura mtk-vcodec backends require MT8173 VPU / MT8183+ SCP. A V4L2 codec driver would require the prohibited Android HAL port, so the delivered interface is two standard platform_driver engines plus the ROM-compatible /dev/Vcodec misc service (same ioctl numbers, structs, 32-bit compat layouts, mmap windows).",
  "firmware": "No codec firmware exists for MT6735 (verified: no VPU/SCP symbols in ROM, no request_firmware in downstream videocodec); none is invented or requested. Only real hardware services are implemented.",
  "verified_vs_rom": [
    "ROM dec_isr c0397f80: GCON bit4, [base+0xA4] bit16, ack OR 0x11 / BIC 0x10",
    "ROM enc_isr c0398098: type compares #5/#28, per-bit acks",
    "ROM vcodec_driver_init c0daf914: VENC status/ack at base+0x5C/0x60",
    "ROM vcodec_probe c0395dac, vdec_power_on c0396888, venc_power_on c0396ab8"
  ],
  "unresolved_gaps": [
    "No on-hardware validation; all register offsets/bits transcribed from downstream and confirmed by ROM disassembly only",
    "MMDVFS/DVFS scaling deferred (no MMDVFS framework)",
    "MTK hibernation IRQ re-sensitivity deferred",
    "SET_CPU_OPP_LIMIT returns -EOPNOTSUPP (no MTK cpu_opp_limit API)",
    "SYSRAM/non-cache/ion commands return -EOPNOTSUPP (ROM also had no handler)",
    "Deliberate deviations documented: lock timeout -ETIMEDOUT, WAITISR timeout -EFAULT, strict mmap containment, EMI counter saturation, CPU load from kcpustat",
    "DTS fragment and udev rule still to be applied by the DTS/integration owner",
    "Full-build .ko link needs vmlinux.o/Module.symvers from the global integration build"
  ],
  "coordinator_report": "$M/logs/vcodec-coordinator.md",
  "deliverables": [
    "$M/patches/vcodec-core.patch",
    "$M/patches/vcodec-vdec.patch",
    "$M/patches/vcodec-venc.patch",
    "$M/patches/vcodec-integration.patch",
    "$M/logs/vcodec-core.md",
    "$M/logs/vcodec-vdec.md",
    "$M/logs/vcodec-venc.md",
    "$M/logs/vcodec-coordinator.md",
    "$M/logs/vcodec-integration-build.log"
  ]
}