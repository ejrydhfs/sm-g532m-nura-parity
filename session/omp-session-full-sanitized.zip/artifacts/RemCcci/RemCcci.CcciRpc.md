{
  "leaf": "rpc",
  "status": "partial",
  "patch_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/rem-ccci-rpc.patch",
  "report_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/rem-ccci-rpc.md",
  "files_changed": [
    "drivers/misc/mediatek/ccci/ccci_rpc.c (new, 1389 lines)",
    "drivers/misc/mediatek/ccci/ccci_rpc.h (new, 211 lines)",
    "drivers/misc/mediatek/ccci/Makefile (+ccci_rpc.o)",
    "drivers/misc/mediatek/ccci/ccci_core.c (include, RPC demux in ccci_rx_dispatch_qno, rpc_init/exit)",
    "drivers/misc/mediatek/ccci/ccci_port_kernel.c (include, CCCI_RPC_RX -> ccci_rpc_handle)"
  ],
  "compile_result": "PASS. export PATH=$M/llvmpkg/usr/bin:$M/bin:$PATH; cp $M/nura.config .config; scripts/config -e MTK_CCCI -e MTK_CCMNI -e MTK_CCCI_C2K -e MTK_CCCI_UTIL -e MTK_CCCI_CLDMA; make ARCH=arm64 LLVM=1 olddefconfig -> rc=0 (CONFIG_MTK_CCCI=y); rm objects; make ARCH=arm64 LLVM=1 -j2 W=1 ccci_rpc.o ccci_core.o ccci_port_kernel.o -> rc=0; make ARCH=arm64 LLVM=1 -j2 W=1 drivers/misc/mediatek/ccci/built-in.a -> rc=0 (archive lists ccci_rpc.o). ccci_rpc.o and ccci_port_kernel.o are W=1 clean; only pre-existing kernel-doc warnings for ccci_md_send_skb() at ccci_core.c:384 and the kbuild 'overriding recipe' note for the explicit built-in.a target. Log: $M/logs/rem-ccci-rpc_build.log.",
  "open_items": [
    "0x2001 IPC_RPC_CPSVC_SECURE_ALGO_OP: handler validates the wire args but returns FS_NO_FEATURE; the HACC transform needs the MASP asfv2 driver (masp_hal_secure_algo_init/masp_hal_secure_algo, mach/hacc_hk.c) which does not exist in this tree. Downstream has no error code for this case (it BUG_ON()s at port_kernel.c:1298-1300).",
    "0x4007/0x4009 ADC value half: FS_NO_FEATURE. The in-tree mt6577_auxadc exposes only IIO_CHAN_INFO_PROCESSED (mV, integer-scaled) and does not match 'mediatek,mt6735-auxadc', so a raw 12-bit count cannot be produced without inventing one.",
    "0x4008 RF_CLK_BUF: the count!=CLKBUF_MAX_COUNT branch is exact; the count==4 branch returns FS_FUNC_FAIL because clk_buf_get_swctrl_status() and its mt_clkbuf_ctl driver are absent (the DT half alone would be a half-fabricated answer).",
    "DTS fragment (gpio_usage_mapping, SIM1/SIM2 EINT attribute nodes, adc_channel, auxadc controller) is delivered unapplied in report section 6; validated with the tree's dtc (exit 0, only pre-existing mt6735.dtsi warnings).",
    "For ADC value support the fragmented auxadc node additionally requires 'mediatek,mt6735-auxadc' to be added to mt6577_auxadc_of_match[] (drivers/iio/adc/mt6577_auxadc.c:313-320) plus a RAW IIO channel in that driver - outside this leaf's files.",
    "0x400B depends on the MPU leaf's ccci_md_set_dsp_mpu_protection(); it is referenced, not defined (0-based md->id confirmed with the coordinator/MPU leaf).",
    "Full vmlinux link was intentionally not run (coordinator performs it); the only unresolved ccci_* symbol from ccci_rpc.o is the cross-leaf ccci_md_set_dsp_mpu_protection."
  ],
  "missing_inputs": [
    "MediaTek MASP/asfv2 driver incl. HACC HAL and key material (drivers/misc/mediatek/masp/asfv2/**, masp_hal_secure_algo_init/algo) for op 0x2001",
    "A raw-count AUXADC provider: 'mediatek,mt6735-auxadc' compatible + IIO_CHAN_INFO_RAW in drivers/iio/adc/mt6577_auxadc.c, for ops 0x4007/0x4009",
    "MediaTek clk buffer control driver (clk_buf_get_swctrl_status(), mediatek,rf_clock_buffer consumer) for the count==4 half of op 0x4008"
  ]
}