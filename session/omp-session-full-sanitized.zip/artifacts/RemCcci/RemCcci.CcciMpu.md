{
  "leaf": "mpu",
  "status": "done",
  "patch_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/rem-ccci-mpu.patch",
  "report_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/rem-ccci-mpu.md",
  "files_changed": [
    "drivers/misc/mediatek/ccci/Makefile",
    "drivers/misc/mediatek/ccci/ccci_boot.c",
    "drivers/misc/mediatek/ccci/ccci_core.c",
    "drivers/misc/mediatek/ccci/ccci_mpu.c",
    "drivers/misc/mediatek/ccci/ccci_mpu.h",
    "drivers/misc/mediatek/ccci/ccci_priv.h"
  ],
  "compile_result": "exit 0: ccci_mpu.o, ccci_core.o, ccci_boot.o rebuilt with W=1, no warnings from this leaf's code; drivers/misc/mediatek/ccci/built-in.a archived with all 10 members. Pre-existing warnings named in report: ccci_ringbuf.c:209 unused-but-set 'read'; kernel-doc param warnings in ccci_core.c:370 / ccci_boot.c:670 (integration-baseline doc blocks, only on a fresh W=1 doc pass).",
  "open_items": [
    "DSP region size uses the header's dsp_img_size instead of downstream's separately-loaded DSP sub-image size (which is bounded by dsp_img_size); [INFERENCE], documented in report §5.",
    "EMI MPU direct-MMIO fallback intentionally not implemented: Nura DT has the arm,psci/smc conduit, and MT6735 has no non-secure MPU accessor downstream; without a conduit the code returns -ENODEV instead of faking success.",
    "modem_run_env_ready() LK bypass not reproduced (this driver always loads the image itself) - documented equivalence.",
    "Extra clears in ccci_md_stop()/ccci_md_reset() are a documented superset of downstream (which clears only at start).",
    "Hardware-unverified: no SMC executed, no MPU register read back, modem never booted with these regions.",
    "RMPU needs the DTS-FRAGMENT property mediatek,infracfg-ao on the modem node (report §6, not applied).",
    "RPC leaf must pass 0-based md->id to ccci_md_set_dsp_mpu_protection() (notified to coordinator)."
  ],
  "missing_inputs": []
}