{
  "leaf": "rem-ccci-dts",
  "status": "done",
  "patch_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/rem-ccci-dts.patch",
  "report_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/rem-ccci-dts.md",
  "files_changed": [
    "drivers/misc/mediatek/ccci/ccci_boot.c"
  ],
  "compile_result": "PASS. Config: cp $M/nura.config .config; scripts/config -e MTK_CCCI -e MTK_CCMNI -e MTK_CCCI_C2K -e MTK_CCCI_UTIL -e MTK_CCCI_CLDMA; make ARCH=arm64 LLVM=1 olddefconfig (rc=0, CONFIG_MTK_CCCI=y). Objects with PATH=$M/llvmpkg/usr/bin:$M/bin and W=1: drivers/misc/mediatek/ccci/ccci_boot.o rc=0, 0 warnings; drivers/misc/mediatek/ccci/built-in.a rc=0 with 9 members and ccci_boot.o rebuilt from scratch. Only pre-existing warnings: ccci_core.c:370 and ccci_ccif.c:145 kernel-doc, ccci_ringbuf.c:181 kernel-doc + ccci_ringbuf.c:209 unused-but-set 'read', plus Kbuild recipe-override notices for directly naming a subdir built-in.a. DTS: cpp -nostdinc -undef -x assembler-with-cpp -I include -I arch/arm64/boot/dts/mediatek -I arch/arm64/boot/dts over a scratch wrapper of mt6737t-samsung-grandpplte.dts + fragments (rc=0), then scripts/dtc/dtc -I dts -O dtb (rc=0); warning set identical to the unmodified board DTS (one pre-existing /soc/interrupt-controller@10220000 simple_bus_reg warning), none from the added carve-out/mdcldma/EINT nodes. git apply --check of this patch on the ccci-gap-clock worktree (which already carries the single-carve-out split) exits 0.",
  "open_items": [
    "Single-carve-out split itself is owned by the clock leaf (ccci-gap-clock.patch) and was NOT re-implemented here; reviewed and found correct (CCCI_IMAGE_ALIGN 0x4000 at ccci_boot.c:44 == get_md_smem_align() at ccci_util_lib_fo.c:948-951; math matches fo.c:1120-1122). This leaf adds the missing memory-region resolution so the recovered reg-less carve-out can actually be consumed.",
    "mediatek,md1-smem-size / md3-smem-size / md1md3-smem-size are parsed by downstream cal_md_settings_v2() (fo.c:1157-1175) and proven live by ROM strings, but the Nura tree has no consumer (no MD3 IRAT/MD1<->MD3 smem window) -> documented as recovered-but-unused, not parsed, no dead fields added.",
    "clocks = <&scpsys SCP_SYS_MD1> not emitted: the tree has no SCP_SYS_* binding, no clk-mt6735-pg.c and scpsys has no #clock-cells; MD1 gate maps to MT6735_POWER_DOMAIN_MD1 via power-domains (same substitution as previously delivered fragments).",
    "EINT nodes placed under &pio, not a separate eintc: the Nura tree has no eintc node (assignment's mt6735.dtsi:353 is an MMC pin group); pio owns the 0x10005000 'eint' window, GIC_SPI 153 and 2 interrupt cells, matching ROM eintc 403-408. ROM @0/@1 unit suffixes dropped because the nodes have no reg/ranges (dtc warning) and of_find_node_by_name() matches the base name.",
    "No device was available: reserved-memory chosen base, modem visibility, EINT polarity/debounce and power-domain attach are source-derived only.",
    "Deliverable deviations from earlier fragments are tabulated in report section 6.3 (single carve-out + compatible key vs two FILL regions; firmware-name/power-domains/status merged; infracfg-ao included; EINT nodes newly delivered)."
  ],
  "missing_inputs": [
    "MD3 carve-out size for mediatek,reserve-memory-ccci_md3_ccif (key at ccci_util_lib_fo.c:1228, RESERVEDMEM_OF_DECLARE at :1264): absent from downstream DTS (only reserve-memory-ccci_md1 exists), absent from ROM DTB reserved-memory (rom_dtb_0.dts:167-220), no ap2c2k_ccif/md3-smem-size property anywhere.",
    "MD1<->MD3 share size for mediatek,reserve-memory-ccci_share (key at ccci_util_lib_fo.c:1229, consumed by get_md1_md3_resv_smem_info()/eccci ccci_core.c:297-301): absent from every source; ROM string vmlinux.strings:37118 proves the property is parsed but no value exists.",
    "Explicit MD1 image/smem base addresses for the two-region fragment form: absent from every source (downstream uses a dynamically allocated carve-out with size/alignment/alloc-ranges only), hence the single-region fragment is the recovered shape."
  ]
}