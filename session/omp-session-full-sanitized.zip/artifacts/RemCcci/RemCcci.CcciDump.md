{
  "leaf": "dump",
  "status": "partial",
  "patch_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/rem-ccci-dump.patch",
  "report_path": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/rem-ccci-dump.md",
  "files_changed": [
    "drivers/misc/mediatek/ccci/Kconfig",
    "drivers/misc/mediatek/ccci/Makefile",
    "drivers/misc/mediatek/ccci/ccci_boot.c",
    "drivers/misc/mediatek/ccci/ccci_ccif.c",
    "drivers/misc/mediatek/ccci/ccci_core.c",
    "drivers/misc/mediatek/ccci/ccci_exception.c",
    "drivers/misc/mediatek/ccci/ccci_exception.h",
    "drivers/misc/mediatek/ccci/ccci_port_char.c",
    "drivers/misc/mediatek/ccci/ccci_priv.h",
    "tools/mediatek/ccci/.gitignore",
    "tools/mediatek/ccci/Makefile",
    "tools/mediatek/ccci/ccci-dump.c",
    "tools/mediatek/ccci/ccci_exrec.h"
  ],
  "compile_result": "Kernel: cp nura.config + scripts/config -e MTK_CCCI/CCMNI/C2K/UTIL/CLDMA + make ARCH=arm64 LLVM=1 olddefconfig rc=0 (CONFIG_MTK_CCCI=y etc.); make ARCH=arm64 LLVM=1 -j1 W=1 ccci_exception.o ccci_core.o ccci_boot.o ccci_port_char.o ccci_ccif.o rc=0, 5/5 rebuilt, zero warning:/error: lines; make ... built-in.a rc=0, 10 members. Only pre-existing kernel-doc warnings on untouched functions (ccci_core.c:446, ccci_boot.c:641, ccci_ccif.c:145). Userspace: make -C tools/mediatek/ccci rc=0 with cc (GCC 16.2.1); make check rc=0; no-device run exits 1 with ENODEV. Patch 2560 lines, git apply --check --reverse OK.",
  "open_items": [
    "DHL RX ring cannot remain alive during the 2 s HIF_EX_CLEARQ_DONE flush window: the frozen API has no cldma_stop_for_ee(), so HIF_EX_INIT stops the whole engine (documented partial; exact SCAFFOLD CHANGE REQUIRED proposal in report section 7).",
    "AEE database client (aed_md_exception_api, ROM 0xc0628298) does not exist in this kernel tree; dumps are delivered to kernel log, /dev/ccci_dump ring and debugfs ccci/mdN/exception_{dump,packet,stage}, and the ROM ABI aee_dump_ccci_debug_info() is implemented for such a client.",
    "Legacy SRAM SBP WM_ID half (feature_4_val[1] from modem load_type/get_md_wm_id_map) not implemented: no load-type data in the tree or frozen ccci_md_cfg.",
    "No hardware attached: modem-written record contents, 2000 ms flush timing and RMPU offender placement are hardware-unverified.",
    "Debugfs node names use the exception_ prefix (exception_dump/exception_packet/exception_stage) to avoid colliding with the util driver's ccci/mdN/dump; the tool documents and reads them."
  ],
  "missing_inputs": [
    "Frozen header addition void ccci_cldma_stop_for_ee(struct ccci_cldma *cd, u16 stop_mask); (downstream modem_cldma.c:1449-1520, NONSTOP_QUEUE_MASK 0xF0).",
    "Modem load-type source (md->config.load_type / get_modem_support_cap() / get_md_wm_id_map(), downstream modem_cldma.c:3357-3360) for the legacy SBP WM_ID byte.",
    "An AEE/aed client implementation (aed_md_exception_api) if Android DB upload of the dump is required; not present in the ROM source tree or Nura."
  ]
}