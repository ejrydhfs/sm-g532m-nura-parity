{
  "status": "done",
  "summary": "Implemented the AEE/AED exception (DB) client kernel interface for Nura: new drivers/misc/mediatek/aee/ (aed-main.c, aed-process.c, aed.h, Kconfig, Makefile) registering /dev/aed0 (EE) and /dev/aed1 (KE), the 24-byte AE_Msg read/write/poll protocol per downstream aed.h/aed-main.c, an EE exception record queue+worker with the 5-minute close handshake, the EE detail response including the '== CCCI LOG ==' section fetched via aee_dump_ccci_debug_info(), /proc/aed/current-ee-coredump, the ioctls libaed.so actually uses (AEEIOCTL_GET_THREAD_REG in BOTH the 296-byte 0x41287007 and 76-byte 0x404c7007 encodings, empirically read out of the ROM library) plus AEEIOCTL_GET_PROCESS_BT, SET_AEE_MODE and CHECK_SUID_DUMPABLE, and aed_md_exception_api()/md32/scp/combo implemented directly as EXPORT_SYMBOL_GPL, GFP_ATOMIC-safe. ccci_ex_build() now hands its EX_LOG_T record, CCCI_MD_IMG_DUMP_SIZE image head and the 'mdN:<reason>' detail string to aed_md_exception_api() with DB_OPT_DEFAULT|DB_OPT_FTRACE, guarded by IS_ENABLED(CONFIG_MTK_AEE_FEATURE). New include/uapi/linux/aee.h carries the whole client ABI (every value cited to downstream aed.h/mt-plat/aee.h) and is shared by driver and tool. New tools/mediatek/aee/aee-db speaks the ABI (query/class/type/process/module/backtrace/detail/coredump/ccci --md N/close/regs/bt/--selftest).",
  "deliverables": {
    "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/rem2-aee.patch",
    "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/rem2-aee.md"
  },
  "diffstat": "12 files changed, 2378 insertions(+), 0 deletions(-): drivers/misc/mediatek/{Kconfig +1, Makefile +1}, drivers/misc/mediatek/aee/{Kconfig 20, Makefile 3, aed-main.c 1160, aed-process.c 84, aed.h 65}, drivers/misc/mediatek/ccci/ccci_exception.c +38, include/uapi/linux/aee.h 194, tools/mediatek/aee/{.gitignore 1, Makefile 23, aee-db.c 788}",
  "build": {
    "worktree": "$M2/worktrees/rem2-aee @ 046883c0c + parity-baseline-all.patch + frozen headers",
    "config": "cp $M/nura.config .config; ./scripts/config --enable MTK_AEE_FEATURE --enable MTK_CCCI; make ARCH=arm64 LLVM=1 olddefconfig (rc=0)",
    "kernel": [
      {
        "cmd": "make ARCH=arm64 LLVM=1 -j2 W=1 drivers/misc/mediatek/aee/",
        "rc": 0,
        "warnings": 0,
        "artifacts": [
          "drivers/misc/mediatek/aee/aed-main.o",
          "drivers/misc/mediatek/aee/aed-process.o",
          "drivers/misc/mediatek/aee/built-in.a"
        ]
      },
      {
        "cmd": "make ARCH=arm64 LLVM=1 -j2 W=1 drivers/misc/mediatek/ccci/ccci_exception.o",
        "rc": 0,
        "warnings": 0
      },
      {
        "cmd": "CONFIG_MTK_CCCI=n variant of the aee/ build (ifdef path)",
        "rc": 0,
        "warnings": 0
      },
      {
        "cmd": "CONFIG_MTK_AEE_FEATURE=n variant of ccci_exception.o (call compiled out)",
        "rc": 0,
        "warnings": 0
      }
    ],
    "preexisting_warning_not_mine": "drivers/misc/mediatek/ccci/ccci_ringbuf.c:209: variable 'read' set but not used (only when building the whole ccci/ directory)",
    "userspace": {
      "build": "cd tools/mediatek/aee && make -> cc -I../../../include/uapi -O2 -Wall -Wextra -Werror -o aee-db aee-db.c, rc=0, 0 warnings",
      "check": "make check -> selftest: OK: 5 KAT groups, 24-byte AE_Msg, 32-byte aee_ioctl, 0x404c7007/0x41287007 thread-reg ioctls, rc=0"
    },
    "patch_validation": "git apply --check clean; applied onto the pristine baseline blobs of the three touched baseline files and the result is byte-identical to the worktree",
    "symbols": "aed-main.o defines+exports aed_{md,md32,scp,combo}_exception_api (EXPORT_SYMBOL_GPL) and has U aee_dump_ccci_debug_info; ccci_exception.o has U aed_md_exception_api"
  },
  "client_abi_findings": {
    "libaed_so": "ELF32 ARM Thumb-2 libaed.so: aee_ioctl_get_reg (dynsym 0x4675) opens /dev/aed0 (literal 0xaa24 at 0x4764 -> '0xf0a6') and issues ioctl 0x41287007 (_IOW('p',7,296)) at 0x46be, falling back to 0x404c7007 (_IOW('p',7,76)) at 0x4702, then close; no read/write on the fd. Raises go over the local socket 'com.mtk.aee.aed' as 24-byte AE_IND messages (helper at 0x3828: cmdType 2, cmdId 0x0b/0x0c/0x0d/0x0e). /dev/aed1 is never referenced by the library.",
    "served_by_driver": [
      "AEEIOCTL_GET_THREAD_REG (76-byte)",
      "AEEIOCTL_GET_THREAD_REG64 (296-byte)",
      "AEEIOCTL_GET_PROCESS_BT",
      "AEEIOCTL_SET_AEE_MODE",
      "AEEIOCTL_CHECK_SUID_DUMPABLE",
      "AE_Msg EE protocol (class/type/process/detail/coredump + AE_IND_LOG_CLOSE)",
      "AE_Msg KE protocol (AE_NOT_AVAILABLE, no producer in tree)",
      "aed_md/md32/scp/combo_exception_api (CCCI path)"
    ]
  },
  "deferred": [
    {
      "item": "libaed.so AE_Msg raise path over the 'com.mtk.aee.aed' local socket",
      "missing_input": "the closed-source AED daemon (Java com.mtk.aee.aed) or its source; userspace-only, no kernel interface involved"
    },
    {
      "item": "KE exception capture (kernel oops -> /dev/aed1) and aee_kernel_exception/warning/reminding_api, aee_kernel_dal_api",
      "missing_input": "aee_oops_create()/aee_oops_free() infrastructure plus ipanic/mrdump/dram console (mrdump.h, mt-plat/mtk_ram_console.h) - absent from the Nura tree"
    },
    {
      "item": "DAL show/clean/setcolor ioctls",
      "missing_input": "the vendor disp_assert_layer.h DAL framebuffer assert layer"
    },
    {
      "item": "red screen / RT monitor / WDT powerkey / SF state ioctls",
      "missing_input": "/dev/RT_Monitor, /dev/kick_powerkey, SurfaceFlinger state producers and the red-screen display path"
    },
    {
      "item": "userspace backtrace/regs/maps message payloads (AE_REQ_USERSPACEBACKTRACE/USER_REG/USER_MAPS) on /dev/aed1",
      "missing_input": "struct aee_oops userthread_stack/userthread_maps storage and DumpThreadNativeInfo(), i.e. the KE oops model (aed-main.c:472-560 needs aee_oops)"
    },
    {
      "item": "aed-debug.c test/proc entries",
      "missing_input": "ipanic/dram-console/kprobe test scaffolding; debug-only, not required by any consumer"
    },
    {
      "item": "CCCI image-info suffix in the detail string",
      "missing_input": "ccci_get_md_info_str()/md_img_info_str from ccci_util_lib_load_img.c:646 - not present in Nura"
    }
  ],
  "scaffold_changes": "none required; the coordinator-owned frozen include/linux/aee.h (IS_ENABLED(CONFIG_MTK_AEE_FEATURE) guard + static-inline fallbacks), include/linux/clkbuf.h and include/linux/ccci.h were used as-is and are absent from the patch. Kconfig symbol is exactly MTK_AEE_FEATURE (bool). No shared DTS/DTSI edit; the report's DTS-FRAGMENT section states that no node is needed. No other worktree, integration tree or $M/nura.config was modified.",
  "notes": "Patch is a true delta against the parity baseline (generated with a temporary GIT_INDEX_FILE whose base tree is HEAD + the three touched baseline blobs: ccci_exception.c fa2fbff6c, mediatek/Kconfig cba2e7fc4, mediatek/Makefile e77fb43c0), because the baseline itself is uncommitted in the worktree. 13 deliberate deviations (documented in report section 6), notably: aee_mode defaults to AEE_MODE_MTK_USER because there is no AED daemon to set it; record payloads use kmalloc(GFP_ATOMIC)/kfree instead of vmalloc_user for atomic safety; the ioremapped CCCI window is read with memcpy_fromio; the 76-byte register view returns -EOPNOTSUPP for a 64-bit task; GET_PROCESS_BT unwinds with stack_trace_save_tsk without the 32-bit cross-CPU barrier. [INFERENCE] items are limited to the internal field split of the 296-byte register payload and the AArch32 mapping of the 76-byte one; all command values and struct sizes come from libaed.so or downstream headers. Nothing was hardware-verified."
}