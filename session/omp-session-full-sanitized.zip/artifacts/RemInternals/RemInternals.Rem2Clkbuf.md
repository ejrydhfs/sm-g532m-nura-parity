{
  "status": "complete",
  "leaf": "rem2-clkbuf",
  "worktree": "$M2/worktrees/rem2-clkbuf (detached 046883c0c + $M/patches/parity-baseline-all.patch; no reset/checkout/stash/commit)",
  "summary": "Ported the MT6735 RF clock buffer driver as an arm64 7.x platform driver on \"mediatek,rf_clock_buffer\" with SPM access through the existing scpsys syscon (required \"mediatek,spm\" phandle, regmap, offsets 0x014/0x3b4/0x60c/0x610/0x614/0x620/0x624-0x634 from downstream mt_spm.h). Implemented the frozen clkbuf.h API (clk_buf_ctrl / clk_buf_get_swctrl_status / clk_buf_init, exported GPL for the mtk_wcn_wmt module), the /sys/power/clk_buf/clk_buf_ctrl show/store semantics below power_kobj at late_initcall, and rewrote CCCI op 0x4008 to the downstream 13-byte ccci_rpc_clkbuf_result payload (count 4 -> DT mediatek,clkbuf-config + swctrl shadow; count != 4 -> 0xFF + zeros; not probed -> FS_FUNC_FAIL + log). CONSYS co-clock power-on/off now drives clk_buf_ctrl(CLK_BUF_CONN, 1/0) inside the existing wmt_lib_co_clock() condition, with an err-path unwind. GPS (MT6580-only) intentionally not wired; NFC reported deferred (Nura has no NFC driver).",
  "paths": {
    "patch": "$M/patches/rem2-clkbuf.patch",
    "report": "$M/logs/rem2-clkbuf.md",
    "supplementary_build_log": "$M2/logs/rem2-clkbuf-build.log"
  },
  "diffstat": "drivers/misc/mediatek/Kconfig 1 +; drivers/misc/mediatek/Makefile 1 +; drivers/misc/mediatek/ccci/ccci_rpc.c 96 +++-; drivers/misc/mediatek/clkbuf/Kconfig 22 +; drivers/misc/mediatek/clkbuf/Makefile 5 +; drivers/misc/mediatek/clkbuf/mt_clkbuf_ctl.c 553 +; drivers/misc/mediatek/clkbuf/mt_clkbuf_ctl.h 127 +; drivers/misc/mediatek/connectivity/wmt/consys_mt6735.c 26 +; 8 files changed, 814 insertions(+), 17 deletions(-); patch 28470 bytes",
  "build": {
    "config": "cp $M/nura.config .config; scripts/config -e MTK_CLKBUF -e MTK_CCCI -e MTK_CCCI_CLDMA -e MTK_CCCI_UTIL -m MTK_WCN_WMT -m MTK_BTIF; make ARCH=arm64 LLVM=1 olddefconfig (rc 0); $M/nura.config untouched",
    "commands": [
      "make ARCH=arm64 LLVM=1 -j2 W=1 drivers/misc/mediatek/clkbuf/mt_clkbuf_ctl.o",
      "make ARCH=arm64 LLVM=1 -j2 W=1 drivers/misc/mediatek/clkbuf/built-in.a",
      "make ARCH=arm64 LLVM=1 -j2 W=1 drivers/misc/mediatek/ccci/ccci_rpc.o drivers/misc/mediatek/connectivity/wmt/consys_mt6735.o",
      "make ARCH=arm64 LLVM=1 -j2 W=1 drivers/misc/mediatek/built-in.a"
    ],
    "rc": 0,
    "compiler_warnings": 0,
    "compiler_errors": 0,
    "non_source_warnings": "4 make-level 'overriding recipe for target ...built-in.a' messages from scripts/Makefile.build:541/462 when the archive target is requested explicitly (artifact of the invocation, not code)",
    "extra_check": "CONFIG_MTK_CLKBUF=n + olddefconfig: ccci_rpc.o still builds W=1 rc 0 (header stubs + IS_ENABLED guard); config restored to =y and both objects rebuilt clean",
    "exports_verified": "__export_symbol_clk_buf_ctrl / __export_symbol_clk_buf_get_swctrl_status / __export_symbol_clk_buf_init in llvm-nm of mt_clkbuf_ctl.o"
  },
  "deferred": [
    {
      "item": "NFC clock buffer (CLK_BUF_NFC enable/disable)",
      "downstream": "drivers/misc/mediatek/nfc/mt6735/mt6605.c:890 (MTK_NFC_IOCTL_CMD_CLOCK_BUF_ENABLE), :897 (MTK_NFC_IOCTL_CMD_CLOCK_BUF_DISABLE)",
      "missing_input": "no NFC driver/ioctl implementation exists anywhere in the Nura tree; a stub NFC driver was explicitly not created"
    },
    {
      "item": "Root-level rf_clock_buffer DTS node with mediatek,spm = <&scpsys>",
      "missing_input": "shared DTS is coordinator-owned; fragment (ROM values 2 1 1 1, quantity 4) is in report section 7, phandle marked [INFERENCE]"
    }
  ],
  "scaffold_changes": "none - include/linux/clkbuf.h was sufficient as frozen; no SCAFFOLD CHANGE REQUIRED section needed",
  "evidence_highlights": [
    "ROM vmlinux.elf: clk_buf_ctrl@0xc03492d0, clk_buf_get_swctrl_status@0xc03493f4, clk_buf_init@0xc0349424, spm_clk_buf_ctrl.constprop.0@0xc034905c, clk_buf_Send_BSI_CW.constprop.1@0xc03490dc, spm_ap_bsi_gen@0xc0367ffc, spm_ap_mdsrc_req@0xc036bf18 (.text, sizes 0 in recovered symtab); disassembly of 0xc03492d0-0xc03493f4 shows of_property_read_u32_array, id 0..3 vs config==2 compares, mutex_lock, ldr #0x60c/#0x610, calls to both BSI variants",
    "ROM DTB rom_dtb_0.dts:4602-4607 rf_clock_buffer {quantity 4; config <2 1 1 1>}; :307-311 scpsys reg <0x10000000 0x1000 0x10006000 0x1000>",
    "downstream citations verified with nl -ba: mt_clkbuf_ctl.c:59-64,66-73,75-83,85-96,98-149,151-169,170,171-217,219-225,227-294,296-313; mt_spm.h:87,156,176-185,321-327; spm_v1/mt_spm.c:932-945; spm_v1/mt_spm_sleep.c:2031-2096; mt_spm_internal.h:77-78; port_kernel.c:1650-1707; mtk_wcn_consys_hw.c:353-358,729-734; mt_pm_init.c:550-559"
  ],
  "git_status_note": "The parity baseline is uncommitted in this worktree and drivers/misc/mediatek/ plus include/linux/clkbuf.h are untracked vs 046883c0c, so a literal `git add -A && git diff --cached` would emit the whole baseline. The delivered patch is a leaf-only delta built from tree objects (staged tree T_ALL vs T_BASE whose entries for the four pre-existing baseline files were re-pointed at the pristine baseline blobs and the four new clkbuf files removed); `git apply -R --check` rc 0 proves it applies forward on the baseline. The index is left fully staged (no reset was run, per contract) - status shows 'A' for the 8 leaf paths."
}