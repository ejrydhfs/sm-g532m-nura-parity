{
  "status": "complete",
  "worktree": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/rem2-iopipe",
  "head": "046883c0c (detached) + parity-baseline-all.patch (baseline left uncommitted, not touched)",
  "summary": "Recovered the MT6735 camera pipe/tuning data from the closed HALs into a host tool tools/mediatek/camera/iopipe/: (1) the six libcam.iopipe.so port/path tables (34x8, 17x8, 43x20, 8x12, 2x8, 1x8 bytes) with record widths proved by code stride (FeatureStream::init @0x11686/0x11698, mla #0x14) or by content invariants asserted at run time, plus the AlltoP2<->P2toAll inverse check; (2) the ISP_MGR_* catalogue from libcam.hal3a.v3.so dynsym (25 module tokens, 90 template instances with SensorDev/SensorTG/PCAMode, 123 methods, 24 ISP_NVRAM types) in text/CSV/JSON; (3) 19 TPIPE/P1/P1_D/P2 module-enable programming records over 13 modules, each recorded as MOVW-address + BFI/ORR-bit + owning CTL_EN_* call site and re-read/re-decoded from the ELF by the selftest; (4) a CQ0C instruction-word builder reusing the libcamdrv/camdrv_cq.c encodings with KATs; (5) 15 allow-listed tuning symbols (9 file-backed decoded/dumped, 6 .bss reported as runtime-only) and the machine-listed per-sensor default-data generators. Kernel change: none - the enable words are written by the userspace 3A library and the kernel only reads ISP_REG_EN1 for a debug line (mtk-isp.c:2833), so no constant is grounded kernel-side; mtk-isp-regs.h is untouched and no kernel object was built. DSP: proved absent (grep -aic dsp = 0 in all six vendor libs, 0 files in downstream cameraisp, 0 camera/isp strings in the ROM), so no DSP pipeline was invented.",
  "paths": {
    "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/rem2-iopipe.patch",
    "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/rem2-iopipe.md",
    "build_log": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/rem2-iopipe-build.log",
    "check_log": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/rem2-iopipe-check.log"
  },
  "diffstat": "tools/mediatek/camera/Makefile +3 (3 recipe lines) ; tools/mediatek/camera/iopipe/{Makefile 87, iopipe_elf.c 590, iopipe_elf.h 114, iopipe_portmap.c 496, iopipe_portmap.h 84, iopipe_mgr.c 415, iopipe_mgr.h 44, iopipe_regmap.c 575, iopipe_regmap.h 87, iopipe_cq.c 83, iopipe_cq.h 73, iopipe_tuning.c 316, iopipe_tuning.h 43, main.c 282, iopipe_selftest.c 284} = 16 file diffs, 15 new files +3573 lines, 0 deletions. Patch 108,850 bytes, applies clean with git apply --whitespace=error-all --check on top of the baseline.",
  "build_rc": {
    "tool_build": {
      "cmd": "make -j2 (after rm -rf build; gcc -O2 -Wall -Wextra -Werror -std=gnu11)",
      "rc": 0,
      "warnings": 0,
      "errors": 0
    },
    "tool_check": {
      "cmd": "make check",
      "rc": 0,
      "selftest_checks_passed": 41,
      "per_object_lines": "7 portmap ok, 19 regmap ok, 4 regmap none, 15 tuning ok",
      "failures": 0
    },
    "parent": {
      "cmd": "tools/mediatek/camera: make all ; make check",
      "rc_all": 0,
      "rc_check": 0
    },
    "kernel": "not built, not modified (no header change) - deliberate, see report s6.4"
  },
  "deferred": [
    {
      "item": "per-module register VALUE programming (payload registers for BNR/LSC/CCM/... )",
      "missing_input": "apply(EIspProfile_T, isp_reg_t*) is a generic loop over a runtime (address,value) pair array built by put() (0x6ce50 / 0x6d1a4); no static address->value table exists in the ELF"
    },
    {
      "item": "enable programming for MIXER3, NR3D, MFB, G2C_SHADE",
      "missing_input": "their apply(EIspProfile_T) bodies contain no CAM-window register immediate (machine-checked by a Thumb-2 length-walking scan); addresses only exist as NVRAM data at run time"
    },
    {
      "item": "FLK window / FKO DMA address registers",
      "missing_input": "ISP_MGR_FLK_CONFIG::SetFLKWin/enableFlk/SetFKO_DMA_Addr are 2-byte aliases at 0x3d07b inside _ZThn4_...Hal3AAdapter::doDataCb - no implementation in libcam.hal3a.v3.so"
    },
    {
      "item": "AE/AWB statistic config register lists",
      "missing_input": "config(int, AE_STAT_PARAM_T&) / config(AWB_STAT_CONFIG_T&, int, int) take runtime structs; no register immediates in the bodies"
    },
    {
      "item": "any camera DSP tuning/pipeline",
      "missing_input": "no camera DSP exists in any available source: grep -aic dsp = 0 for libcam.iopipe.so, libcam.hal3a.v3.so, libcamalgo.so, lib3a.so, libcameracustom.so, libcamdrv.so; 0 files in downstream cameraisp; 0 cam/isp-related dsp strings in vmlinux.strings"
    },
    {
      "item": "per-sensor ISP NVRAM defaults",
      "missing_input": "generated at run time by _ZNK9NSFeature13RAWSensorInfoILj537EE17impGetDefaultData... @0xf371c/0xf3c78 (208 bytes each), not stored as blobs"
    },
    {
      "item": "kernel TPIPE/P1/P2 register constants",
      "missing_input": "not needed: the kernel never writes a module-enable word (only reads ISP_REG_EN1 at mtk-isp.c:2833) and CAM 0x4004 is already ISP_REG_EN1 = 0x0004"
    }
  ],
  "scaffold_changes": [],
  "notes": [
    "Patch composition deviation (documented in report s6.5): the parity baseline is uncommitted and tools/mediatek/camera/ is untracked here, so a literal `git add -A && git diff --cached --binary` would emit the whole parity payload; I staged only tools/mediatek/camera/iopipe/ and prepended a minimal 3-line diff of tools/mediatek/camera/Makefile (the file the otp leaf wired), which applies cleanly on the baseline.",
    "Ghidra 12.1.2 headless was used for the initial xref sweep (script + project recorded in the report); its decompiler does not fold the PC-relative GOT literals, so all instruction-accurate work was done with llvm-objdump windows cited in report s2.",
    "Field names in the port/path tables and the 'BFI source is the module enable flag' reading are marked [INFERENCE]; offsets, sizes, record counts, raw words, register addresses and bit positions are machine-verified by `iopipe selftest`.",
    "No file outside tools/mediatek/camera/ was touched: git status shows only the 15 iopipe files (staged) plus the pre-existing baseline entries; no DTS, no nura.config, no kernel tree change."
  ]
}