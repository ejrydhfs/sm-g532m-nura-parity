{
  "status": "complete",
  "leaf": "rem2-cldma",
  "worktree": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/rem2-cldma",
  "head": "046883c0c2b956fd7436d3c1156f25512d1f6a90",
  "one_line_result": "Implemented ccci_cldma_stop_for_ee() and ccci_cldma_dhl_rx_alive() from the downstream cldma_stop_for_ee sequence, verified register-by-register against the inlined writes in ROM md_cd_ccif_work/md_cd_ccif_delayed_work, and wired HIF_EX_INIT/HIF_EX_CLEARQ_DONE to them (stop -> ACK; 2 s window -> close -> full stop -> dump -> CLEARQ_ACK), removing the stale SCAFFOLD CHANGE REQUIRED comment.",
  "diffstat": {
    "files": [
      {
        "path": "drivers/misc/mediatek/ccci_cldma/ccci_cldma.c",
        "added": 214,
        "removed": 0
      },
      {
        "path": "drivers/misc/mediatek/ccci_cldma/ccci_cldma.h",
        "added": 42,
        "removed": 0
      },
      {
        "path": "drivers/misc/mediatek/ccci/ccci_ccif.c",
        "added": 50,
        "removed": 18
      }
    ],
    "total": "3 files changed, 306 insertions(+), 18 deletions(-)"
  },
  "paths": {
    "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/rem2-cldma.patch",
    "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/rem2-cldma.md",
    "patch_sha256": "684bdc22f2c657a0c0a45265d76529e75fb42b8ddff1eac5919d16410d9ae086",
    "patch_bytes": 16344
  },
  "api_surface": {
    "implemented": [
      "int ccci_cldma_stop_for_ee(struct ccci_cldma *cd)  [EXPORT_SYMBOL_GPL]",
      "int ccci_cldma_dhl_rx_alive(struct ccci_cldma *cd, bool alive)  [EXPORT_SYMBOL_GPL]"
    ],
    "failure_codes": [
      "0 success",
      "-EINVAL bad engine pointer",
      "-ETIMEDOUT stopped queues never report idle (latch/mask programming still applied; caller raises AEE)"
    ],
    "callers": [
      "ccci_ccif_exception(): HIF_EX_INIT -> ccci_cldma_stop_for_ee(); HIF_EX_CLEARQ_DONE -> msleep(2000) -> ccci_cldma_dhl_rx_alive(false) -> ccci_cldma_stop()"
    ],
    "aee": "aed_md_exception_api() referenced only as extern from <linux/aee.h>, called by the ccif after a -ETIMEDOUT with DB_OPT_DEFAULT and detail \"mdN:\\nUNKNOWN Exception\\nstop Tx/Rx CLDMA for EE failed.\\n\"; never from inside a spinlock"
  },
  "build": {
    "commands": [
      "cp $M/nura.config .config; ./scripts/config -e MTK_CCCI; make ARCH=arm64 LLVM=1 olddefconfig",
      "make ARCH=arm64 LLVM=1 -j2 W=1 drivers/misc/mediatek/ccci_cldma/ccci_cldma.o drivers/misc/mediatek/ccci/ccci_ccif.o drivers/misc/mediatek/ccci/ccci_core.o",
      "make ARCH=arm64 LLVM=1 -j2 W=1 drivers/misc/mediatek/ccci_cldma/ drivers/misc/mediatek/ccci/",
      "make ARCH=arm64 LLVM=1 -j2 W=1 drivers/misc/mediatek/ccci_cldma/ (after final header edit)"
    ],
    "rc": [
      0,
      0,
      0
    ],
    "warnings": "ccci_cldma.o: 0 warnings. ccci_ccif.o/ccci_core.o: 10 W=1 kernel-doc lines, all in untouched functions (ccci_ccif.c:146 ccci_ccif_send 'md'/'channel', ccci_core.c:494 ccci_md_send_skb 'md'/'qno'/'skb'); proven pre-existing by rebuilding the baseline blob of ccci_ccif.c, which emits the same 4 warnings. Full-directory rebuild additionally shows pre-existing ccci_boot.c:730 kernel-doc and ccci_ringbuf.c:209 unused-but-set-variable.",
    "notes": "nura.config has no CCCI option; CONFIG_MTK_CCCI=y was enabled only in the worktree-local .config for the object builds. No vmlinux build, -j2, TMPDIR=$M2/tmp."
  },
  "evidence_highlights": [
    "downstream modem_cldma.c:113-114 (0xF0/0xF0F0F0F0), 1449-1520 (stop_for_ee), 1694-1730 (per-queue RX stop), 1746-1770 (per-queue RX start), 1966-1983 (delayed work), 1999-2035 (HIF_EX_INIT/INIT_DONE/CLEARQ_DONE/ALLQ_RESET)",
    "ROM vmlinux.elf md_cd_ccif_work 0xc052843c: window 0xc0528558-0xc0528928 inlines the whole sequence (UL_STOP_CMD=0xFF @0xc05285d8, SO_STOP_CMD=0xF0 @0xc0528720, SO_STATUS&0xF0 @0xc0528754, 100000 cadence @0xc0528604-0xc0528618, 1600000 + aed_md_exception_api @0xc0528678/0xc05287e4, latches 0xc05287f4-0xc0528888, L2RIMSR0=0x00F000F0 @0xc05288c4, md_cd_clear_all_queue + md_cd_ccif_send(1=H2D_EXCEPTION_ACK) @0xc0528940/0xc0528950, msleep(2000) @0xc0528a0c, SO_CFG bit0 re-check 0xc0528d04-0xc0528d1c)",
    "ROM md_cd_ccif_delayed_work 0xc0527c80: inlined full cldma_stop (0xFF stop cmds, all latches/masks 0xFFFFFFFF)",
    "ROM md_cd_ee_callback 0xc052d648 only toggles the watchdog in this build (no CLDMA writes), which is why the sequence was cited from the ccif worker",
    "Nura port table ccci_core.c:1283-1285/1289-1291/1298-1300 proves the exception traffic uses RX queues 1/2/3 (.rxq_exp), i.e. the 0x0F set kept alive"
  ],
  "deferred": [
    {
      "item": "TX ring purge at HIF_EX_INIT (downstream modem_cldma.c:2007 md_cd_clear_all_queue(md, OUT))",
      "status": "partial",
      "missing_input": "the frozen include/linux/ccci.h exposes only stop_for_ee/dhl_rx_alive; no TX-only purge entry point. TX DMA is stopped before the ACK and the rings are purged by ccci_cldma_stop() at HIF_EX_CLEARQ_DONE."
    },
    {
      "item": "Progress dump content inside the stop loops (downstream also calls ccci_mem_dump + md_cd_dump_debug_register)",
      "status": "partial",
      "missing_input": "the CLDMA object owns neither the exception smem window nor the MD bus/PC-monitor register map; it dumps engine registers via cldma_dump_register(). The core still snapshots the full MD state per stage via ccci_exception_trigger()/_sync()."
    },
    {
      "item": "Per-queue L3 interrupt bit attribution for the DHL RX set",
      "status": "partial",
      "missing_input": "no source attributes L3 RISAR/RIMSR bits to RX queue numbers (downstream only writes 0xF0F0F0F0 for the stopped set or 0xFFFFFFFF for the full stop). The close path uses the full-stop 0xFFFFFFFF values, a superset, immediately before the full stop."
    },
    {
      "item": "Hardware verification of poll durations, UL_STATUS/SO_STATUS bit semantics and the 0x00F000F0 L2RIMSR0 value",
      "status": "deferred",
      "missing_input": "no MT6735 CLDMA register manual in any available source tree and no device; constants are taken verbatim from the ROM writes and the downstream ISR."
    }
  ],
  "scaffold_changes": "none required - both frozen prototypes were sufficient. Only documentation note: the comment in include/linux/ccci.h describes NONSTOP_QUEUE_MASK 0xF0 as the DHL set, while the register writes make 0xF0 the *stopped* set (RX 0..3 = 0x0F stay alive). The implementation follows the register writes; no header edit was made.",
  "worktree_hygiene": "Only the three gap files were modified; no commit/reset/checkout/stash, no other worktree, no DTS edit, no change to include/linux/{ccci.h,aee.h,clkbuf.h} or $M/nura.config. Patch generated as a delta against the baseline blobs extracted from parity-baseline-all.patch (the baseline is uncommitted/untracked in this worktree), re-applied and byte-compared to the worktree files."
}