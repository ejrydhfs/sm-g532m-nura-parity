{
  "driver": "mtk-imgsys (MT6735/MT6737T IMGSYS/ISP platform driver)",
  "worktree": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/camera-imgsys",
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/camera-imgsys.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-imgsys.md",
  "build_log": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-imgsys-build.log",
  "files_changed": [
    "drivers/media/platform/mediatek/Kconfig (add source imgsys/Kconfig)",
    "drivers/media/platform/mediatek/Makefile (add obj-y += imgsys/)",
    "drivers/media/platform/mediatek/imgsys/Kconfig (new)",
    "drivers/media/platform/mediatek/imgsys/Makefile (new)",
    "drivers/media/platform/mediatek/imgsys/mtk-imgsys.c (new, 300 lines)",
    "drivers/media/platform/mediatek/imgsys/mtk-imgsys-regs.h (new)"
  ],
  "objects_compiled": [
    "drivers/media/platform/mediatek/imgsys/mtk-imgsys.o (arm64 LLVM, rc=0, zero warnings)",
    "drivers/media/platform/mediatek/imgsys/built-in.a (directory target, rc=0)"
  ],
  "build_commands": [
    "cp $M/nura.config .config; scripts/config -e MEDIA_SUPPORT -e MEDIA_CONTROLLER -e VIDEO_DEV -e VIDEO_V4L2_SUBDEV_API -e V4L2_FWNODE -e V4L2_ASYNC -e I2C -e REGULATOR -e COMMON_CLK -e VIDEO_CAMERA_SENSOR -e DEBUG_FS -e MEDIA_PLATFORM_SUPPORT -e MEDIA_PLATFORM_DRIVERS -e V4L_PLATFORM_DRIVERS -e VIDEO_MTK_IMGSYS; make ARCH=arm64 LLVM=1 olddefconfig; make ARCH=arm64 LLVM=1 -j2 drivers/media/platform/mediatek/imgsys/mtk-imgsys.o"
  ],
  "parity_counts": {
    "done": 7,
    "partial": 0,
    "deferred": 8
  },
  "parity_done": [
    "reg window mapping (0x15004000+0x4000, 0x1500d000+0x1000)",
    "ISP genpd MT6735_POWER_DOMAIN_ISP",
    "six IMGSYS clock gates in downstream order",
    "SCP_SYS_DIS/SCP_SYS_ISP mapped to nura SPM domains",
    "P1 CAM_SW_CTL soft reset on probe and every resume",
    "debugfs /sys/kernel/debug/mtk-imgsys/regs read-only dump (runtime-resumed)",
    "runtime + system suspend/resume via RUNTIME_PM_OPS and pm_runtime_force_*"
  ],
  "parity_deferred": [
    "CG_DISP0_SMI_COMMON (SMI/DMA path)",
    "Pass 2 soft reset",
    "CAMSV/CAMSV2 soft reset (regs outside 0x4000 ISP window)",
    "CAM0/1/2 interrupt handling (no documented enable/clear register)",
    "CAMSV0/1 interrupt handling",
    "ISP Pass1/Pass2/DSP/CQ/DMA pipeline + firmware/libcamdrv ABI",
    "V4L2 entity/video node (by design; seninf owns the single media_device)",
    "imgsys CAMINF config block access (only needed by deferred pipe code)"
  ],
  "cross_driver_notes": [
    "Register window split: imgsys maps ONLY 0x15004000+0x4000 and 0x1500d000+0x1000. SENINF (0x15008000+0x4000) and MIPIRX config (0x1500c000+0x1000) are left entirely to mtk-seninf; downstream's single 0x9000 ISP blob overlapped them and was split.",
    "CAMSV/CAMSV2 reset registers (ISP_ADDR+0x5010/+0x5810 = 0x15009010/0x15009810) fall inside the SENINF window; no driver claims them in this series - documented as an orphaned region for future CAMSV work.",
    "imgsys config/syscon 0x15000000+0x1000 stays bound to clk-mt6735-imgsys; the imgsys driver does not look it up today (only deferred pipe code would, via syscon_regmap_lookup_by_compatible).",
    "No IRQs are requested, so the 5 DT IRQs (GIC SPI 183,184,185,206,207) remain unused/free; no interrupt enable or write-to-clear register exists in the downstream source (verified by full-source grep), so enabling a level-low line would storm.",
    "Parent-file edits to drivers/media/platform/mediatek/{Kconfig,Makefile} are conflict-merge items.",
    "Kconfig has one addition beyond the requested deps: 'depends on PM' (runtime PM is the power/reset contract; without CONFIG_PM probe would leave the block unpowered).",
    "DTS fragment adds node ispsys: isp@15004000 with status = \"disabled\"; the board DTS must flip it to okay, and the node must not overlap the seninf node at 0x15008000."
  ],
  "verification": "object compile rc=0 with no warnings; patch reverse-check passes; patch contains exactly 6 files, no .config/artifacts",
  "notes": "First build produced two -Wformat warnings (%x with size_t); fixed by iterating an unsigned int offset. Fixed a clk rollback double-disable in runtime_resume before final build. Patch regenerated after the final source edit."
}