{
  "driver": "s5k5e3yx",
  "status": "complete",
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/camera-s5k5e3yx.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-s5k5e3yx.md",
  "build_log": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-s5k5e3yx-build.log",
  "files_changed": [
    "drivers/media/i2c/s5k5e3yx.c (new, 1343 lines)",
    "drivers/media/i2c/Kconfig (+10, VIDEO_S5K5E3YX)",
    "drivers/media/i2c/Makefile (+1)"
  ],
  "objects_compiled": [
    "drivers/media/i2c/s5k5e3yx.o"
  ],
  "build": "make ARCH=arm64 LLVM=1 -j2 drivers/media/i2c/s5k5e3yx.o -> exit 0, 0 warnings (needed -e MEDIA_CAMERA_SUPPORT in addition to the task's option list; otherwise MEDIA_SUPPORT_FILTER turns VIDEO_DEV/VIDEO_CAMERA_SENSOR off)",
  "parity": {
    "done": 25,
    "partial": 0,
    "deferred": 5,
    "deferred_items": [
      "digital gain (no register/feature downstream)",
      "hflip/vflip (set_mirror_flip is inside #if 0, never compiled)",
      "OTP/lens-shading NVM pages (MTK HAL-only SENSOR_FEATURE -> no V4L2 equivalent)",
      "MIPI LP->HS settle 85 (SENINF-side parameter, owner mtk-seninf)",
      "per-scenario 3-frame AE delays (framework, not sensor behavior)"
    ]
  },
  "key_facts": {
    "chip_id": "0x5e30 read from 0x0000/0x0001 (kd_imgsensor.h:184, sensor.c:216-220)",
    "i2c": "downstream write addrs 0x20/0x6c -> 7-bit 0x10/0x36; probe tries DT addr then alternate, 2 attempts each",
    "modes": "4 tables / 5 scenarios: 2576x1932@30 (pre/cap/video, 2950/2025), 2560x1920@15 cap1 (2950/2025), 640x480@120 (2950/506), 1280x960@15 (2950/4050); tables verified byte-for-byte against downstream (92/45/51/45/45 entries)",
    "link_freq": "448 MHz (896 Mbps/lane, PLL 24/6*224 = 0x0820 896) and 218 MHz (436 Mbps/lane, PLL 24/6*218/2, PLLS=1); cap1 pclk-derived 448.08 Mbps conflicts by 2.7% - PLL value chosen per instruction, documented",
    "power": "kd_camera_hw.c:325-366 / 642-683 S5K5E3YX branch ported exactly: reset low -> VCAMA 2.8V -> VCAMD 1.2V -> VCAMIO 1.8V -> 1ms -> reset high -> 1ms -> MCLK on; off in reverse with 1ms steps; cam1 rst+pdn both GPIO12 in downstream so one active-high reset-gpios",
    "controls": "EXPOSURE (1..fll+vblank-4, margin 4, VTS<=0xffff), ANALOGUE_GAIN (gain>>1, unity 0x40), VBLANK, HBLANK (RO, 2950-width), PIXEL_RATE per mode, LINK_FREQ menu, TEST_PATTERN (0x0601 + 0x3200=0)"
  },
  "integration_notes": [
    "Sensor expects clocks = <&seninf 1> (ISP_MCLK2_EN equivalent); DTS fragment in report section '## DTS-FRAGMENT' incl. placeholder remote-endpoint label seninf_cam1_in that must be renamed to mtk-seninf's endpoint",
    "mtk-seninf must program the 85 (mipi_data_lp2hs_settle_dc) settle value and the 3-frame scenario delays; the sensor subdev does not",
    "Pre-existing nit in another owner's file: drivers/regulator/mt6328-regulator.c has the ldo_vcamio MT6328_LDO_TABLE entry duplicated (lines 395-397 and 398-400); harmless, first match wins",
    "Rails required: vcama 2.8V (mt6328_vcama_reg), vcamd 1.2V (mt6328_vcamd_reg; note main sensor uses 1.0V on the shared LDO so the driver sets voltage per power-on), vcamio 1.8V (mt6328_vcam_io_reg)",
    "Driver creates no media_device; registers via v4l2_async_register_subdev_sensor and expects seninf's notifier to bind it",
    "No dts/dtsi edited; no commit made"
  ]
}