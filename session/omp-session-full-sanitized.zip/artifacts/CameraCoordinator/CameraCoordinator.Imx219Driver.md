{
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/camera-imx219.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-imx219.md",
  "build_log": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-imx219-build.log",
  "files_changed": [
    "drivers/media/i2c/imx219.c"
  ],
  "objects_compiled": [
    "drivers/media/i2c/imx219.o"
  ],
  "build_result": "CC drivers/media/i2c/imx219.o — no errors, no warnings; checkpatch 0 errors / 0 warnings",
  "parity": {
    "done": 16,
    "partial": 4,
    "deferred": 4
  },
  "summary": "Variant support added to imx219.c: new compatible samsung,grandpplte-imx219 (listed first) selects a Samsung mode set; sony,imx219 keeps the generic path unchanged. Samsung formats: 3264x2456@30 (pre/cap/normal_video, FLL 2691, LLP 3448, 416 MHz), 3280x2456@24 (cap1, 344 MHz), 816x460@120 (340 MHz), 1640x1228@15 (340 MHz); each with a verbatim cci_reg_sequence ported from the downstream *_setting() functions. Per-mode pixel_rate/link_freq controls, rate_factor forced to 1 (downstream writes FLL/shutter in lines), orientation XOR 0x03 for the module, rail-sequenced power on/off (A 2.8 -> D 1.2 -> AF 2.8 -> 2 ms -> IO 1.8 -> 3 ms -> MCLK -> 1 ms -> PDN/RST high; reverse off order), optional powerdown GPIO, 4-lane enforcement, and stream-on EINVAL when the active format or link frequency is not representable/advertised.",
  "cross_driver_notes": [
    "DTS fragment uses clocks = <&seninf 0> (seninf mclk0) and remote-endpoint <&seninf_in0> as a placeholder for the label created by the mtk-seninf DTS fragment (port@0 = cam0); the coordinator must unify that label.",
    "Seninf must also mux GPIO45 as CMMCLK0 (downstream camera default pinctrl) and expose mclk0 at 24 MHz, or probe fails on the driver's 24 MHz xclk check.",
    "Fragment uses reset-gpios = <&pio 44 GPIO_ACTIVE_HIGH> plus an &pio pinmux child; powerdown-gpios is intentionally omitted because downstream muxes GPIO44 for both cam0 rst and pnd (EBUSY if both were requested).",
    "Build config: nura.config's CONFIG_MEDIA_SUPPORT_FILTER=y hides VIDEO_DEV/VIDEO_V4L2_SUBDEV_API; the config step must disable MEDIA_SUPPORT_FILTER or enable MEDIA_CAMERA_SUPPORT, otherwise olddefconfig silently drops the requested options and the sensor driver fails to compile on v4l2_subdev_state_get_*() (affects every camera worktree)."
  ],
  "known_gaps": [
    "Link frequencies 416/344/340 MHz are [INFERENCE] from PLL_OP_MPY / (2*PREPLLCK_OP_DIV); formula validated against the two known generic rates 456/364 MHz.",
    "Downstream IMX219 powers VCAMD at 1.2 V (kd_camera_hw.c:500), not the 1.0 V stated in the task (that is the imx135/imx220 branch); 1.2 V was used.",
    "Exposure min stays 4 (downstream 2), no automatic framelength extension; analogue gain stays raw 0x0157 (downstream 64=1x table not reproduced)."
  ]
}