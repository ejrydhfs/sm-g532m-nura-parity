{
  "change": "Gated DW9807 ring-control-mode power-up on OF match data, as requested",
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/camera-lens-cal.patch",
  "patch_lines": 590,
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-lens-cal.md",
  "build_log": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-lens-cal-build.log",
  "diff_summary": {
    "drivers/media/i2c/dw9807-vcm.c": [
      "new struct dw9807_match_data { bool ring_mode; } + of_device_get_match_data() in probe stored into dw9807_dev->ring_mode (NULL match data => false)",
      "dw9807_of_table: samsung,dw9807-vcm carries .data = &dw9807_samsung_data (ring_mode=true); dongwoon,dw9807-vcm and dongwoon,dw9807 carry no .data",
      "dw9807_vcm_resume(): writes 0x02 = DW9807_CTL_RING (0x02) when ring_mode, otherwise DW9807_CTL_DIRECT (0x00) exactly as upstream",
      "dw9807_vcm_suspend(): unchanged, 0x02 = DW9807_CTL_PD (0x01)",
      "added #include <linux/of.h>; header comment states the gating so the generic path is unchanged"
    ],
    "files": "unchanged set: Kconfig, Makefile, dw9807-vcm.c, new imx219-eeprom.c (imx219-eeprom.o rebuilt and unchanged in content)"
  },
  "objects_compiled": [
    "drivers/media/i2c/dw9807-vcm.o",
    "drivers/media/i2c/imx219-eeprom.o"
  ],
  "compile_result": "both CC lines present, grep -cE 'warning:|error:' build.log = 0; checkpatch --no-tree -f on dw9807-vcm.c = 0 errors / 0 warnings",
  "counts": {
    "done": 19,
    "partial": 0,
    "deferred": 2
  },
  "report_updates": [
    "§1 VCM row now describes the match-data gating and the unchanged generic path",
    "§2 added a gating paragraph (NULL match data / Dongwoon entries -> 0x00)",
    "§3 ring-mode row marks 'Samsung module only' and states the generic path still writes 0x02=0x00",
    "§3 suspend row states power-down is unchanged for every compatible",
    "§5 inference bullet renamed to 'Ring control mode on every resume (Samsung match only)'",
    "§4 checkpatch line now covers both modified/new files"
  ],
  "cross_driver_notes": [
    "No behavior change for dongwoon,dw9807-vcm / dongwoon,dw9807 firmware: resume still writes 0x02=0x00.",
    "AF still depends on vcamaf being raised by the imx219 power_on; EEPROM reads need vcamio up and are lazy (no probe i2c)."
  ]
}