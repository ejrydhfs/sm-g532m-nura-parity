{
  "documentation_fix": "report only; no code, build, or patch changes",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-seninf.md",
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/camera-seninf.patch (unchanged, 6 files, still matches worktree)",
  "changes": [
    "§3 mapping table: vcama-supply / vcamd-supply / vcamio-supply / vcamaf-supply (imx219 all four in rail order; S5K5E3YX has no vcamaf)",
    "§3: reset-gpios/powerdown-gpios are GPIO_ACTIVE_HIGH; value 1 = out-of-reset/enabled (matches downstream output-high ON level)",
    "§6.2 sensor examples: same supply names/order and ACTIVE_HIGH reset/powerdown; per-sensor pinctrl-names/pinctrl-N removed",
    "new note: do not define both the SENINF camera_pins_default state and per-sensor pinctrl states for GPIO44/GPIO12/GPIO45/GPIO46; merged DTS keeps the SENINF default state and drops sensor-local rst/pnd states",
    "§6.1 per-sensor pin groups marked reference-only (downstream mapping record, not used by the merged DTS)"
  ]
}