{
  "compile": {
    "command": "make ARCH=arm64 LLVM=1 -j2 drivers/misc/mediatek/vcodec/vcodec-venc.o",
    "result": "CC vcodec-venc.o clean, zero warnings; W=1 rebuild clean; checkpatch -f 0 errors 0 warnings 314 lines"
  },
  "files_changed": [
    "drivers/misc/mediatek/vcodec/vcodec-venc.c (new, 314 lines)"
  ],
  "fixes_applied": [
    "probe: devm_pm_domain_attach_list(dev, NULL, &pd_list) after clocks, accepts -EEXIST, -ENODEV when no domains, #include <linux/pm_domain.h>",
    "MODULE_DEVICE_TABLE(of, vcodec_venc_of_match) with #include <linux/module.h>; no lifecycle macros"
  ],
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/vcodec-venc.patch",
  "patch_verified_current": true,
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/vcodec-venc.md",
  "status": "done",
  "worktree": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/vcodec-venc"
}