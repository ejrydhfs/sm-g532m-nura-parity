{
  "status": "done",
  "compat_loading_info_fix": {
    "change": "dedicated struct vcodec_compat_cpu_loading_info (3x __u64 + __u32) added to the compat block; VCODEC_GET_CPU_LOADING_INFO on the 32-bit path now fills the internal struct via vcodec_ioc_cpu_loading_info() and writes the four fields with put_user, so nothing past inst_count is written from the 64-bit layout",
    "comment": "\"identical layout on both word sizes\" replaced with an accurate note that offsets are shared but the tail padding belongs to the caller",
    "correction": "measured sizeof of the 32-bit shape = 32 (clang --target=arm-linux-gnueabi and -mabi=aapcs-linux both emit 0x20), i.e. AAPCS rounds up to 8-byte alignment, so the ROM struct is also 32 bytes and the previous copy did not overflow; the field-wise copy removes the padding dependency regardless. Reported back to the coordinator."
  },
  "verification": "make ARCH=arm64 LLVM=1 -j2 (W=1 also) drivers/misc/mediatek/vcodec/vcodec-core.o -> CC, exit 0, zero warnings; checkpatch --strict -f: 0 errors 0 warnings, vcodec-core.c 1159 lines, include/uapi/linux/vcodec.h 227 lines",
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/vcodec-core.patch (9 files, 1654 lines, no vcodec.h)",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/vcodec-core.md (new \"32-bit payload handling\" subsection with the sizeof measurement, parity row 21 updated, line counts refreshed)",
  "prior_fixes_intact": [
    "power_on -> owner/type -> publish hw_locked -> enable_irq with full undo on failure",
    "JPEG_ENC lock records owner only (no power/unmask); WAITISR rejects JPEG with -EINVAL",
    "WAITISR timeout -EFAULT, -ERESTARTSYS for signals, no -2 path",
    "CONFIG_COMPAT=n guard around all compat types/helpers/function and the .compat_ioctl initialiser",
    "symbol-export table in report (kcpustat_field/cpu_fetch, sched_clock, nr_cpu_ids, pin/unpin, remap_pfn_range, misc_register)"
  ]
}