{
  "status": "complete",
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/wcn-gap-gps.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/wcn-gap-gps.md",
  "files_changed": [
    "drivers/misc/mediatek/connectivity/gps/gps.c",
    "drivers/misc/mediatek/connectivity/gps/gps.h (new)",
    "drivers/misc/mediatek/connectivity/gps/stp_chrdev_gps.c (new)",
    "drivers/misc/mediatek/connectivity/gps/Makefile",
    "drivers/misc/mediatek/connectivity/gps/Kconfig"
  ],
  "summary": "Vendor /dev/stpgps char device (dynamic major, class + device_create) on the single STP GPS channel, exclusively shared with the GNSS device. Blocking read/write with MTKSTP_BUFFER_SIZE bounds, downstream ioctl numbers 0/1/6/7/8/9/10/11 + compat_ioctl, reset -EIO wakeups, rfkill/PM/WMT power paths shared. GNSS device retained and now optional at build time.",
  "compile": {
    "gnss_y": "gps.o, stp_chrdev_gps.o, LD mtk_wcn_gps.o: 0 errors / 0 warnings",
    "gnss_n": "gps.o, stp_chrdev_gps.o, LD mtk_wcn_gps.o: 0 errors / 0 warnings",
    "module_link": "LD [M] mtk_wcn_gps.ko succeeded with KBUILD_MODPOST_WARN=1; unresolved-symbol warnings only, due to absent tree-wide Module.symvers (no full kernel build)"
  },
  "closed": [
    "vendor chardev ABI",
    "exclusive owner arbitration / shared RX + suspend logic",
    "blocking raw read/write",
    "ioctl 0,1,6,10 and -EFAULT default",
    "reset handling for vendor I/O",
    "GNSS competitive/optional build"
  ],
  "blocked": [
    "ioctl 9 returns -EOPNOTSUPP: no MT6735 nvmem provider/offset binding (exact DT in report; downstream efuse 0x10206000+0x198, mtk-efuse.c matches only mt8173/mt8186)",
    "ioctls 7/8/11 depend on peer WcnGap.WmtGap landing mtk_wcn_wmt_ic_info_get()/mtk_wcn_wmt_co_clock_flag_get() additively in mtk_wcn_wmt.h + wmt_api.c (peer confirmed; values exist in wmt_lib_get_icinfo/wmt_lib_co_clock)",
    "GNSS read error injection impossible (gnss_operations has no read-error callback); GNSS buffered data not dropped"
  ],
  "dts": "Fragment (not applied): / { soc { gps: gps { compatible = \"mediatek,mt3326-gps\"; }; }; };",
  "notes": "No DTS files edited. Patch contains only gps/ files, no artifacts/binaries. Build checks used a temporary, reverted declaration block identical to the WMT peer's promised additive API; it is not in the patch. Integration must apply the wcn-gap-wmt patch before this one."
}