{
  "status": "complete",
  "round": "rem2 internals gap-closure",
  "baseline_verified": {
    "patch": "$M/patches/parity-baseline-all.patch",
    "applies_to": "046883c0c2b956fd7436d3c1156f25512d1f6a90",
    "result": "clean git apply --check; 247 files +85795/-589"
  },
  "leaves": [
    {
      "gap": "camera IOPIPE/TPIPE/P1/P2 tuning + pipeline programming",
      "worktree": "$M2/worktrees/rem2-iopipe",
      "patch": "$M/patches/rem2-iopipe.patch",
      "patch_bytes": 108850,
      "diffstat": "16 files, +3576 -0",
      "report": "$M/logs/rem2-iopipe.md",
      "result": "done (userspace): 6 libcam.iopipe.so port/path tables with proved record widths, 25-module/90-instance/24-NVRAM-type ISP_MGR catalogue, 19 machine-verified TPIPE enable-word records over 13 modules (0x4004/0x4008/0x4010/0x4014/0x4018), CQ0C word builder, 15 tuning symbols (9 file-backed) + per-sensor generators identified",
      "verification": "make rc0, make check rc0 (41 checks, all re-read from the shipped ELFs); one BNR record independently cross-checked against llvm-objdump",
      "kernel_change": "none (no constant grounded kernel-side)"
    },
    {
      "gap": "clk-buf driver + CCCI RPC 0x4008 + consumers",
      "worktree": "$M2/worktrees/rem2-clkbuf",
      "patch": "$M/patches/rem2-clkbuf.patch",
      "patch_bytes": 28470,
      "diffstat": "8 files, +814 -17",
      "report": "$M/logs/rem2-clkbuf.md",
      "result": "done: new drivers/misc/mediatek/clkbuf (platform driver on mediatek,rf_clock_buffer + scpsys syscon; BSI word; spm_ap_bsi_gen and spm_ap_mdsrc_req ported; /sys/power/clk_buf; late_initcall), frozen API implemented and EXPORT_SYMBOL_GPL, RPC 0x4008 returns downstream payload, CONSYS co-clock CONN buffer wired; GPS correctly not wired (MT6580-only)",
      "verification": "objects rc0 W=1 clean (mt_clkbuf_ctl.o, ccci_rpc.o, consys_mt6735.o)"
    },
    {
      "gap": "AEE/AED DB client interface",
      "worktree": "$M2/worktrees/rem2-aee",
      "patch": "$M/patches/rem2-aee.patch",
      "patch_bytes": 69248,
      "diffstat": "12 files, +2378 -0",
      "report": "$M/logs/rem2-aee.md",
      "result": "done: /dev/aed0 (EE) + /dev/aed1 (KE) misc devices, 24-byte AE_Msg protocol, EE queue/worker, detail path with the CCCI LOG section via aee_dump_ccci_debug_info(), the ioctls libaed.so actually uses (296-byte 0x41287007 + 76-byte 0x404c7007), exported aed_{md,md32,scp,combo}_exception_api, CCCI dump path wired with DB_OPT_DEFAULT|DB_OPT_FTRACE, uapi ABI header, aee-db tool",
      "verification": "kernel objects rc0 W=1 clean; tool make/make check rc0 (ABI KATs)"
    },
    {
      "gap": "CLDMA stop_for_ee + DHL RX-alive window",
      "worktree": "$M2/worktrees/rem2-cldma",
      "patch": "$M/patches/rem2-cldma.patch",
      "patch_bytes": 16344,
      "diffstat": "3 files, +306 -18",
      "report": "$M/logs/rem2-cldma.md",
      "result": "done: ccci_cldma_stop_for_ee() and ccci_cldma_dhl_rx_alive() implemented register-for-register, HIF_EX_INIT/HIF_EX_CLEARQ_DONE rewired (stop -> ACK; 2 s window -> close -> full stop -> dump -> CLEARQ_ACK), stale SCAFFOLD comment removed, AEE timeout notification only via extern",
      "verification": "objects rc0; sequence cross-checked against ROM md_cd_ccif_work @0xc0528558-0xc0528928 and md_cd_ccif_delayed_work @0xc0527c80"
    }
  ],
  "frozen_interfaces_added": [
    "include/linux/aee.h (new, config-gated prototypes)",
    "include/linux/clkbuf.h (new)",
    "include/linux/ccci.h (appended ccci_cldma_stop_for_ee / ccci_cldma_dhl_rx_alive)"
  ],
  "integration": {
    "tree": "$M2/worktrees/rem2-integration",
    "order": [
      "rem2-clkbuf",
      "rem2-cldma",
      "rem2-iopipe",
      "rem2-aee"
    ],
    "conflict": "only drivers/misc/mediatek/{Kconfig,Makefile}; resolved as the union (aee/ before clkbuf/) with git apply -C1 --include=...",
    "config": "scripts/config -e MTK_CLKBUF -e MTK_AEE_FEATURE on the known-good full-build .config; nura.config untouched",
    "dts_edits": "none (grep of all four patches: 0 arch/ paths)"
  },
  "builds": {
    "kernel_objects": "all touched objects rc0 at W=1; only pre-existing kernel-doc warnings (ccci_ccif.c:146, ccci_ringbuf.c:209)",
    "full_kernel": "make ARCH=arm64 LLVM=1 -j2 rc0, 0 error / 0 warning lines, vmlinux + Image + modules built (mtk-isp.ko, mtk_wcn_wmt.ko, ...)",
    "link_contract": "ccci_ccif.o U aed_md_exception_api; aed-main.o T + EXPORT_SYMBOL_GPL; aed-main.o U aee_dump_ccci_debug_info (exported by ccci_core); Module.symvers exports clk_buf_ctrl/get_swctrl_status/init; mtk_wcn_wmt.ko U clk_buf_ctrl",
    "userspace": "tools/mediatek/camera/iopipe make+check rc0; tools/mediatek/aee make+check rc0"
  },
  "coordinator_report": "$M/logs/rem2-coordinator.md",
  "dts_fragment": "root-level rf_clock_buffer node {compatible=\"mediatek,rf_clock_buffer\"; mediatek,clkbuf-quantity=<4>; mediatek,clkbuf-config=<2 1 1 1>; mediatek,spm=<&scpsys> /*[INFERENCE]*/; status=\"okay\";}",
  "deferred": [
    "camera per-module register VALUES and AE/AWB stat configs: no static address->value tables (runtime NVRAM/OTP)",
    "camera enable words for MIXER3/NR3D/MFB/G2C_SHADE: no register immediates in their apply() bodies",
    "camera FLK window / FKO DMA registers: methods are 2-byte aliases inside Hal3AAdapter::doDataCb, no implementation in libcam.hal3a.v3.so",
    "camera DSP: absent from every available source (grep -aic dsp = 0 in all six libs); post-processing is P2/DIP - nothing invented",
    "per-sensor ISP NVRAM defaults: generated by functions, not stored blobs",
    "clkbuf NFC consumer: no NFC driver in Nura (downstream mt6605.c:890,897); API exported",
    "clkbuf rf_clock_buffer DTS node: fragment returned, not applied (shared DTS owner)",
    "AEE AE_IND raise path over com.mtk.aee.aed: closed-source AED daemon absent from system.raw.img (only libaed.so client shipped)",
    "AEE ipanic/mrdump/dram-console/red-screen/RT-monitor: out of scope, own port required",
    "AEE 296-byte thread-reg payload inner layout: [INFERENCE] from arm64 user_pt_regs (only command number and size are observable)",
    "CLDMA TX ring purge at HIF_EX_INIT: partial - still done by the full stop at HIF_EX_CLEARQ_DONE; needs hardware validation",
    "CLDMA L3 per-queue bit attribution: unavailable in any source; full-stop values used when closing the window"
  ],
  "notes": [
    "parity-baseline-all.patch adds inert wmt_api.c.rej / mtk_wcn_wmt.h.orig / mtk_wcn_wmt.h.rej artifacts; recommend removing them from the baseline (content already present in wmt_api.c)",
    "no commit, no reset, no DTS edit, no other worktree touched; all leaf artifacts remain in $M2/worktrees/rem2-*"
  ]
}