{
  "status": "complete",
  "leaf": "rem-wcn-fm-i2s",
  "worktree": "$M/worktrees/rem-wcn-fm-i2s",
  "deliverables": {
    "patch": "$M/patches/rem-wcn-fm-i2s.patch",
    "report": "$M/logs/rem-wcn-fm-i2s.md",
    "files_changed": 10,
    "binary_hunks": 0,
    "touches_sound": false,
    "committed": false
  },
  "implemented": {
    "dai_naming": "component \"mt6627-fm-i2s\"; DAI .name \"mt-soc-fm-i2s-dai-codec\" (AudDrv_Def.h:307); streams FM_I2S_Playback/FM_I2S_Capture (AudDrv_Def.h:342-343)",
    "codec": "fixed 32000 Hz / S16_LE / 2ch / I2S+NB_NF+CBC_CFC enforced with -EINVAL/-EOPNOTSUPP; no DAPM widgets; -ENODEV when unbound; no snd_soc_register_card()",
    "chip": "i2s_set/get/info with 0x9B=0xF9AB, host 0x80101054=0x00003f35, disable masks host 0x6000 / 0x9B 0xFFF8; port state mirrors power-up/power-down and resyncs after tune paths",
    "ioctl": "FM_IOCTL_I2S_SETTING (0xf5,33) / FM_IOCTL_GET_I2S_INFO (0xf5,41), 12-byte payload from new uapi header, -EINVAL/-EOPNOTSUPP/-EAGAIN/-ENODEV, compat_ioctl32",
    "build_matrix": "SND_SOC=n/m/y all exit 0, W=1, zero warnings/errors; i2s.o present only for y/m",
    "userspace": "tools/mediatek/wcn/fm_i2s (get/set/--selftest), host -Wall -Wextra -Werror, make check PASS (37 checks)"
  },
  "verification_run": [
    "make ARCH=arm64 LLVM=1 W=1 ... -j2 drivers/misc/mediatek/connectivity/fm/mtk_wcn_fm.o for SND_SOC=y, =m, =n",
    "make -C tools/mediatek/wcn/fm_i2s check"
  ],
  "environment_notes": [
    "/tmp tmpfs was full from other agents; kernel builds used TMPDIR=$M/tmp/remwcn/tmp, userspace Makefile keeps temporaries in .tmp",
    "no full kernel build / tree-wide modpost; standalone .ko modpost remains the documented environment limitation",
    "latest MTK_WCN_FM cannot reach =y while MTK_WCN_WMT is =m in this tree; required n/m/y matrix with FM=m was tested"
  ],
  "hardware_unverified": [
    "actual FM I2S audio on silicon",
    "register read-back semantics (derived from write/clear masks)",
    "card binding with the audio leaf's AFE DAI"
  ]
}