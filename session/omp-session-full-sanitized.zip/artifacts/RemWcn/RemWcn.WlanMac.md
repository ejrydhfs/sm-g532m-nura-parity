{
  "phase": 2,
  "leaf": "rem-wcn-wlan",
  "status": "complete",
  "deliverables": {
    "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/rem-wcn-wlan.patch",
    "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/rem-wcn-wlan.md",
    "files": [
      "Kconfig",
      "Makefile",
      "wlan_ahb.c",
      "wlan_hif.h",
      "wlan_main.c",
      "wlan_mac.c/h",
      "wlan_mgmt.c",
      "wlan_netdev.c",
      "wlan_txrx.c",
      "wlan_cmd.c/h (new)"
    ]
  },
  "implemented": {
    "command_channel": "wlan_cmd.c: WIFI_CMD_T (8 bytes) + payload written to TC4 / HIF port 1 (MCR_WTDR1), length DW-padded, pkt type HIF_TX_PKT_TYPE_CMD, one TC4 credit per command; one command in flight under a mutex; result matched by EVENT_ID_CMD_RESULT + WIFI_EVENT_T.ucSeqNum; 5 s wait_for_completion timeout (no polling in atomic context); aborted with -ENETDOWN on fw-down/reset, cancelled with -ECANCELED on local disconnect without poisoning the channel",
    "event_rx": "HIF_RX_PKT_TYPE_EVENT buffers are now dispatched to mtk_wlan_cmd_event() from mtk_wlan_mac_rx(): WIFI_EVENT_T starts at buffer offset 0 (first DW shared with HIF_RX_HEADER_T) and its body at EVENT_HDR_SIZE=8; EVENT_ID_CMD_RESULT is consumed, other events ignored",
    "association_sequence": "connect worker: CMD_BSS_ACTIVATE_CTRL active=1 -> CMD_UPDATE_STA_RECORD state 1 -> auth -> assoc -> CMD_UPDATE_STA_RECORD state 3 (AID, RCPI, need-resp) -> CMD_SET_BSS_INFO connected -> cfg80211 result; failure/cancel paths tear the firmware state down",
    "bss_info": "CMD_SET_BSS_INFO (0x16) with SSID/BSSID, connection state, OP_MODE_INFRASTRUCTURE, operational/basic rate sets from the AP IEs, PHY type set/non-HT basic PHY, auth mode 0, encryption disabled, own MAC, STA index, and the full CMD_SET_BSS_RLM_PARAM_T block (BAND_2G4, primary channel, SCN, ERP protection, short preamble/slot, check id 0x72)",
    "sta_record": "CMD_UPDATE_STA_RECORD (0x17) index 0 (first free cnmStaRecAlloc slot), STA_TYPE_LEGACY_AP, BSSID, AID masked per assoc.c:1183-1200 workaround, listen interval 10, desired PHY/rate sets, state 1 and state 3 (HT/UAPSD fields zero for this non-QoS open association)",
    "teardown": "CMD_SET_BSS_INFO disconnected -> CMD_REMOVE_STA_RECORD (0x18) -> CMD_BSS_ACTIVATE_CTRL active=0, also from fw-down/link-down when the firmware is still alive",
    "data_tx": "data frames now go out in downstream's default 802.3 mode (fgIs802_11=false, wlan_header_length=ETH_HLEN, EtherType offset 14) and carry the real STA record index in the HIF header; the host 802.11 data builder was deleted; management frames keep the host 802.11 builder",
    "ap_params": "operational/basic rate sets, PHY type set, non-HT basic PHY, ERP protection and short preamble/slot derived from the cfg80211 BSS IEs (rate.c:80-254/bss.c:566-680/rlm.c:1227-1314)"
  },
  "compile": {
    "command": "make ARCH=arm64 LLVM=1 W=1 AR=ar NM=aarch64-linux-gnu-nm OBJCOPY=aarch64-linux-gnu-objcopy OBJDUMP=aarch64-linux-gnu-objdump READELF=aarch64-linux-gnu-readelf STRIP=aarch64-linux-gnu-strip -j2 drivers/misc/mediatek/connectivity/wlan/mtk_wcn_wlan.o",
    "configs": [
      "CONFIG_RFKILL=y, CONFIG_CFG80211=y, CONFIG_MTK_WCN_WLAN=m",
      "CONFIG_RFKILL unset, CONFIG_CFG80211=y, CONFIG_MTK_WCN_WLAN=m (nura default; GPS/FM disabled because their Kconfig selects RFKILL)"
    ],
    "result": "both: CC [M] wlan_main.o wlan_ahb.o wlan_fw.o wlan_mac.o wlan_netdev.o wlan_mgmt.o wlan_txrx.o wlan_cmd.o + LD [M] mtk_wcn_wlan.o, zero warnings, zero errors",
    "hygiene": [
      "grep -nE 'TODO|FIXME|XXX|stub|not implemented' over all touched files: no matches",
      "git diff HEAD --check: clean",
      "patch: 0 binary hunks, 12 WLAN source files only, reverse-applies cleanly",
      "no commits made"
    ]
  },
  "citations": {
    "cmd_framing": [
      "include/nic_cmd_event.h:919-929 WIFI_CMD_T; hif_tx.h:98 CMD_HDR_SIZE",
      "nic/nic_tx.c:1700-1740 nicTxCmd (port 1, header fields, TFCB_FRAME_PAD_TO_DW hif_tx.h:206)",
      "common/wlan_lib.c:2037-2098 wlanSendCommand (TC4, one credit, pending for need-resp)",
      "nic/nic.c:1594-1609 nicIncreaseCmdSeqNum; nic.c:1406-1437 nicGetPendingCmdInfo",
      "nic_cmd_event.h:1414-1494 CMD_BSS_ACTIVATE_CTRL / CMD_SET_BSS_RLM_PARAM_T / CMD_SET_BSS_INFO / CMD_UPDATE_STA_RECORD_T / CMD_REMOVE_STA_RECORD_T",
      "nic_cmd_event.h:678-702 CIDs 0x15/0x16/0x17/0x18"
    ],
    "cmd_completion": [
      "nic_cmd_event.h:932-941 WIFI_EVENT_T; nic_cmd_event.h:660 EVENT_HDR_SIZE=8; nic_cmd_event.h:613 first DW shared with HIF_RX_HEADER_T",
      "nic_cmd_event.h:1175-1179 EVENT_CMD_RESULT status 0/1/2",
      "nic/nic_rx.c:1750-1830 nicRxProcessEventPacket matches EVENT_ID_CMD_RESULT by ucSeqNum",
      "gl_kal.c:2445-2449 the documented 5 s command/OID timeout"
    ],
    "producers": [
      "nic/nic.c:1902-1958 nicActivateNetwork/nicDeactivateNetwork",
      "nic/nic.c:1966-2103 nicUpdateBss (+ eAuthMode-1, ucStaRecIdxOfAP)",
      "mgmt/cnm_mem.c:1032-1056 cnmStaRecChangeState; cnm_mem.c:1129-1215 cnmStaSendUpdateCmd; cnm_mem.c:1220-1238 cnmStaSendRemoveCmd",
      "mgmt/ais_fsm.c:1372-1384 state 1 before auth; ais_fsm.c:1873/1885 network activate; ais_fsm.c:3353-3358 state 3 -> nicUpdateBss; ais_fsm.c:4072-4080 BSS disconnect",
      "mgmt/rate.c:80-254, mgmt/bss.c:566-680, mgmt/rlm.c:1713-1745 AP/RLM parameters",
      "ROM symbols: wlanSendCommand c055e238, wlanProcessCommandQueue c055e5fc, nicTxCmd c0583698, nicUpdateBss c057fa68, nicActivateNetwork c057f840, cnmStaRecChangeState c05c9c74, nicRxProcessEventPacket c05879dc, cmdBufAllocateCmdInfo c058b6dc"
    ],
    "data_tx_mode": [
      "nic/nic_tx.c:2000-2018 (OS data: fgIs802_11=FALSE, ucMacHeaderLength=ETH_HLEN)",
      "nic/nic_tx.c:1404-1416 (non-802.11 EtherType offset)",
      "nic/nic_tx.c:1447-1448 / 1461-1474 (format flag and ack/basic-rate flags)"
    ]
  },
  "boundaries_and_missing": [
    {
      "item": "firmware acceptance of the command PDUs and of 802.3 data with the installed STA record index",
      "status": "hardware-only",
      "detail": "frame layout, CIDs, payloads and ordering are copied from downstream and corroborated by ROM symbols; actual acceptance by this firmware revision cannot be verified without a phone"
    },
    {
      "item": "CMD_REMOVE_STA_RECORD on AIS teardown",
      "status": "intentional extension, documented",
      "detail": "downstream AIS frees the STA record without chip sync (cnmStaRecFree(..., FALSE), ais_fsm.c:4975) and uses the remove command only for P2P/TDLS; this port sends the documented command after SET_BSS_INFO disconnected, and ignores a possible reject event"
    },
    {
      "item": "per-channel RF tuning during scan",
      "status": "deferred",
      "detail": "needs CMD_ID_SCAN_REQ (scan_fsm.c:377-455); probe requests are emitted per requested channel but the firmware keeps its current RF channel"
    },
    {
      "item": "multicast filter, WoWLAN/suspend behaviour, RCPI accuracy, firmware blob contents",
      "status": "unchanged partial/unverified",
      "detail": "no hardware programming path for the filter; no WoWLAN; RCPI and blob behaviour are hardware-only unknowns"
    }
  ],
  "notes": [
    "Kconfig feature text was already accurate for this change set (station-only, 2.4 GHz, open networks, software scan) and was left unchanged",
    "no DTS edits; the wifi@180f0000 fragment is unchanged in the report",
    "report §5 was rewritten: the former host-802.11-data and STA_REC_INDEX_NOT_FOUND inferences are now backed by downstream code (802.3 TX + real STA index); remaining unknowns are hardware-only"
  ]
}