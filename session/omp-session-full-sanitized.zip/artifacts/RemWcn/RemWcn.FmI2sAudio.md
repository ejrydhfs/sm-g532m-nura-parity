{
  "leaf": "rem-wcn-fm-i2s-audio",
  "status": "done",
  "revision": "four-route correction applied (removed invented I00->O14 and I01->O13 cross-connections); guard and everything else as before",
  "worktree": "$M/worktrees/rem-wcn-fm-i2s-audio (HEAD 9b66b7790, no commit)",
  "deliverables": {
    "patch": "$M/patches/rem-wcn-fm-i2s-audio.patch — 27841 bytes, 7 files, +564/-13, 0 binary hunks, sound/soc/mediatek/mt6735/ only, matches git diff HEAD",
    "report": "$M/logs/rem-wcn-fm-i2s-audio.md — §1 table, §2.3 four-route citations, §3 row 5, §4/§4.1 (both configs + fresh preproc table), §5.1 greps, §8 stat"
  },
  "routing": {
    "routes": "exactly the four downstream routes: I00->O13 (AFE_GAIN1_CONN2 bit 2), I01->O14 (bit 16), I10->O03 (AFE_GAIN1_CONN bit 8), I11->O04 (bit 10)",
    "prepare": "mt6735-dai-fm-i2s.c:255-264, mask == value, four bits only",
    "teardown": "mt6735-dai-fm-i2s.c:173-178, same four masks cleared to 0",
    "removed": "AFE_CONN_FM_I2S_I00_TO_O14 and AFE_CONN_FM_I2S_I01_TO_O13 deleted; grep for both in the directory returns none",
    "comment": "regs header now cites mt_soc_pcm_fm_i2s.c:278-285 / close :246-254 with the four register/bit citations; the unused [I00][O14]bit15 and [I01][O13]bit3 table entries are documented as deliberately not programmed"
  },
  "compile": {
    "FM=m": "exit 0, 8x CC [M] + LD [M] snd-soc-mt6735-afe.o + LD [M] snd-soc-mt6735-mt6331.o, W=1 0 warnings; preproc .i: FM_I2S_RX_Playback=1, mt-soc-fmi2S-driver=1",
    "FM=n": "exit 0, same 8x CC [M] + both LD [M], W=1 0 warnings; 0 FM strings in mt6331.o; preproc .i 0/0",
    "checkpatch": "mt6735-dai-fm-i2s.c 0/0 (395 lines); mt6735-mt6335-mt6331.c 0/0 (575 lines)",
    "logs": [
      "$M/logs/rem-wcn-fm-i2s-audio-build.log",
      "-build-fm_m.log",
      "-build-fm_n.log",
      "-preproc-fm_m.log",
      "-preproc-fm_n.log",
      "-objects.log"
    ]
  },
  "unchanged": {
    "guard": "#if IS_ENABLED(CONFIG_MTK_WCN_FM) around DAILINK_DEFS + link entry (mt6331.c:131-137, :252-266)",
    "dai": "mt-soc-fmi2S-driver, memif-less, id 10, existing AFE component",
    "exclusivity": "AFE_I2S_CON 0x0018 -EBUSY FM<->I2S0 both ways; FM refuses while voice_afe_users>0; teardown never releases another owner's DAC",
    "asrc": "bypass AFE_CONN4 bit 30 = 1 (downstream mt_soc_afe_control.c:2274)",
    "naming": "frozen names, mt-snd-card, mediatek,mt6735-sound, playback_only, dai_fmt",
    "dts": "none"
  },
  "bindings": {
    "afe_dai": "MT6735_AFE_FM_I2S_DAI_NAME (afe-common.h:97, dai-fm-i2s.c:383)",
    "machine": "mt6331.c:133 COMP_CPU, :134-135 COMP_CODEC, :259-260 link/stream",
    "peer": "rem-wcn-fm-i2s.patch names match; component-only, no card",
    "single_card": "soc_probe_component() soc-core.c:1602-1622"
  },
  "environment_note": "/tmp tmpfs fullness caused one transient build failure; all later builds used TMPDIR on the work disk"
}