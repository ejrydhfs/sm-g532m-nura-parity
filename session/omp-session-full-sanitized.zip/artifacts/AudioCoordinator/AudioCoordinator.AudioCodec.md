{
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/mt6331-codec.patch (git diff --binary, 1959 lines, 5 files, 1907 insertions; new files included via git add -N, nothing committed). Verified with `git apply --check --reverse` against the worktree.",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/mt6331-codec.md - 7 required sections incl. parity matrix, inferred items, and the exact DTS-FRAGMENT (mt6328 codec child node + optional GPIO80 de-pop pinctrl group for the board DTS).",
  "compile_result": "cd $M/worktrees/audio-codec; PATH=$M/llvmpkg/usr/bin:$M/bin:$PATH; cp $M/nura.config .config; ./scripts/config --enable SOUND --enable SND --module SND_SOC --module SND_SOC_MT6331; make ARCH=arm64 LLVM=1 olddefconfig  -> CONFIG_SND=y CONFIG_SND_SOC=m CONFIG_SND_SOC_MT6331=m; make ARCH=arm64 LLVM=1 -j2 sound/soc/codecs/mt6331.o drivers/mfd/mt6397-core.o  ->  'CC [M] sound/soc/codecs/mt6331.o' and 'CC drivers/mfd/mt6397-core.o', exit 0, no errors, no warnings. Also clean with W=1. Objects: mt6331.o 335216 bytes, mt6397-core.o 187864 bytes (contains 'mt6328-codec' / 'mediatek,mt6328-codec'). Full kernel build and modpost not run (out of scope; single-module link needs vmlinux/Module.symvers).",
  "files_changed": [
    "sound/soc/codecs/mt6331.c (new, 1714 lines)",
    "sound/soc/codecs/mt6331.h (new, 179 lines)",
    "sound/soc/codecs/Kconfig (+9: config SND_SOC_MT6331, depends on MFD_MT6397)",
    "sound/soc/codecs/Makefile (+2: snd-soc-mt6331-y, obj-$(CONFIG_SND_SOC_MT6331))",
    "drivers/mfd/mt6397-core.c (+3: one mt6328-codec cell appended to mt6328_devs[]; no reordering)"
  ],
  "deferred": [
    "Voice call DAIs (MD1/MD2), TDM (task-deferred)",
    "VOW analog+digital (task-deferred)",
    "HP impedance detection (task-deferred)",
    "FM paths I2S2/MRG/FM_I2S (task-deferred)",
    "Speaker protection/SPKL IRQ + current sensing SPK_CON12 (task-deferred)",
    "OTP/efuse HP-offset trim and AFE_DL_DC_COMP_CFGx DC compensation - efuse read is ROM/nvmem only, no safe Nura source; nothing written",
    "Audio DAC/ADC digital volume - no documented scale (AFE_DL_SDM_CON1 is a fixed 0x001e write), no control invented",
    "External AW8736 speaker amp (extspkamp GPIO117) - board-level GPIO policy; belongs to machine/board layer",
    "Class-AB / receiver speaker modes, 2-in-1 headset-speaker, lineout, DMIC - only reachable through vendor-private userspace controls not used here",
    "CLK_BUF_AUDIO (audckbufEnable/clk_buf_ctrl) - no clk-buffer driver in this tree; calls omitted, flagged as a missing prerequisite in the clock/AFE slice",
    "13 of the vendor's 16 DAIs (stub, loopback, merge, FM, voice, HP-impedance) - only tx/tx2/rx implemented"
  ],
  "notes": "Naming: vendor driver/symbols are mt6331 but the silicon is MT6328; only the MT6328 register map is implemented (documented in the header, the report and the Kconfig help). Regmap is the parent PMIC regmap from mt6397_chip->regmap (16-bit reg / 16-bit val, offsets 0x0000-0xFFFF), exactly mirroring downstream Ana_Set_Reg() = pwrap read-modify-write; no raw pwrap calls. Evidence: ROM mt6331_codec_probe @0xc0864334 with the inlined init sequence at 0xc0864460-0xc08644bc (six read-modify-writes) and InitCodecDefault @0xc08642d4 (MICAMP=3, HPOUT=8) disassembled with capstone; every numeric (reg,value,mask) triple in the driver (166 calls) was script-compared against the 307 Ana_Set_Reg() triples in mt_soc_codec_63xx.c/mt_soc_codec_speaker_63xx.c and all 166 matched. Component name 'mt-soc-codec'; DAIs mt-soc-codec-tx-dai, mt-soc-codec-tx-dai2 (per amendment, independent DAI object + AIF_RX2 widget, stream MultiMedia2_PLayback; downstream has no per-DAI register programming - both DAIs share the single PMIC downlink voice and the single DAC DAPM node), mt-soc-codec-rx-dai. Controls (8): Headset Volume (stereo TLV, ZCD_CON2 +8..-10 dB 1 dB steps), Earpiece Volume (TLV, ZCD_CON3), Speaker PGA Gain (vendor 16-entry enum, SPK_ANA_CON0), Mic Amp 1/2 Volume (TLV, 6 dB steps, AUDENC_ANA_CON10), Mic Bias Voltage (AUDMICBIASVREF), MICBIAS1/2 Mode (value enums over the DCC field: ACC/DCC, DCC ECM Single, DCC ECM Diff). DAPM: AIF_RX/AIF_RX2 -> DAC -> Headphone/Earpiece/Speaker Amp -> HEADSET/EARPIECE/SPEAKER; MICBIAS1/2 -> MIC1/MIC2/Headset Mic -> PGA L/R -> ADC -> AIF1TX, with ADC Supply. ASoC widget ordering reproduces the vendor power-up/down order in all four directions (documented). set_jack registers a blocking notifier that switches the second mic bias + AIN1 headset-mic path on SND_JACK_MICROPHONE. Suspend resumes by replaying every saved block (state bitmask), extending SetAnalogSuspend which only handles the output amps."
}