{
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/audio-jack.patch",
  "report": "Full report: /run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/audio-jack.md. Machine driver complete: card \"mt-snd-card\", compatible \"mediatek,mt6735-sound\", four contract-exact non-DPCM links (MultiMedia1 dl1->tx-dai playback, MultiMedia2 ul1->rx-dai capture, MultiMedia_DL2 dl2->tx-dai playback, I2S0OUTPUT i2s0->snd-soc-dummy bidirectional with I2S|NB_NF|CBC_CFC citing AFE I2S_CON programming). ASoC jack created in MultiMedia1 init (Headset Jack, pins Headphone/Headset Mic, BTN_0..3 with KEY_PLAYPAUSE/VOICECOMMAND/VOLUMEUP/VOLUMEDOWN), snd_soc_component_set_jack on rtd0 codec (-ENOTSUPP tolerated as codec-no-jack), ACCDET blocking notifier registered in probe/unregistered in remove, translations for ACCDET_EVENT_PLUG (3-pole HEADPHONE, 4/5-pole HEADSET) and ACCDET_EVENT_BUTTON with remembered-press release semantics, and boot state seeded via the final accdet_get_state() in probe + retried in card init; no second input device. ROM-empty MM1 init left without fmt/constraints (documented). Only two card-level jack anchor pins, no routes, no codec routing duplicated.",
  "compile_result": "PASS. Exact acceptance recipe (nura.config, scripts/config --enable SOUND --enable SND --module SND_SOC --module SND_SOC_MT6735_MT6331, olddefconfig, make ARCH=arm64 LLVM=1 -j2 sound/soc/mediatek/mt6735/mt6735-mt6331.o): exit 0, 'CC sound/soc/mediatek/mt6735/mt6735-mt6331.o', object 233712 bytes. W=1 clean (no warnings/errors). Both ACCDET header branches compile: CONFIG_MTK_ACCDET unset (inline stubs) and CONFIG_MTK_ACCDET=1 via KCFLAGS (exit 0, no warnings; llvm-nm shows U accdet_get_state / U accdet_register_notifier / U accdet_unregister_notifier). Caveat: CONFIG_SND_SOC_MT6735 does not exist in this worktree yet (AFE patch), olddefconfig drops SND_SOC_MT6735_MT6331, but kbuild single-target still builds the object; module wiring also verified with CONFIG_SND_SOC_MT6735_MT6331=m forced on the make command line (CC [M]).",
  "files_changed": [
    "sound/soc/mediatek/mt6735/mt6735-mt6331.c",
    "sound/soc/mediatek/mt6735/Makefile",
    "sound/soc/mediatek/Kconfig",
    "sound/soc/mediatek/Makefile"
  ],
  "deferred": [
    "Voice_MD1 / Voice_MD2 (+BT, VOIP BT) links",
    "HDMI_OUT link",
    "FM: FM_I2S_RX, FM_MRGTX, FM I2S capture",
    "TDM debug capture, ULDLOOPBACK, MRGRX/MRGRXCAPTURE",
    "AWB: DL1_AWB, I2S0_AWB, MultiMedia3/UL2",
    "OFFLOAD_GDMA / compress offload path",
    "HP_IMPEDANCE PCM",
    "PLATOFRM_CONTROL / Routing-Control link",
    "I2S low-jitter machine control (SOC_ENUM_EXT)",
    "Android HAL-facing debugfs/proc/ioctl and param parser"
  ],
  "notes": "DTS-FRAGMENT (apply by integration owner; no shared DTS edited):\n/ {\n\tsound {\n\t\tcompatible = \"mediatek,mt6735-sound\";\n\t\tstatus = \"okay\";\n\t};\n};\nNames-only links suffice; accdet.h was copied by the ACCDET owner into my worktree and stays untracked/excluded from the patch. Patch regenerated after the final source edit: 4 files, 485 lines, new files via git add -N, nothing committed. Known interface limitation: DL2 shares the single contract playback DAI mt-soc-codec-tx-dai (ROM used tx-dai2), so MM1+DL2 cannot stream concurrently. Hardware-unverified: I2S clocking/word length, jack DAPM pin resolution, codec set_jack implementation, ACCDET debounce/timing, hundred-ohm key bands."
}