{
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/audio-mt-soc.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/audio-mt-soc.md",
  "compile_result": "PASS. cd $M/worktrees/audio-mt-soc; PATH=$M/llvmpkg/usr/bin:$M/bin:$PATH; cp $M/nura.config .config; ./scripts/config --enable SOUND --enable SND --module SND_SOC --module SND_SOC_MT6735; make ARCH=arm64 LLVM=1 olddefconfig; make ARCH=arm64 LLVM=1 -j2 sound/soc/mediatek/mt6735/mt6735-afe-pcm.o sound/soc/mediatek/mt6735/mt6735-afe-clk.o sound/soc/mediatek/mt6735/mt6735-dai-pcm.o sound/soc/mediatek/mt6735/mt6735-dai-i2s.o -> exit 0 after full rm+rebuild, output exactly 'CC [M] sound/soc/mediatek/mt6735/mt6735-afe-pcm.o', 'CC [M] .../mt6735-afe-clk.o', 'CC [M] .../mt6735-dai-pcm.o', 'CC [M] .../mt6735-dai-i2s.o', no warnings. CONFIG_SND_SOC_MT6735=m resolved, SND_SOC_MEDIATEK selected. A module .ko link also passes LD [M]; modpost's unresolved-core-symbol messages are only due to the single-module build having no vmlinux.o.",
  "files_changed": [
    "sound/soc/mediatek/Kconfig",
    "sound/soc/mediatek/Makefile",
    "sound/soc/mediatek/mt6735/Makefile",
    "sound/soc/mediatek/mt6735/mt6735-afe-regs.h",
    "sound/soc/mediatek/mt6735/mt6735-afe-common.h",
    "sound/soc/mediatek/mt6735/mt6735-afe-clk.h",
    "sound/soc/mediatek/mt6735/mt6735-afe-clk.c",
    "sound/soc/mediatek/mt6735/mt6735-afe-pcm.c",
    "sound/soc/mediatek/mt6735/mt6735-dai-pcm.c",
    "sound/soc/mediatek/mt6735/mt6735-dai-i2s.c"
  ],
  "deferred": [
    "voice MD1/MD2 and BT variants",
    "HDMI",
    "FM I2S / MRG",
    "TDM capture",
    "AWB and UL/DL loopback memifs",
    "BT CVSD (DAIBT)",
    "offload/compress GDMA and other memifs (AWB, DAI/mod-PCM, DL1_D2, VUL_D2, HDMI)",
    "HP impedance",
    "internal-SRAM playback path (DRAM managed buffers only)",
    "side tone, sine generator, HW gain, ASRC, 2nd I2S, modem PCM",
    "MCLK/BCLK dividers (audiosys clock controller, 0x1021xxxx; no provider in kernel yet)",
    "AFE_MEMIF_MSB 33-bit addresses"
  ],
  "notes": "Delivered the AFE platform driver (compatible mediatek,mt6735-afe; reg 0x11220000/0x10000; IRQ from DT), 3 FE DAIs with exact names and working startup/hw_params/prepare/trigger (component pointer + pcm_construct implemented), and the bidirectional I2S0 BE DAI driving AFE_I2S_CON. Component name is \"mtk-afe-pcm\"; afe->memif uses the standard mtk_base_afe/mtk_base_memif_data tables; no codec or machine driver created. All register offsets and bit fields are cited to downstream file:line in mt6735-afe-regs.h and cross-checked against ROM disassembly: AudDrv_IRQ_handler@0xc084c08c (0x3A4/0x3B4/0x3BC/0x3CC/0x3A8), Auddrv_DL1_Interrupt_Handler@0xc084b7a8 and mtk_pcm_pointer@0xc0850238 (0x44), SetIrqMcuCounter@0xc0847224 (0x3AC/0x3B0), SetIrqEnable@0xc0846f60 (0x3A0/0x3B4), EnableAfe@0xc0847fac (0x10 bit0), SetDLSrc2@0xc0849194 (0x108/0x10C), SetI2SDacOut@0xc0849284 (0x34), SetMemIfFetchFormatPerSample@0xc084a658 (0x3D8 masks 0x30000/0xC0000/0xC00000), SetSampleRate@0xc0848174 (0x14 masks 0xf..0xf0000), Enable4pin_I2S0_I2S3@0xc084ccfc (0x4/0x18/0x4C). Key deviation documented: the assignment says select audpmicclk-mode0 while the codec path is active, but downstream AudDrv_Gpio.c:219-234 and the DTS pin groups show mode1 = AUD_CLK_MOSI/AUD_DAT_MISO/AUD_DAT_MOSI (active) and mode0 = GPIOs (idle), so the driver selects mode1 while active, mode0 when idle, default at probe/remove. Other inferred items: DL2 mono bit corrected from downstream mask/value mismatch to bit22; period_bytes_min/periods limits; capture voice-mode 0 for non-8/16/32/48 kHz rates reproduced from downstream (44.1 kHz capture unverified); 21 aud_* clocks fetched with devm_clk_bulk_get_optional because no audiosys clock provider exists in this kernel (register access without them is hardware-unverified); pinctrl selection moved out of the atomic trigger path. GPLv2 notices and MediaTek copyrights preserved, each file marked 'Port from Samsung/MTK downstream ...'. No shared DTS edit; exact afe node + aud pin-group fragment is in report section 6, including the note that clock phandles require the missing mediatek,mt6735-audiosys provider."
}