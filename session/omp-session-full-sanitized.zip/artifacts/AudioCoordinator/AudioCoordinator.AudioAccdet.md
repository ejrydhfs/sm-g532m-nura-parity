{
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/audio-accdet.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/audio-accdet.md",
  "compile_result": "PASS. Recipe: PATH=$M/llvmpkg/usr/bin:$M/bin; cp $M/nura.config .config; ./scripts/config --enable SOUND --enable SND --module SND_SOC --module MTK_ACCDET; make ARCH=arm64 LLVM=1 olddefconfig; make ARCH=arm64 LLVM=1 -j2 drivers/misc/mediatek/accdet/accdet.o drivers/mfd/mt6397-core.o -> exit 0, output 'CC drivers/mfd/mt6397-core.o' and 'CC [M] drivers/misc/mediatek/accdet/accdet.o'. Re-run with W=1: zero warnings/errors from either object. CONFIG_MTK_ACCDET=m, CONFIG_MFD_MT6397=y verified in .config. accdet.ko link not verifiable in this tree (no Module.symvers because no full kernel build; modpost reports unresolved kernel symbols, expected). llvm-nm accdet.o shows T accdet_register_notifier / accdet_unregister_notifier / accdet_get_state and the expected kernel API imports.",
  "files_changed": [
    "drivers/misc/mediatek/accdet/accdet.c",
    "drivers/misc/mediatek/accdet/accdet-regs.h",
    "drivers/misc/mediatek/accdet/Kconfig",
    "drivers/misc/mediatek/accdet/Makefile",
    "include/linux/mfd/mt6328/accdet.h",
    "drivers/misc/Kconfig",
    "drivers/misc/Makefile",
    "drivers/mfd/mt6397-core.c"
  ],
  "deferred": [
    "AP GPIO EINT 4 plug path (ROM CONFIG_ACCDET_EINT): not used because MC6735 mtk_eint_hw has no .db_time so the ROM's 256 ms plug debounce cannot be programmed via gpiod_set_debounce/mtk_eint_set_debounce (-EOPNOTSUPP); plug/unplug therefore comes from the PMIC ACCDET comparator (STATE_RG[7:6]==3) and the unit stays enabled while idle. pinctrl state 'state_eint_as_int' is still selected to apply the ROM pin muxing (GPIO1/GPIO4).",
    "Five-pole headset (ROM CONFIG_HEADSET_SUPPORT_FIVE_POLE off): external cable maps to EXT_CABLE/ACCDET_CABLE_NONE exactly like downstream; ACCDET_CABLE_HEADSET_5POLE never produced.",
    "/dev/accdet misc device and ioctls (ACCDET_INIT, SET_CALL_STATE, GET_BUTTON_STATUS) - excluded by task rules (Android HAL interface).",
    "Samsung SEC_JACK_SYSFS jack factory (jack_factory.c) - excluded by task rules.",
    "TS3A225E accessory switch (ROM defconfig off).",
    "Pin swap (ACCDET_PIN_SWAP) and pin recognition (ACCDET_PIN_RECOGNIZATION) - ROM defconfig off.",
    "input device key injection (send_key_event with KEY_PLAYPAUSE/VOLUMEUP/VOLUMEDOWN/VOICECOMMAND) replaced by ACCDET_EVENT_BUTTON notifier per the interface contract.",
    "6 s mic-bias power-down timer (MICBIAS_DISABLE_TIMER) - EINT-specific; disabling the unit would lose plug detection in this configuration.",
    "Call state / STAND_BY state (HAL ioctl only)."
  ],
  "notes": "DTS-FRAGMENT (integration owner applies; no shared DTS edited):\n\n&mt6328 {\n\tmt6328_accdet: accdet {\n\t\tcompatible = \"mediatek,mt6328-accdet\";\n\t\tstatus = \"okay\";\n\n\t\tpinctrl-names = \"default\", \"state_eint_as_int\";\n\t\tpinctrl-0 = <&accdet_pins_default>;\n\t\tpinctrl-1 = <&accdet_pins_eint_as_int>;\n\n\t\t/* ROM headset-detect EINT (AP GPIO EINT 4); not parsed by this\n\t\t * PMIC-interrupt configuration, kept as the ROM description.\n\t\t */\n\t\tinterrupt-parent = <&pio>;\n\t\tinterrupts = <4 IRQ_TYPE_LEVEL_LOW>;\n\t\tdebounce = <4 0x3e800>;\n\n\t\taccdet-mic-vol = <7>;\n\t\theadset-mode-setting = <0x500 0x500 0x1 0x1f0 0x800 0x800 0x20>;\n\t\taccdet-plugout-debounce = <20>;\n\t\taccdet-mic-mode = <1>;\n\t\theadset-vol-threshold = <0 0x252 0x253 0x270f 0xaf0>;\n\t\theadset-three-key-threshold = <0 0x7a 0xd4 0x1e8>;\n\t\theadset-four-key-threshold = <0 0x55 0x7a 0xd4 0x1e8>;\n\t};\n};\n\n&pio {\n\taccdet_pins_default: accdet-default-pins {\n\t\tpins {\n\t\t\tpinmux = <PINMUX_GPIO1__FUNC_GPIO1>,\n\t\t\t\t <PINMUX_GPIO4__FUNC_GPIO4>;\n\t\t\tslew-rate = <0>;\n\t\t\tbias-disable;\n\t\t};\n\t};\n\n\taccdet_pins_eint_as_int: accdet-eint-pins {\n\t\tpins {\n\t\t\tpinmux = <PINMUX_GPIO1__FUNC_GPIO1>,\n\t\t\t\t <PINMUX_GPIO4__FUNC_GPIO4>;\n\t\t\tslew-rate = <0>;\n\t\t\tbias-disable;\n\t\t};\n\t};\n};\n\nPin set from rom_dtb_0.dts:2163-2179 (pins 0x100=GPIO1, 0x400=GPIO4, slew 0, bias-disable). Interface note for integration: the shared header now also exports accdet_get_state() (additive; compiled into the audio-jack worktree and used by that machine driver). New files were recorded with git add -N so git diff --binary contains all five new files plus the three small edits; nothing committed. Warning: CONFIG_MTK_ACCDET=m with a built-in machine driver would fail to link; integration should set CONFIG_MTK_ACCDET=y if the sound card is built in."
}