{
  "status": "done",
  "key_finding": "The ticket's 'real gap' is falsified: MT6735/MT6737T LARB MMU_EN really is at 0xfc0, not 0xf00. Evidence: m4u/mt6735/mt6735/m4u_reg.h:314, mt6735m variant :311, dispsys mt6735/ddp_reg.h:1866 all use 0xfc0, and ROM m4u_config_port @0xc03814d8 writes larb_base+0xfc0/+0xfc4 (verified by disassembly). smi/smi_reg.h:388 0xf00 is a dead define for a different SMI generation (its DOMN 0xf08/0f0c 2-bit layout contradicts the MT6735 bank at 0xfd0-0xfdc, 4-bit). Existing mt6735 -> mt_smi_larb_mt8167 mapping is therefore correct; writing 0xf00 would break IOMMU on this SoC. Bytemap is per-port BIT(port) from the IOMMU consumer; no consumer => 0 => bypass, which is what the physical-address ISP char ABI needs.",
  "files": [
    "drivers/memory/mtk-smi.c: new mtk_smi_common_mt6735 gen + init table (L1LEN 0x100=0x1b, M4U_TH 0x234=0xf7e19085, FIFO_TH1 0x230=0x0e9f; downstream smi_configuration.c:111-117 and ROM .rodata 0xe808b0); evidence comments for the 0xfc0 larb path",
    "drivers/clk/mediatek/clk-mt6735-imgsys.c: CLK_IMG_SEN_CAM parent fixed mm_sel -> camtg_sel (downstream clk-mt6735.c:896)",
    "not changed (verified correct): mt6735-pm-domains.h (ISP SRAM bits/PWR_STATUS/no bp_cfg, DIS PROT bit1), imgsys dt-binding (all 8 gates present), DTS"
  ],
  "build": "PASS, 0 warnings/0 errors both passes. CONFIG_MTK_SMI=y, CONFIG_MTK_IOMMU=y, CONFIG_COMMON_CLK_MT6735_IMGSYS=y; make ARCH=arm64 LLVM=1 [-W=1] drivers/memory/mtk-smi.o drivers/clk/mediatek/clk-mt6735-imgsys.o (+mtk_iommu.o sanity). Logs/camera-gap-imgsys-build.log.",
  "patch": "$M/patches/camera-gap-imgsys.patch (2 files, +49/-3, applies cleanly to clean HEAD), report $M/logs/camera-gap-imgsys.md",
  "dts": "No DTS edit. ISP node must stay without iommus (physical DMA); exact future-V4L2 iommus fragment for the 21 LARB2 ports and confirmation that mediatek,larb is a downstream-only property are in report §6.",
  "remaining": "Not ported (documented, evidence+dangers in report): LARB2 OSTDL=1 x21 and 0x24 bit-27 clear (QoS/undocumented fields), SMI common L1ARB 0x104-0x114 (downstream indexes OOB and field layout unknown), LARB IRQ. Optional tools/.../imgsys-check intentionally omitted: no debugfs export for SMI registers and /dev/mem is blocked by STRICT_DEVMEM, so it would be an unverifiable placeholder.",
  "blockers": "None. Hardware-only unknowns: reset value of SMI QoS regs, whether ISP MTCMOS-off clears DIS-domain SMI common, and SMI_BUS_SEL=0x220 semantics (marked [INFERENCE], single-bank m4u makes 0 the only consistent value)."
}