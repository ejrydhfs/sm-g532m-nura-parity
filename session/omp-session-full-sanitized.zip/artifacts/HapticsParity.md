{
  "driver": "haptics (worktree rtc-haptic)",
  "status": "complete",
  "key_finding": "The SM-G532M ROM does not ship the assigned MTK vibrator_drv.c at all — ROM symbols (sec_vib_enable @0xc07c8810, sec_vib_vdd_en @0xc07c8c34, sec_vib_work @0xc07c8cb0, sec_vib_init @0xc0dc2ff0, timed_output_dev_register) and strings (sec_vib,max_timeout / sec_vib,ldo_type / sec_vib,regulator) prove it ships Samsung's drivers/motor/sec_vib.c. sec_vib was used as primary behavioral reference, vibrator_drv.c as secondary.",
  "files_changed": [
    "drivers/input/misc/regulator-haptic.c",
    "Documentation/devicetree/bindings/input/regulator-haptic.yaml"
  ],
  "audited_no_change": [
    "drivers/regulator/mt6328-regulator.c (VIBR EN=VIBR_CON0 BIT(1), VOSEL=DLDO_ANA_CON2 0x70, QI BIT(15), MODE_SET BIT(0), table ldo_volt_table9 == downstream mt6328_VCAM_AF_voltages — exact match to upmu_hw.h)",
    "arch/arm64/boot/dts/mediatek/mt6328.dtsi ldo_vibr node (3.3V fixed, ramp 44us) — byte-identical to ROM DTB rom_dtb_0.dts ldo_vibr"
  ],
  "changes": [
    "Timeout parity: hrtimer watchdog caps continuous regulator-on time at DT max-timeout-ms (default unlimited so other regulator-haptic boards are unaffected); latch holds motor off until FF stream goes quiet; ROM value is 10000ms (sec_vib,max_timeout = 0x2710 in ROM DTB, clamp confirmed in ROM disassembly 'movge r5, r2')",
    "New .remove callback cancels watchdog, drains work, disables rail (the added timer must be cancelled before devm teardown; also mirrors MTK vib_shutdown motor-off)",
    "suspend/close now cancel the watchdog; resume re-arms a fresh cap window",
    "Binding doc: max-timeout-ms property documented"
  ],
  "already_at_parity": [
    "enable/disable sequencing (active-cache toggle, voltage-before-enable) vs sec_vib running-cache",
    "voltage: 3.3V fixed (ROM DTB ldo_vibr min=max=0x325aa0) matches Nura haptics min/max-microvolt and mt6328_vibr_reg",
    "PMIC rail register programming in mt6328-regulator.c"
  ],
  "deliberate_deviations": [
    "Suspend: ROM sec_vib has no PM ops (motor keeps running through suspend); Nura keeps mainline suspend-off/resume-restore",
    "No MTK min-pulse bump (10-24ms -> 25ms): the ROM-shipped sec_vib driver has none; documented as follow-up if hardware shows short taps inaudible",
    "Timeout clamp is continuous-on-time based because ff-memless never passes effect duration to play_effect; identical behavior for single-effect playback, corner divergence documented for overlapping FF effects"
  ],
  "dts_fragment": "Add `max-timeout-ms = <10000>;` to the existing haptics node in arch/arm64/boot/dts/mediatek/mt6737t-samsung-grandpplte.dts (shared DTS untouched; full node in report §6)",
  "compile": "make ARCH=arm64 LLVM=1 ... -j2 drivers/input/misc/regulator-haptic.o -> CC [M] drivers/input/misc/regulator-haptic.o, clean (first attempt failed on hrtimer_init; this tree uses hrtimer_setup(), fixed)",
  "outputs": [
    "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/haptics.patch",
    "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/haptics.md"
  ],
  "hardware_unverified": [
    "ROM effective VIBR VOSEL at runtime (sec_vib never programs it; [INFERENCE] 3.3V from DT constraints)",
    "Motor amplitude at 3.3V vs the unshipped MTK HAL's 2.8V (vib_vol=5)",
    "VOSEL table entries 0-4 conflict between the two downstream tables (only code 7 = 3.3V used here)",
    "Cap timing accuracy (hrtimer + work latency) and latched hold-off under overlapping FF effects",
    "suspend/resume motor restart behavior"
  ]
}