{
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/ccci-c2k.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/ccci-c2k.md",
  "build_log": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/ccci-c2k_build.log",
  "compile": {
    "command": "export PATH=\"$M/llvmpkg/usr/bin:$M/bin:$PATH\"; cp $M/nura.config .config; scripts/config -e MTK_CCCI_C2K; make ARCH=arm64 LLVM=1 olddefconfig; make ARCH=arm64 LLVM=1 -j2 drivers/misc/mediatek/ccci_c2k/{ccci_c2k,ccci_c2k_hw,ccci_c2k_ch,ccci_c2k_sysfs}.o",
    "result": "rc=0, CONFIG_MTK_CCCI_C2K=y, all four objects built, zero warnings (W=1 pass also clean)"
  },
  "files": [
    "include/linux/ccci.h (contract section 5 verbatim + approved append)",
    "drivers/misc/mediatek/ccci_c2k/ccci_c2k.c",
    "drivers/misc/mediatek/ccci_c2k/ccci_c2k_hw.c",
    "drivers/misc/mediatek/ccci_c2k/ccci_c2k_ch.c",
    "drivers/misc/mediatek/ccci_c2k/ccci_c2k_sysfs.c",
    "drivers/misc/mediatek/ccci_c2k/ccci_c2k.h",
    "drivers/misc/mediatek/ccci_c2k/Kconfig",
    "drivers/misc/mediatek/ccci_c2k/Makefile",
    "drivers/misc/mediatek/Kconfig (created)",
    "drivers/misc/mediatek/Makefile (created)",
    "drivers/misc/Kconfig (1 line)",
    "drivers/misc/Makefile (1 line)"
  ],
  "header_append": "struct ccci_md_hw_ops { power_on, let_md_go, power_off, reset } + ccci_register_md_hw_ops()/ccci_unregister_md_hw_ops() appended before #endif; lines 1-284 and the closing #endif are byte-identical to contract section 5 (diff-verified). Driver calls ccci_register_md_hw_ops(CCCI_MD_SYS3) in probe; NO weak fallback, NO polling fallback, per coordinator.",
  "done": [
    "MD3 as second CCIF modem instance (ROM has no modem_sdio/cbp_sdio/rawbulk symbols, only mtk_wdt_set_c2k_sysrst): platform driver on compatibles mediatek,ap2c2k_ccif / mediatek,mt6735-ccif-md3, fills ccci_md_cfg (md_id SYS3, md3, md3img, ccif phys/size/irq, MD3 boot-slave triples, RGU 0x30050000, sram 512, capability IRAT|WORLD_PHONE, irat_md_id SYS1), ccci_register_modem + unregister in remove and shutdown",
    "hw sequencing with downstream citations: boot slave key/vector/enable, C2K_CONFIG bootmode [10:8]=5 + ETS_SEL(bit13), C2K_SPM_CTRL srcclkena [5:4]=2, SLEEP_CLK_CON bits 2/3/12/27 + clear 14, TOP_RGU SWSYSRST bit15+key 0x88000000 (matches ROM disasm at 0xc0715d60), SPM wake pulse + C2K_STATUS[1] poll (bounded 1s), chip-id read vs 0x020AC000, VTCXO_1 via regulator (PMIC 0x0A02 == MT6328_VTCXO_1_CON0), clock gating via optional scp-sys-md2-main",
    "channel map: c2k_ports[] verbatim (control/status/audio/net1-3+dl_ack/mdlog ctrl+data/fs/data-ppp/AT/AT2/AT3/agps/loopbacks), both directions with exception-channel behaviour, exported for core",
    "IRAT: ccci_md_set_irat(SYS3, SYS1) at probe + irat_state sysfs",
    "dual-SIM switch mode storage (store/get parity) exposed as c2k/sim_switch_mode",
    "sysfs /sys/kernel/c2k (md3_state, boot_count, irat_state, sim_switch_mode, chip_id, md_wdt_irq, regs, c2k_wdt_status) + debugfs /sys/kernel/debug/ccci_c2k (state, regs, wdt, channels)",
    "DTS fragment validated with tree cpp+dtc against mt6737t-samsung-grandpplte.dts; all phandles resolve"
  ],
  "partial_deferred": [
    "clock gating: Nura mt6735 clk/SCP driver has no SCP_SYS_MD2 (only POWER_DOMAIN_MD1) -> optional clock, fragment leaves clocks commented; needs shared mtk-scpsys/clock work",
    "ETS_SEL source: no 7.0.10 boot-mode provider -> DT bool mediatek,ets-sel (documented)",
    "MD3 watchdog IRQ parsed/reported but not requested: struct ccci_md_cfg has one irq; MD exception handling is core's",
    "CCCI_IOC_RESET_MD1_MD3_PCCIF (port_char.c:981) not run as side effect of MD3 reset; PCCIF windows mapped and dumped only",
    "CCCI_MD_MSG_CFG_UPDATE monitor message after sim-mode change: virtual modem messages have no contract API",
    "CBP/SDIO transport absent from ROM build (verified); legacy dual_ccci /dev ABI unused by 3.18 eccci",
    "PMIC VTCXO: register identity proven (0x0A02) but full 16-bit 0xA12E value not written bit-for-bit; regulator enable instead"
  ],
  "hardware_unverified": [
    "MD3 CCIF IRQ = GIC_SPI 139 LEVEL_HIGH is [INFERENCE] from AP_CCIF1@0x10218000 in mt6735m.dtsi; ROM DTB only proves C2K WDT = SPI 229, EDGE_FALLING",
    "MD3 boot-slave writes conflict with downstream eccci 'no boot slave for md3' comment (ccif_c2k_platform.c:188-193); written per contract section 7 with values cited from modem_reg_base.h and also passed to core",
    "1s wake timeout is a robustness choice, not a hardware constant"
  ],
  "dts_fragment": "see section 9 of report: ccif_md3: ccif@10218000 under soc, reg-names ap-ccif/md1-pccif/md3-pccif/chip-id/boot-vector/boot-vector-key/boot-vector-en/md-rgu, interrupts ccif + md-wdt, cell-index 2, ccif,capability 0x00180000, phandles infracfg/spm/toprgu, vtcxo1-supply = <&mt6328_vtcxo_1_reg>",
  "notes": "skb ownership unaffected (this leaf never touches skbs). Worktree has only the 12 intended files staged; nothing committed."
}