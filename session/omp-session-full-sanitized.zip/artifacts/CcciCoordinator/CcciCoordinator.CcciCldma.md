{
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/ccci-cldma.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/ccci-cldma.md",
  "worktree": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/ccci-cldma",
  "compile": {
    "command": "export PATH=\"$M/llvmpkg/usr/bin:$M/bin:$PATH\"; cp $M/nura.config .config; scripts/config -e MTK_CCCI_CLDMA; make ARCH=arm64 LLVM=1 olddefconfig; make ARCH=arm64 LLVM=1 -j2 drivers/misc/mediatek/ccci_cldma/ccci_cldma.o",
    "result": "PASS (exit 0, 'CC drivers/misc/mediatek/ccci_cldma/ccci_cldma.o'); W=1 clean; checkpatch 0 errors / 0 warnings"
  },
  "header": "include/linux/ccci.h byte-identical to contract section 5 (md5 a44b077ce8fb37dd2c2d5c84f7d462e0)",
  "files_changed": [
    "include/linux/ccci.h",
    "drivers/misc/mediatek/ccci_cldma/ccci_cldma.c",
    "drivers/misc/mediatek/ccci_cldma/ccci_cldma.h",
    "drivers/misc/mediatek/ccci_cldma/Kconfig",
    "drivers/misc/mediatek/ccci_cldma/Makefile",
    "drivers/misc/mediatek/Kconfig",
    "drivers/misc/mediatek/Makefile",
    "drivers/misc/Kconfig",
    "drivers/misc/Makefile"
  ],
  "done": [
    "register map from mt6735/cldma_reg.h with line citations",
    "GPD/BD ring allocation via dma_pool (net TX BD/SGIO, normal GPD) with downstream queue-to-ring tables",
    "TX send: DMA map, per-channel seq_num assigned under ring_lock (FEATURE_SEQ_CHECK_EN), HWO publish, UL_RESUME doorbell, -EBUSY/ownership semantics",
    "TX collect (GPD+BD) with unmap and skb free, TX_DONE work/mask",
    "RX arm/refill, normal collect -> callback, net collect -> push thread -> callback, CCCI header intact",
    "threaded IRQ (GIC SPI 145) with L2/L3 ack/mask and per-queue work dispatch",
    "start/config/stop/clear paths, bounded status polling, seq counter reset at start",
    "queue-7 30s watchdog timer with GPD + register dump",
    "32-bit DMA mask, workqueue/kthread lifecycle, create/destroy error unwinding"
  ],
  "cross_leaf": {
    "tx_seq_num": "owned by CLDMA under the queue lock (downstream modem_cldma.c:2862); core confirmed it does not touch it on the CLDMA path",
    "assert_bit": "CLDMA forces 1 for all channels except CCCI_RPC_TX/CCCI_FS_TX; core pre-sets those two from boot stage (agreed)",
    "rx_seq_check": "core does it in ccci_md_rx_cb() with the qno delivered by this driver",
    "skb_ownership": "success = CLDMA consumes/frees; -EBUSY/-EINVAL/-EIO = caller frees (core confirmed)"
  },
  "partial": [
    "queue switch ring implements normal-mode mapping; exception-mode 4K remap not reachable through frozen API"
  ],
  "deferred": [
    "exception-mode ring remap (no EX_INIT_DONE signal in frozen API)",
    "RGU reset via INFRA_RST0/1 (INFRA_AO base not in ccci_cldma_cfg)",
    "SPM MD clock request (platform PM)",
    "CCIF peer wakeup / force-assert (core/CCIF)",
    "NAPI hand-off (API has no NAPI; push-thread path used)",
    "MD-side UL_STATUS check in rx_done (no MD_CLDMA_PDN base)",
    "traffic monitor, packet history, AEE/dump_info hooks",
    "blocking send/write_room and IoC override (not in API)"
  ],
  "notes": "DTS fragment in report section 9 (mdcldma@1000A000, GIC_SPI 145/140/221, md_id 0, capability 6, smem 0x30000, MD1 power domain). No DTS/config/shared-file edits; nothing committed; 9 files staged."
}