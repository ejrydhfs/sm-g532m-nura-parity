{
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/ccci-eccci.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/ccci-eccci.md",
  "worktree": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/ccci-eccci",
  "compile": {
    "command": "export PATH=\"$M/llvmpkg/usr/bin:$M/bin:$PATH\"; cp $M/nura.config .config; scripts/config -e MTK_CCCI; make ARCH=arm64 LLVM=1 olddefconfig; make ARCH=arm64 LLVM=1 -j2 drivers/misc/mediatek/ccci/{ccci_core,ccci_platform,ccci_ccif,ccci_boot,ccci_port_char,ccci_port_net,ccci_port_kernel,ccci_ringbuf,ccci_sysfs}.o",
    "result": "PASS: 9/9 objects built from scratch, exit 0, zero warnings/errors; drivers/misc/mediatek/ccci/built-in.a also links",
    "config": "CONFIG_MTK_CCCI=y"
  },
  "files": {
    "new_driver": [
      "drivers/misc/mediatek/ccci/ccci_priv.h (782)",
      "ccci_core.c (1265)",
      "ccci_platform.c (366)",
      "ccci_ccif.c (784)",
      "ccci_boot.c (918)",
      "ccci_port_char.c (577)",
      "ccci_port_net.c (369)",
      "ccci_port_kernel.c (434)",
      "ccci_ringbuf.c (290)",
      "ccci_sysfs.c (357)",
      "Kconfig",
      "Makefile"
    ],
    "shared_header": "include/linux/ccci.h — byte-identical to contract §5, plus the required struct ccci_md_hw_ops addendum appended before #endif",
    "hooks": [
      "drivers/misc/Kconfig (+1 source line)",
      "drivers/misc/Makefile (+1 obj-y line)",
      "drivers/misc/mediatek/Kconfig (new)",
      "drivers/misc/mediatek/Makefile (new)"
    ],
    "patch_stat": "17 files, 6493 insertions, nothing committed (staged only)"
  },
  "implemented": {
    "core": "modem object + per-MD device, state machine CCCI_MD_BOOTING/READY/EXCEPTION/STOPPED (+EV pseudo events), verbatim MD1/MD3 port tables from port_cfg.c (minor 0xF0|n net, IPC minor base 100), Rx dispatch by channel, Tx queueing with transport switch, per-port seq (ring path only; CLDMA owns it per peer confirmation), per-module kernel service helpers, ccci_register_modem/unregister/get_state/set_irat, ccci_register_md_hw_ops API (NULL-checked, power_on/let_md_go failures abort boot, power_off on stop, reset on exception)",
    "platform": "platform_driver 'mediatek,mdcldma': DT md_id/cldma_capability/md_smem_size/firmware-name, 6 register windows, 3 IRQs, optional scp-sys-md1-main clock + MD1 genpd, builds ccci_md_cfg, creates CCIF, creates CLDMA engine via ccci_cldma_create when regs present, pm_ops suspend/resume/freeze/thaw/poweroff/restore/restore_noirq, .remove, .shutdown",
    "ccif": "APCCIF_CON/BUSY/START/TCHNUM/RCHNUM/ACK/CHDATA at contract offsets, 512-byte SRAM window, BUSY/ACK handshake with 1ms bounded timeout, request_threaded_irq + per-queue Rx tasklets, D2H SRAM header dispatch, HIF_EX exception state machine (IRQ-driven for CCIF-ring, polled work for CLDMA), ccif_enable_irq/ccif_disable_irq, MD WDT IRQ -> reg dump + reset + MD_MSG_RESET",
    "boot": "request_firmware md1img/md3img (DT firmware-name override), CHECK_HEADER v1-v5 parse/validate (magic, bind_sys_id, md_img_size, mem_size, tail header-size word), chunked copy into modem image region (DT reserved-memory; clean -ENODEV without it, -ENOENT for missing firmware), firmware released after copy, boot vector/key/enable (0x3567C766/0x0/0xA3B66175), clock+genpd+WDT_MD_MODE power-on, runtime-data handshake (ap_query_md_feature on control q0 for CLDMA, legacy modem_runtime in CCIF SRAM for ring mode), 20s/10s boot watchdog",
    "char": "one cdev+/dev node per char port with ROM minors, open/release with critical-user tracking, read with header strip/partial read/monitor CCCI_MONITOR_CH_ID tag, state-gated write with blocking retry, poll, ioctl subset (GET_MD_STATE, MD_RESET, DO_MD_RST, GET_MD_INFO, GET_MD_EX_TYPE, FORCE_MD_ASSERT, SEND_RUN_TIME_DATA, DO_START/STOP_MD, STOP/START/POWER requests, ENTER/LEAVE_DEEP_FLIGHT, GET_MD_PROTOCOL_TYPE, SET/GET_MD_BOOT_MODE, GET_MD_MEM_SIZE)",
    "net": "ccmni_ccci_ops filled (8/3 devices, ccmni/cc3mni, CAP|DATA_ACK_DVD), send_pkt 0/-1/-2/-3 semantics, ack-channel txq mapping, Rx header pull then ccmni_rx_callback, md-state callback on READY/EXCEPTION/STOPPED, napi_poll returns 0 as downstream",
    "kernel": "control/system/status kthreads handling MD_INIT_START_BOOT/MD_NORMAL_BOOT/MD_EX/MD_EX_REC_OK/MD_EX_PASS/MD_EX_RESUME/CCCI_DRV_VER_ERROR/C2K msgs and MD_GET_BATTERY_INFO/MD_WDT_MONITOR/MD_SIM_TYPE/TX-power/thermal; exec_ccci_kern_func_by_md_id (wakeup-src, state, reset, pause-lte, txpower, sim-switch, dump, throttle), register_ccci_sys_call_back, ccci_get_md_boot_count",
    "ringbuf": "downstream wire format (0xEE0000EE header, 0xAABBAABB+len, 8-byte align, 0xCCDDEEFF footer) with read/write/readable/writeable/move_rpointer/reset, MMIO accessors + barriers",
    "sysfs": "per-modem /sys/class/ccci_node/mdN/{ccci_md_enable,ccci_version,ccci_md_state,ccci_dump,ccci_boot_info,ccci_md_exception} and same-named files plus 'ccif' in debugfs ccci/mdN (debugfs_lookup on EEXIST, shared with ccci-util)"
  },
  "deferred": [
    "CLDMA engine internals (owned by ccci-cldma; core only uses the frozen API)",
    "kernel RPC services (GPIO/ADC/EINT/time; MTK providers absent) — ccci_rpc_k logs+drops",
    "/sys/kernel/ccci global attribute set (util declines it too)",
    "MD security/MPU/RMPU programming and check-header v4/v5 region permissions (masp/EMI-MPU absent)",
    "PMIC VLTE/VSEL, SPM md_src, RF clock-buffer pinctrl, kicker_pbm, spm_is_md1_sleep (no providers)",
    "AEE dump, SBP, DHL logging, MD sleep-history log",
    "LK/DA modem memory table parsing (replaced by DT reserved-memory)",
    "MD1<->MD3 smem, C2K SDIO/CBP, rawbulk/USB bypass (not in ROM build / c2k leaf)",
    "IPC kernel-side ID/ack/garbage filtering (port_ipc.c)",
    "header v6 images (-EOPNOTSUPP)"
  ],
  "non_existent_requested_items": {
    "CCCI_IOC_GET_MD_BOOT_INFO": "no such ioctl in the 3.18 ROM header; implemented as CCCI_IOC_GET_MD_INFO (_IOR('C',8)) plus ccci_boot_info sysfs/debugfs; no ioctl number invented",
    "CCCI_IOC_GET_MD_WAKEUP_SRC": "not an ioctl in this ROM; the ROM uses the kernel API exec_ccci_kern_func_by_md_id(md_id, ID_GET_MD_WAKEUP_SRC), which is implemented"
  },
  "hardware_unverified": [
    "no MT6737T hardware attached; register writes never exercised",
    "dma_alloc_coherent smem fallback is only MD-visible if the modem can address it (logged as unverified); real boot requires DT reserved-memory carve-outs whose addresses come from the device memory map",
    "CCIF ring sizes/timings copied from downstream, not measured",
    "ccci_util_dump_set_window() signature from the util leaf; integration must confirm"
  ],
  "dts_fragment_location": "report §10 (two parts: mdcldma node with contract §7 regs/IRQs; reserved-memory md1-image/md1-smem carve-outs with bases to be filled from the device memory map — no addresses invented)",
  "cross_leaf_agreements": [
    "ccci-util: symbol split + debugfs ccci/mdN sharing via debugfs_lookup + ccci_util_dump_set_window call",
    "ccmni: L3-skb/headroom/error-code contract, ops struct copied so core keeps ownership, napi_poll may return 0",
    "ccci-cldma: engine owns seq_num/assert_bit; core only pre-sets RPC/FS assert bit; Rx seq check in ccci_md_rx_cb with hw qno and AP_MD_SEQ_ERROR"
  ]
}