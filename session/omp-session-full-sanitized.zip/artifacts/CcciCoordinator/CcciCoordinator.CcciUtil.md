{
  "status": "complete",
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/ccci-util.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/ccci-util.md",
  "worktree": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/ccci-util",
  "compile": "cp $M/nura.config .config; scripts/config -e MTK_CCCI_UTIL; make ARCH=arm64 LLVM=1 olddefconfig; make ARCH=arm64 LLVM=1 -j2 drivers/misc/mediatek/ccci_util/{ccci_util,ccci_util_dump,ccci_util_img,ccci_util_log}.o -> exit 0; W=1 dir build also exit 0 with no warnings; drivers/misc/mediatek/ builds built-in.a",
  "files": [
    "include/linux/ccci.h (byte-identical to contract section 5, cmp-verified)",
    "drivers/misc/mediatek/ccci_util/ccci_util.c",
    "drivers/misc/mediatek/ccci_util/ccci_util.h",
    "drivers/misc/mediatek/ccci_util/ccci_util_dump.c",
    "drivers/misc/mediatek/ccci_util/ccci_util_img.c",
    "drivers/misc/mediatek/ccci_util/ccci_util_log.c",
    "drivers/misc/mediatek/ccci_util/Kconfig",
    "drivers/misc/mediatek/ccci_util/Makefile",
    "drivers/misc/mediatek/Kconfig",
    "drivers/misc/mediatek/Makefile",
    "drivers/misc/Kconfig (1 line)",
    "drivers/misc/Makefile (1 line)"
  ],
  "done": [
    "contract API ccci_util_init/exit, ccci_util_log_init/exit, ccci_util_log, ccci_util_dump_mem",
    "per-MD 4KiB log ring with timestamps/overflow + 6 downstream dump buffers per MD, debugfs ccci/mdN/{log,dump,log_stats}",
    "/dev/ccci_log misc device (blocking read, -EAGAIN on O_NONBLOCK, poll, single reader -EBUSY) and /dev/ccci_dump (snapshot read, poll, raw {type,len,data} write, SET_MD/GET_MD ioctl)",
    "hex/ASCII dump helper, downstream word/compact dump formats, debugfs ccci/dump (md_id addr len) with -EINVAL out-of-window and -ENODEV unregistered window, runtime window registry API + ccci/dump_window",
    "MD check-header v3/v4/v5 parse/validate (magic, verno, size field, bind_sys_id, image_type, mem_size, md_img_size, DSP, region/domain for v4/v5, arm7 for v5), validated against the real md1rom.img header extracted from the ROM CP tarball",
    "ccci_get_md_info_str, ccci_util_md_region_info, ccci_event_log/cpy, get_dump_buf_usage, ROM-parity ccci_dump_write/ccci_log_write[_raw]/ccci_log_init",
    "no calls into the CCCI core; exports only the contract API plus image/dump helpers"
  ],
  "partial": [
    "modem shared-memory dump window must be registered at runtime (ccci_util_dump_set_window or ccci/dump_window); no automatic DT/reserved-memory discovery because util cannot call the core"
  ],
  "deferred": [
    "downstream block-partition file I/O (ccci_util_fo_init/get_raw_check_hdr/get_md_img_raw_size) replaced by core request_firmware path",
    "ccci_load_firmware and ccci_get_md_check_hdr_inf raw-image path",
    "secure-image authentication (ccci_init_security)",
    "meta/opt parsing (ccci_get_opt_val, ccci_dump_opt_tbl, ccci_parse_meta_md_setting, ccci_md_mem_reserve)",
    "/sys/kernel/ccci attributes (out of assigned file set; coordinated with ccci-core)",
    "v1/v2 and v6 check headers (-EOPNOTSUPP)"
  ],
  "notes": [
    "ROM/downstream expose /proc/ccci_log and /proc/ccci_dump via proc_create_data (ROM 0xc0504e30/0xc0504e98); implemented as misc /dev nodes per assignment",
    "debugfs mdN uses md_id+1 (md1, md3); ccci-core agreed to debugfs_lookup instead of create_dir",
    "no DTS change required (DTS-FRAGMENT: none)"
  ]
}