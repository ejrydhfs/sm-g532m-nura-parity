# CCCI gap leaf brief (shared)

`M=/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work`

## Goal
Close one CCCI gap in the Nura arm64 MT6737T kernel (`v7.0.10-mt6735`) to behavioural
parity with the Samsung/MTK SM-G532M 3.18 downstream kernel. You own exactly ONE leaf;
the coordinator integrates the leaves afterwards.

## Read first (mandatory)
1. `$M/CCCI_GAP_CONTRACT.md` — worktree state, frozen API, cross-leaf symbol table,
   evidence rules, required report structure (§7), build commands (§3).
2. `$M/PARITY_CONTEXT.md` — sources of truth and global editing/build rules.
3. `$M/CCCI_CONTRACT.md` and `$M/logs/ccci-coordinator.md` for baseline layout.
4. Your leaf's worktree: existing partial work from an aborted run.

## Worktree rules
- Work only in YOUR worktree (`$M/worktrees/ccci-gap-<leaf>`).
- It already has two local commits: `ccci: integration baseline` (`ccci-integration.patch`)
  and `ccci: gap scaffold`. **Continue the existing partial work.** Do NOT
  `git checkout` / `git reset` / `git stash` / `git commit` / recreate the worktree.
- Do not edit `$M/worktrees/integration`, non-gap worktrees, another leaf's worktree,
  `$M/nura.config`, or any shared DTS file. DTS changes go in the report as a
  `DTS-FRAGMENT` only (see contract §4/§10 for the required shape).
- `include/linux/ccci.h` is frozen: implement the declared signatures exactly; if a
  declaration is genuinely insufficient, implement to it and add
  `SCAFFOLD CHANGE REQUIRED: <exact proposal>` to the report.
- Shared files (`ccci_core.c`, `ccci_priv.h`, `ccci_boot.c`, `ccci_platform.c`,
  `{Kconfig,Makefile}`) must be edited additively in one clearly-commented block;
  no reformatting/reordering. Expect the coordinator to resolve cross-leaf conflicts.
- Cross-leaf symbols (contract §5): reference them; never define a stub for a symbol
  another leaf owns. Object compilation does not require the definition.

## Evidence rules (hard)
- Sources in order: downstream `$M/src/downstream-grandpplte` (cite `file:line`), ROM
  `$M/zip/symbols.txt` / `vmlinux.strings` / `vmlinux.elf` disassembly (cite symbol +
  address), then the Nura tree.
- **Never invent** register values, op ids, GPIO numbers, ADC channels, timing or
  addresses. No stubs, no `TODO: implement`, no fake success, no made-up data.
- Anything not directly cited must be marked `[INFERENCE]` in the code comment and report.
- If a sub-feature needs data absent from every available source, implement the supported
  parts and return the downstream failure code for the rest; state the exact missing input
  in the report. Do not simulate it.
- Preserve GPL notices; add `Port from Samsung/MTK downstream ...` comments.

## Build (must actually run; record exact commands and exit codes)
```sh
export PATH="$M/llvmpkg/usr/bin:$M/bin:$PATH"
cd "$M/worktrees/ccci-gap-<leaf>"
cp "$M/nura.config" .config
make ARCH=arm64 LLVM=1 olddefconfig
rm -f <each changed .o>          # force a real rebuild; stale .o files exist
make ARCH=arm64 LLVM=1 -j2 <each changed .o>
```
Also build the containing directory's `built-in.a` target if you added a new file.
Do NOT run a full `vmlinux` build; that is the coordinator's job. `W=1` must be clean
for your own objects (pre-existing warnings: name them).

## Deliverables (both mandatory)
```sh
cd "$M/worktrees/ccci-gap-<leaf>"
git add -A
git diff --cached --binary > "$M/patches/ccci-gap-<leaf>.patch"
```
- Patch: `$M/patches/ccci-gap-<leaf>.patch` (diff against worktree HEAD = baseline+scaffold).
- Report: `$M/logs/ccci-gap-<leaf>.md` with exactly the eight sections of contract §7.
- `git status --porcelain` must list only files belonging to your gap.

## Finish condition
The gap is genuinely closed (or its unsupported remainder is precisely documented),
every touched object compiles, patch + report exist. Then `yield` a short summary:
result, files changed, build commands/exit codes, patch path, report path, anything the
coordinator must know at integration (shared-file hunks, DTS fragments, cross-leaf deps).
