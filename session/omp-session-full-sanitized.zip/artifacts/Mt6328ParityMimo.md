{
  "patch": "$M/patches/mt6328.patch",
  "report": "$M/logs/mt6328.md",
  "worktree": "$M/worktrees/mt6328",
  "files_changed": [
    "drivers/regulator/mt6328-regulator.c",
    "drivers/rtc/rtc-mt6397.c",
    "drivers/mfd/mt6397-core.c",
    "include/linux/mfd/mt6328/core.h",
    "include/linux/mfd/mt6397/rtc.h"
  ],
  "compile": {
    "objects": [
      "drivers/regulator/mt6328-regulator.o",
      "drivers/rtc/rtc-mt6397.o",
      "drivers/mfd/mt6397-core.o"
    ],
    "command": "export PATH=\"$M/bin:$PATH\"; make ARCH=arm64 LLVM=1 AR=ar NM=aarch64-linux-gnu-nm OBJCOPY=aarch64-linux-gnu-objcopy OBJDUMP=aarch64-linux-gnu-objdump READELF=aarch64-linux-gnu-readelf STRIP=aarch64-linux-gnu-strip -j2 drivers/regulator/mt6328-regulator.o drivers/rtc/rtc-mt6397.o drivers/mfd/mt6397-core.o",
    "result": "all three objects compiled, no warnings/errors"
  },
  "resumed_partial_work": "Validated previous subagent's VPROC_CON11 fix, duplicate ldo_vcamio removal, VSRAM enable-register fix, VMC E1 OTP quirk and VRF18_1 SLDO_ANA_CON8 quirk against downstream pmic.c/upmu_hw.h and ROM disassembly; kept and completed them.",
  "completed": [
    "VCAMD 1.2 V trim remap (mt6328_vcamd[] map + cached factory trim, ported from mtk_regulator_set_voltage_sel/upmu_set_rg_vcamd, ROM 0xc039f8d4)",
    "VRF18_1 VOSEL mask widened 0x30->0x70 so selector 4 (1.825 V) reproduces downstream bit pattern (pmic_config_interface writes unmasked; ROM-confirmed)",
    "VMC E1 OTP voltage-table quirk completed (bounded busy-poll deviation documented)",
    "RTC write-trigger before IRQ_STA read-clear in mtk_rtc_clear_alarm (ROM hal_rtc_clear_alarm @ 0xc039e06c)",
    "RTC per-variant data/compatible validated (PROT 0x36, unlocks 0x586a/0x9136, WRTGR 0x3c; ROM rtc_writeif_unlock @ 0xc039d1a0)",
    "MT6328 IRQ enum bit-indexed (RTC=9) validated against INT_STATUS shifts and RTC_INTERRUPT_NUM",
    "Vibrator rail (ldo_vibr) validated complete vs downstream PMIC_LDO_GEN1(VIBR) and ROM DTB (3.3 V fixed, sec_vib consumer) - unchanged",
    "All 33 rails + voltage/enable tables validated against upmu_hw.h"
  ],
  "dts_fragment": "&mt6328 {\n\trtc {\n\t\tcompatible = \"mediatek,mt6328-rtc\";\n\t};\n};",
  "inferred_unverified": [
    "[INFERENCE] VRF18_1 VOSEL field is 3-bit (upmu_hw.h mask 0x3 vs downstream unmasked write reaching bit 6)",
    "VMC E1 OTP quirk, VCAMD trim remap, alarm-clear ordering, probe-time writeif unlock all hardware-unverified (no phone attached)"
  ],
  "checks_for_main": [
    "full kernel build with CONFIG_RTC_DRV_MT6397 and MT6328 regulator enabled",
    "apply the DTS fragment from logs/mt6328.md section 6 to the board DTS"
  ],
  "git_diff_check": "clean"
}