{
  "leaf": "wcn-fm",
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/wcn-fm.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/wcn-fm.md",
  "files": [
    "drivers/misc/mediatek/connectivity/fm/Makefile",
    "drivers/misc/mediatek/connectivity/fm/mtk_wcn_fm.h",
    "drivers/misc/mediatek/connectivity/fm/mtk_wcn_fm_link.c",
    "drivers/misc/mediatek/connectivity/fm/mtk_wcn_fm_chip.c",
    "drivers/misc/mediatek/connectivity/fm/mtk_wcn_fm_v4l2.c"
  ],
  "stats": {
    "insertions": 3222,
    "files": 5
  },
  "implemented": {
    "v4l2": "v4l2_device + video_device /dev/radio0; VIDIOC_QUERYCAP, G/S_TUNER (RSSI + stereo indicator, audmode), G/S_FREQUENCY, S_HW_FREQ_SEEK, subscribe/unsubscribe_event; controls V4L2_CID_AUDIO_MUTE/VOLUME, TUNE_DEEMPHASIS, RDS_RECEPTION + private BAND/ANTENNA/SOFTMUTE_GAIN/BLEND (V4L2_CID_USER_BASE+0x11f0); read()/poll() RDS record path over kfifo",
    "stp_link": "FM_TASK_INDX command framing [01][op][len][payload], event parser state machine with downstream completion bits (TUNE_DONE/SEEK_DONE/CSPI_READ/HOST_READ/RDS), 1 retry, 3/6/15s timeouts, WMTDRV_FM on/off + mtk_wcn_wmt_msgcb_reg, reset worker, rfkill",
    "chip": "MT6627 power-up/power-down, ROM/ECO/patch version, DSP patch+coeff request_firmware download, tune, seek, ramp-down, RSSI, volume, mute, RDS enable, antenna, de-emphasis, mono, soft-mute gain, blending, 861-entry channel-parameter table, TDD table"
  },
  "compile": {
    "command": "make ARCH=arm64 LLVM=1 AR=ar NM=aarch64-linux-gnu-nm OBJCOPY=aarch64-linux-gnu-objcopy OBJDUMP=aarch64-linux-gnu-objdump READELF=aarch64-linux-gnu-readelf STRIP=aarch64-linux-gnu-strip -j2 drivers/misc/mediatek/connectivity/fm/",
    "config": "cp nura.config .config; scripts/config -e MEDIA_SUPPORT -e MEDIA_RADIO_SUPPORT -e VIDEO_DEV -e RFKILL -e MTK_BTIF -e MTK_WCN_WMT -m MTK_WCN_FM; make olddefconfig",
    "result": "exit 0, zero warnings: CC [M] mtk_wcn_fm_link.o, mtk_wcn_fm_chip.o, mtk_wcn_fm_v4l2.o; LD [M] mtk_wcn_fm.o",
    "modpost_note": "mtk_wcn_fm.ko modpost cannot run without vmlinux in the worktree (all symbols, including core kernel ones, unresolved); integration must re-run after a full build",
    "checkpatch": "0 errors, 1 warning (MAINTAINERS), 3225 lines"
  },
  "deferred": [
    "RDS group decoder (PS/RT/AF/PI/PTY/ECC/CT) from core/fm_rds_parser.c; read() delivers raw 148-byte rds_rx_t records instead",
    "RDS block/group counters and BLER",
    "scan, CQI, soft-mute tune, search thresholds",
    "FM TX (no MT6627 TX ops downstream)",
    "FM over BT, GPS RTC drift, /proc/fm, customer-config and channel-param files",
    "FM audio routing to the SoC I2S/ASoC: chip-side registers programmed (0x9B=0xF9AB, host 0x80101054=0x00003F35) but no Nura MT6735 AFE/codec; required PCM/DAI documented (mt-soc-fm-i2s-pcm, mt_soc_fm_i2s_pcm node, compatible mediatek,mt_soc_pcm_fm_i2s, codec DAI mt-soc-fm-i2s-dai-codec)"
  ],
  "firmware_blobs_required": [
    "/lib/firmware/mt6627/mt6627_fm_v{1..5}_patch.bin",
    "/lib/firmware/mt6627/mt6627_fm_v{1..5}_coeff.bin",
    "same files as downstream /etc/firmware/mt6627/…; CONFIG_EXTRA_FIRMWARE_DIR=/etc/firmware also works"
  ],
  "dts_fragment": "&soc { mt_fmradio_mt6627: mt_fmradio_mt6627 { compatible = \"mediatek,mt_mt6627_fmradio\"; fmradio_ant_sel = <&pio 140 GPIO_ACTIVE_HIGH>; status = \"okay\"; }; }; (full canonical fragment + includes is in report section 6)",
  "unverified": [
    "seek (downstream helper is #if 0 and ops->bi.seek is never registered)",
    "reset recovery timing",
    "run-time de-emphasis write",
    "V4L2 signal scaling",
    "RDS record ABI zero-padding",
    "rfkill semantics (no downstream counterpart)",
    "GPIO 140 muxing"
  ],
  "checks_main_should_run": [
    "full arm64 build with MEDIA_SUPPORT=y MEDIA_RADIO_SUPPORT=y VIDEO_DEV=y RFKILL=y and MTK_WCN_FM=m, then modpost against vmlinux (verifies the mtk_wcn_stp_*/mtk_wcn_wmt_* symbols from the WMT leaf)",
    "boot on hardware: /dev/radio0 appears, open() powers the FM function and loads the vN patch/coeff blobs from the firmware path"
  ]
}