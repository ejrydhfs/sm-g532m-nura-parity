{
  "driver": "wcn-wmt (MediaTek WCN WMT/CONSYS core)",
  "worktree": "$M/worktrees/wcn-wmt",
  "patch": "$M/patches/wcn-wmt.patch",
  "report": "$M/logs/wcn-wmt.md",
  "summary": "Ported the WMT/CONSYS core end to end: STP engine (both parsers, window/ack/CRC16, 8 RX rings, callbacks), BTIF transport binding, WMT op/ctrl/function engines, SOC_CONSYS bring-up (init scripts, patch download, version tables), MT6735 CONSYS platform driver (genpd + clocks + VCN rails + EMI window + BGF IRQ + GPS LNA pinctrl), /dev/stpwmt with the full launcher ioctl ABI and firmware-patch loader, /dev/wmtWifi, and the frozen WMT_SOC.cfg parser. All 30 prototypes of the three frozen headers are implemented and EXPORT_SYMBOL_GPL'd.",
  "files_changed": 15,
  "insertions": 6532,
  "compile": {
    "config": "cp $M/nura.config .config; scripts/config -e MODULES -m MTK_BTIF -m MTK_WCN_WMT; make ARCH=arm64 LLVM=1 olddefconfig",
    "objects": [
      "stp_core",
      "stp_btif",
      "wmt_core",
      "wmt_ctrl",
      "wmt_func",
      "wmt_lib",
      "wmt_conf",
      "wmt_ic_soc",
      "consys_mt6735",
      "wmt_dev",
      "wmt_chrdev_wifi",
      "wmt_api",
      "wmt_main"
    ],
    "result": "13/13 objects compile with zero warnings/errors; module object links (LD [M] mtk_wcn_wmt.o, rc=0). modpost cannot run without vmlinux.o (no full kernel build). Only mtk_wcn_btif_{open,close,write,rx_cb_register,wakeup_consys} remain undefined, provided by the BTIF leaf per the agreed contract."
  },
  "rom_evidence": {
    "symbols": [
      "wmt_core_*",
      "wmt_lib_*",
      "mtk_wcn_soc_sw_init/ver_check/patch_dwn",
      "mtk_wcn_consys_hw_*",
      "mtk_wcn_consys_emi_virt_addr_get",
      "mtk_wcn_consys_soc_chipid",
      "mtk_wcn_stp_*",
      "mtk_wcn_wmt_*",
      "WMT_open/read/write/poll/unlocked_ioctl/close",
      "WIFI_open/write/close"
    ],
    "absent_symbols": [
      "WIFI_ioctl",
      "WMT_ioctl"
    ],
    "strings": [
      "WMT_SOC.cfg",
      "mt66xx_patch_hdr.bin",
      "stpwmt",
      "wmtWifi"
    ],
    "system_image": {
      "cfg": "WMT_SOC.cfg: coex_wmt_ant_mode=1, wmt_gps_lna_pin=0, wmt_gps_lna_enable=0, co_clock_flag=3, bt_tssi_from_wifi=1, bt_tssi_target=3664",
      "patches": [
        "ROMv2_lm_patch_1_0_hdr.bin 131812 B (hw 0x8a00 after byteswap, u4PatchVer 0x00060022)",
        "ROMv2_lm_patch_1_1_hdr.bin 68164 B"
      ]
    },
    "dts": "consys@18070000 (4 reg ranges, IRQ 227/225, conn/bus clocks, 4 vcn rails, pinctrl gps_lna_state_init/oh/ol), wifi@180f0000, btif@1100c000, 1 MiB consys-reserve-memory"
  },
  "runtime_files_userspace_must_supply": [
    "/system/etc/firmware/WMT_SOC.cfg (optional, ROM copy reproduced in report)",
    "/system/etc/firmware/ROMv2_lm_patch_1_0_hdr.bin (name+address via WMT_IOCTL_SET_PATCH_INFO seq 1)",
    "/system/etc/firmware/ROMv2_lm_patch_1_1_hdr.bin (seq 2)",
    "/lib/firmware/mt66xx_patch_hdr.bin (fallback name only)"
  ],
  "deferred": [
    "STP PSM sleep/wakeup engine (incl. BTIF dpidle control)",
    "BTM coredump / AEE / stp_dbg packet logging",
    "firmware-assert-via-EMI (recovery uses whole-chip reset instead)",
    "loopback, cmd_test, efuse, mcu-clk op, ADIE, BGW desense, IDC/LTE coex, TDM antsel",
    "EMI MPU region protection, hibernation restore cb, JTAG mux",
    "WDT_EINT 225 (unused downstream)",
    "wmtWifi 'D' debug level and P2P/AP reconfig (reset recovery via WMTMSG_RESET cb)",
    "chip-side GPS LNA (EEDI/EEDO)",
    "PORT_NAME ioctl (-EOPNOTSUPP, BTIF-only transport)",
    "coexistence keys of WMT_SOC.cfg (accepted, ignored)"
  ],
  "inferences": [
    "SPM gate/AXI protection delegated to the MT6735 CONN genpd instead of hand-written SPM writes",
    "PMIC VCN*_ON_CTRL hardware/software mode writes omitted (no pwrap API); assumes regulator SW control",
    "STP_RST implemented as STP state flush (downstream handler is empty)",
    "assert path wakes CONSYS via BTIF before the assert PDU",
    "compat ioctl mapping added because the 32-bit launcher runs on an arm64 kernel",
    "bluez delivery implemented but dormant (no frozen-API setter; BT client uses MTK mode)"
  ],
  "hardware_unverified": [
    "reset/deassert timing (150 us VCN18, 10 us before bus clock, 20 ms after reset)",
    "chip-id poll against real silicon",
    "EMI remap register effect",
    "patch fragment download against the real firmware",
    "GPS LNA pinctrl states",
    "genpd power-off actually gating CONN"
  ]
}