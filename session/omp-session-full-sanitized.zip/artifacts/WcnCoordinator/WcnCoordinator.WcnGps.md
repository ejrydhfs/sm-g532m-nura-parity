{
  "driver": "wcn-gps",
  "worktree": "$M/worktrees/wcn-gps",
  "patch": "$M/patches/wcn-gps.patch",
  "report": "$M/logs/wcn-gps.md",
  "files_changed": [
    "drivers/misc/mediatek/connectivity/gps/gps.c (new, 501 lines)",
    "drivers/misc/mediatek/connectivity/gps/Makefile (+mtk_wcn_gps-y := gps.o)"
  ],
  "implementation": {
    "gnss": "/dev/gnss0 via gnss_allocate_device/register; type GNSS_TYPE_MTK; ops.open/close/write_raw; RX is STP-only (event cb drains mtk_wcn_stp_receive_data into gnss_insert_raw, spinlock/IRQ-safe, bounded to the 16 KiB STP queue); TX is mtk_wcn_stp_send_data(GPS_TASK_INDX) with downstream -ENOSPC semantics",
    "wmt": "open: func_on(GPS) -> msgcb_reg -> stp_is_ready -> register_event_cb (downstream order), with full unwind on failure; close: unregister cb (flushes queue) -> msgcb_unreg -> func_off",
    "reset": "WMTMSG_RESET payload (WMTRSTMSG_* 0/1/2, 4-byte enum) gates open with -EPERM",
    "rfkill": "RFKILL_TYPE_GPS; block tears the STP channel down, unblock re-brings it up if the GNSS device is open; open returns -ERFKILL",
    "pm": "SYSTEM_SLEEP_PM_OPS sets the ported 'suspend' flag and sysfs_notify()s /sys/class/gnss/gnss0/suspend (RW, 0/1) exactly like gps.c:264-283",
    "teardown": "device_remove_file -> gnss_deregister_device (closes) -> rx callback barrier -> clear singleton -> rfkill unregister/destroy -> gnss_put_device"
  },
  "deferred_with_reason": {
    "ioctl 6/7/8/10/11": "GNSS ABI has no ioctl; ic_info_get/co_clock_flag_get are not in the frozen WMT header; RTC flag is a constant 0 downstream",
    "ioctl 9 D1 efuse": "raw ioremap(0x10206198) efuse read, unrelated to GPS/CONSYS, belongs to an efuse/nvmem driver",
    "ioctl 0/1": "downstream returns -EINVAL for both",
    "/dev/mtkgps loopback chardev + pwrctl/rdelay/state/pwrsave/status sysfs": "would synthesize data and, for power, is a proven hardware no-op: mt3326_gps_hw.ext_power_on/off are NULL (gps.c:164-167, never assigned anywhere) for CONSYS"
  },
  "rom_evidence": [
    "mtk_wcn_stpgps_drv_init 0xc05fa8dc / _exit 0xc05faa1c / gps_cdev_rst_cb 0xc05fa73c",
    "mt3326_gps_probe 0xc05fc8e4 (NULL-checked ext_power calls, 120-iteration delay, rdelay=50) / mt3326_gps_mod_init 0xc0db3360 -> __platform_driver_register",
    "strings: mtk_stp_GPS_chrdev(43664), stpgps(43666), gpsdrv(43699), mtkgps(43701), mediatek,mt3326-gps(6149), pwrctl/pwrsave/rdelay(43724-726)"
  ],
  "compile": {
    "config": "CONFIG_GNSS=y, CONFIG_MTK_WCN_GPS=m, CONFIG_MTK_WCN_WMT=m, CONFIG_MTK_BTIF=m, CONFIG_RFKILL=m (selected)",
    "command": "make ARCH=arm64 LLVM=1 AR=ar NM=aarch64-linux-gnu-nm OBJCOPY=aarch64-linux-gnu-objcopy OBJDUMP=aarch64-linux-gnu-objdump READELF=aarch64-linux-gnu-readelf STRIP=aarch64-linux-gnu-strip -j2 drivers/misc/mediatek/connectivity/gps/gps.o",
    "result": "CC [M] gps.o, clean; W=1 clean; checkpatch --strict -f: 0 errors 0 warnings"
  },
  "dts_fragment": "&soc { gps: gps { compatible = \"mediatek,mt3326-gps\"; status = \"okay\"; }; };  (consys node unchanged; no shared DTS edited)",
  "runtime_blobs": "none added by this driver; prerequisite is WMT's /system/etc/firmware/WMT_SOC.cfg + CONSYS ROM patch (WMT leaf), userspace opens /dev/gnss0",
  "checks_for_main": [
    "full integration build with the WMT/BTIF leaves to link mtk_wcn_gps.ko",
    "checkpatch on the applied series",
    "DTS fragment application by integration owner"
  ]
}