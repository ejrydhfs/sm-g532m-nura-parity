{
  "status": "complete",
  "worktree": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/wcn-wlan",
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/wcn-wlan.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/wcn-wlan.md",
  "files": {
    "new": [
      "drivers/misc/mediatek/connectivity/wlan/wlan_hif.h",
      "drivers/misc/mediatek/connectivity/wlan/wlan_fw.h",
      "drivers/misc/mediatek/connectivity/wlan/wlan_ahb.c",
      "drivers/misc/mediatek/connectivity/wlan/wlan_fw.c",
      "drivers/misc/mediatek/connectivity/wlan/wlan_main.c"
    ],
    "modified": [
      "drivers/misc/mediatek/connectivity/wlan/Kconfig (+select CRC32, RFKILL)",
      "drivers/misc/mediatek/connectivity/wlan/Makefile (mtk_wcn_wlan objects)"
    ]
  },
  "implemented": [
    "platform driver 'mediatek,wifi' (also 'mediatek,WIFI'): DT reg0 HIF window, reg1 AP-DMA channel, IRQ 226, clk 'wifi-dma'; no hardcoded ioremaps",
    "HIF register/PIO engine + HSTCR burst/target programming + WHLPCR INT_EN save/restore",
    "AP-DMA (PDMA) engine: config/start/poll/ack/stop/clock, warm+hard reset, 5 s timeout with register dump",
    "HIF ISR (mask + defer) and bottom half reading WHISR, draining RX0/RX1 (CFG_RX_MAX_PKT_SIZE buffer, 8-frame IST bound), logging TX/abnormal status, re-enabling",
    "driver-own acquisition (2000 ms, 1 ms steps, CLR every 256)",
    "firmware bring-up: request_firmware 'WIFI_RAM_CODE_<chip>' (6735/SOC fallback), MTKW header + CRC32 validation, divided-section and flat download with per-chunk CRC/ACK, INIT_CMD_WIFI_START with section-0 override, WCIR.WLAN_READY 512x10 ms polling, WHISR/WHCR restore, interrupt enable",
    "WMT WLAN callback registration (probe/remove/bus counters) from platform probe; probe idempotent and re-runnable after chip reset",
    "WMT reset msgcb with START quiesce and deferred END recovery via mtk_wcn_wmt_func_on(WIFI)",
    "rfkill 'mtk-wlan' gating WMT WIFI function; device link to 'mediatek,mt6735-consys' when present; suspend/resume mask-restore",
    "complete teardown ordering (msgcb unreg, cancel reset work, func_off, wlan unreg, rfkill destroy, IRQ/free, work cancel)",
    "exported symbols: only mtk_wcn_wlan_gen2_init/exit; undefined non-core symbols are exactly the frozen WMT API"
  ],
  "deferred": [
    "gen2 802.11 MAC/mgmt engine (nic/, mgmt/, cfg80211/wext/P2P) - no wiphy/netdev registered; RX drained and counted",
    "firmware power-off handshake (CMD_NIC_POWER_CTRL/FW-own) - needs the command path",
    "EMI MPU region-12 config for the 512 KiB EMI window (no emi_mpu driver in Nura)",
    "mtk_wcn_consys_hw_wifi_paldo_ctrl (frozen CONSYS API has no equivalent; WMT/regulator owns VCN33_WIFI)",
    "GDMA engine and CONF_HIF_DMA_INT interrupt-driven PDMA (downstream polls, PDMA path used)",
    "HIF_DEV_MISC chardev / loopback test / full debug dumps"
  ],
  "compile_test": {
    "config": "cp $M/nura.config .config; ./scripts/config -m MTK_BTIF -m MTK_WCN_WMT -m MTK_WCN_WLAN -e CRC32; make ARCH=arm64 LLVM=1 olddefconfig",
    "symbols": "CONFIG_MTK_WCN_WLAN=m (selects CRC32, RFKILL=m)",
    "result": "wlan_ahb.o, wlan_fw.o, wlan_main.o each compiled clean (no warnings), twice: with CONFIG_RFKILL unset and enabled; final link stops only at modpost due to missing vmlinux.o, with exactly the 7 mtk_wcn_wmt_* + mtk_wcn_wmt_assert symbols undefined",
    "checkpatch": "0 errors, 0 warnings, 0 checks on all five files"
  },
  "dts_fragment": "wifi@180f0000: compatible 'mediatek,wifi'; reg = <0x180f0000 0x0100>, <0x11000080 0x0080> (second entry for AP-DMA channel 1; optional, PIO fallback); interrupts = <GIC_SPI 226 IRQ_TYPE_LEVEL_LOW>; clocks = <&pericfg CLK_PERI_APDMA>; clock-names = 'wifi-dma'; status = 'okay'. No GPIO/regulator/reset properties.",
  "firmware_blobs": [
    "/etc/firmware/WIFI_RAM_CODE_6735 -> request_firmware('WIFI_RAM_CODE_6735') via the kernel firmware search path",
    "/etc/firmware/wifi_fw.cfg (only the deferred 802.11 stack reads it)"
  ],
  "unverified": [
    "driver-own success condition (WHLPCR bit 8) [INFERENCE]",
    "second DT reg for AP-DMA (downstream hardcodes 0x11000080) [INFERENCE]",
    "suspend/resume masking [INFERENCE]",
    "100 ms deferral before mtk_wcn_wmt_assert [INFERENCE]",
    "DOWNLOAD_BUF_ENCRYPTION_MODE on a possibly plaintext blob [UNVERIFIED]",
    "actual WCIR chip id and ACK EID/seq on hardware [UNVERIFIED]"
  ],
  "notes": "Scaffold was snapshotted in the index; final diff contains only this leaf's changes (1809 insertions over 7 files). No shared headers, DTS, or other worktrees touched; other leaves' drivers untouched."
}