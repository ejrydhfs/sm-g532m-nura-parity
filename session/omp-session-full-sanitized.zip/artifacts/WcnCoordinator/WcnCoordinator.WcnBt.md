{
  "task": "wcn-bt",
  "worktree": "$M/worktrees/wcn-bt",
  "patch": "$M/patches/wcn-bt.patch",
  "report": "$M/logs/wcn-bt.md",
  "patch_stat": "8 files, 2988 insertions; git apply --stat and reverse-check pass",
  "files_changed": [
    "drivers/misc/mediatek/btif/Makefile (object lines only)",
    "drivers/misc/mediatek/btif/btif_regs.h (new)",
    "drivers/misc/mediatek/btif/btif_core.h (new)",
    "drivers/misc/mediatek/btif/btif_hw.c (new)",
    "drivers/misc/mediatek/btif/btif_dma.c (new)",
    "drivers/misc/mediatek/btif/btif_core.c (new)",
    "drivers/misc/mediatek/connectivity/bt/Makefile",
    "drivers/misc/mediatek/connectivity/bt/mtk_wcn_bt.c (new)"
  ],
  "frozen_api": "all 10 mtk_btif.h entry points implemented and EXPORT_SYMBOL_GPL; frozen headers/Kconfigs untouched (verified with git diff)",
  "btif_implemented": [
    "platform driver mediatek,btif: 3 reg windows (BTIF 0x1100c000, APDMA TX 0x11000880, RX 0x11000900), IRQs 90/113/114, btifc+apdmac clocks, 32-bit DMA mask",
    "single-owner/channel model (id = owner pointer, E_BTIF_ALREADY_OPEN)",
    "BTIF init sequence ROM-confirmed (hal_btif_hw_init @0xc06055c0): FAKELCR=0, handshake, FIFO flush, tri lvl 8/1, PIO default, auto-reset, RX IER on",
    "PIO TX 4K kfifo + TX-empty IRQ; DMA TX/RX 8 KiB APDMA vFIFO rings with WPT/RPT wrap handling and sub-8-byte flush",
    "BTIF ISR + TX/RX DMA ISRs; RX staging 64K ring + btif_rxd kthread (360 ms poll) delivering via registered rx callback",
    "ON/DPIDLE/SUSPEND state machine (5 s TX drain, ROM c05fd5d8), wakeup_consys 64-96us WAK pulse (ROM c0605ac8), loopback, dbg_ctrl (logger/rt log/reg dump), parser_wmt_evt, platform suspend/resume",
    "mtk_wcn_btif_read implemented as a real ring drain (ROM/downstream were a stub returning 0; documented deviation)"
  ],
  "bt_hci_implemented": [
    "hci_alloc_dev/hci_register_dev (HCI_VIRTUAL), open/close/send",
    "open = mtk_wcn_wmt_func_on(WMTDRV_BT) -> stp_is_ready -> register_event_cb(BT_TASK_INDX) -> msgcb_reg(WMTDRV_BT); close reverses",
    "TX H4 type byte + stp_send_data with 10x5ms retry; RX event cb -> stp_receive_data -> H4 demux -> hci_recv_frame",
    "whole-chip reset CB defers to work: refuses TX, flushes parser, injects HCI Hardware Error 04 10 01 00 (downstream stp_chrdev_bt.c:105)",
    "rfkill provided by hci_register_dev (core allocates/registers it); no duplicate driver rfkill",
    "no /dev/stpbt by design"
  ],
  "compile": {
    "config": "CONFIG_BT=y CONFIG_MTK_BTIF=m CONFIG_MTK_WCN_WMT=m CONFIG_MTK_WCN_BT=m (local .config only)",
    "cmd": "make ARCH=arm64 LLVM=1 AR=ar NM=aarch64-linux-gnu-nm OBJCOPY=aarch64-linux-gnu-objcopy OBJDUMP=aarch64-linux-gnu-objdump READELF=aarch64-linux-gnu-readelf STRIP=aarch64-linux-gnu-strip -j2 drivers/misc/mediatek/btif/btif_core.o drivers/misc/mediatek/btif/btif_hw.o drivers/misc/mediatek/btif/btif_dma.o drivers/misc/mediatek/connectivity/bt/mtk_wcn_bt.o",
    "result": "all four CC [M] objects build clean; W=1 clean; checkpatch 0 errors/0 warnings on all six new files",
    "note": ".ko link stops in modpost only because vmlinux.o is absent in a per-object build tree (expected)"
  },
  "rom_evidence": [
    "hal_btif_hw_init 0xc06055c0, hal_btif_raise_wak_sig 0xc0605ac8, hal_btif_dma_hw_init 0xc0603b24, _btif_enter_dpidle_from_on 0xc05fd5d8, btif_rx_thread 0xc05fe148 (360 ms), mtk_wcn_btif_open 0xc060231c, mtk_wcn_btif_read 0xc0602860 (stub)",
    "ROM strings /system/etc/firmware/ and WMT_SOC.cfg at vmlinux.strings:39659-39660"
  ],
  "dts": "no shared DTS edited; canonical btif@1100c000 fragment (3 regs, IRQs 90/113/114, btifc+apdmac) reproduced in report DTS-FRAGMENT",
  "inferences": [
    "BTIF IRQ unmasked when either direction is PIO (downstream only in RX PIO setup)",
    "32-bit APDMA DMA mask from GFP_DMA32 usage",
    "rx callback return convention (0 = whole chunk consumed, preserves downstream STP behaviour)",
    "H4 type-prefixed framing over the STP BT channel",
    "64-iteration ISR/DMA drain safety caps"
  ],
  "deferred": [
    "/dev/btif debug char device (downstream BTIF_CDEV_SUPPORT)",
    "restore_noirq IRQ retype (DT trigger survives resume)",
    "WCP deep-idle notification (downstream no-op)",
    "mtk_wcn_stp_set_bluez(0) (not in frozen STP API; STP must stay MTK/non-bluez)",
    "/dev/stpbt ABI (replaced by HCI per assignment)",
    "deep-idle stress, loopback and PIO-fallback soak (no hardware)"
  ],
  "firmware": "No blobs added or referenced by this driver. BT patch download is WMT's job during mtk_wcn_wmt_func_on(WMTDRV_BT); userspace supplies the patch path via the WMT launcher ioctl (downstream WMT_IOCTL_SET_PATCH_NAME, wmt_dev.c:73,1886), default /system/etc/firmware/WMT_SOC.cfg, prefix /system/etc/firmware/.",
  "coordinator_notes": [
    "Main should run the full arm64 build with the integration DTS fragment applied and the WMT leaf present (BT module references mtk_wcn_wmt_*/mtk_wcn_stp_* exports).",
    "WMT leaf notified of BTIF API semantics and the non-bluez STP mode requirement."
  ]
}