{
  "status": "complete",
  "driver": "bma254",
  "worktree": "$M/worktrees/bma254",
  "files_changed": [
    "drivers/iio/accel/bmc150-accel-core.c",
    "drivers/iio/accel/bmc150-accel.h"
  ],
  "resumed_partial_work": "validated previous agent's edits (chip ID retries, default BW, latch/slope defaults, calibbias plumbing, IRQ wake, suspend); fixed calibbias sign convention to Samsung 'value = acc - caldata' semantics and changed suspend to enter low-power mode (PMU_LPW mode bits 2 = downstream BMA2X2_MODE_LOWPOWER1) when any-motion armed",
  "parity_items_done": [
    "chip ID retry x5 + table lookup (0xFA BMA254)",
    "range table validated (3/5/8/12)",
    "bandwidth/ODR table validated (PMU_BW 0x08-0x0F), BMA254 default ODR 250 Hz = PMU_BW 0x0c",
    "calibration offsets via in_accel_{x,y,z}_calibbias (regs 0x38-0x3A)",
    "mount matrix (driver complete; corrected DTS fragment provided)",
    "IRQ config: slope->INT1 map, rising edge, 250 ms latch 0x21=0x01, irq_wake on any-motion arm/disarm",
    "suspend/resume: LPM when wake-armed else suspend; resume -> normal",
    "ACPI/OF bosch,bma254 preserved"
  ],
  "compile": {
    "command": "cp $M/nura.config .config && make ARCH=arm64 LLVM=1 olddefconfig && make ARCH=arm64 LLVM=1 AR=ar NM=aarch64-linux-gnu-nm OBJCOPY=aarch64-linux-gnu-objcopy OBJDUMP=aarch64-linux-gnu-objdump READELF=aarch64-linux-gnu-readelf STRIP=aarch64-linux-gnu-strip -j2 drivers/iio/accel/bmc150-accel-core.o drivers/iio/accel/bmc150-accel-i2c.o",
    "result": "exit 0, CC [M] bmc150-accel-core.o and bmc150-accel-i2c.o clean, no warnings; bmc150-accel-spi.o (header consumer) also rebuilt clean"
  },
  "patch": "$M/patches/bma254.patch (git diff --binary, 2 files +210/-24, matches tree, git diff --check clean)",
  "report": "$M/logs/bma254.md",
  "dts_fragment_in_report": true,
  "hardware_unverified": [
    "offset register LSB size 1/128 g [INFERENCE] - no downstream/ROM evidence (Samsung calibrates in software)",
    "slope threshold 5/duration 1 applied at probe vs downstream applying at arm time",
    "LPM suspend wake latency (register value matches downstream LOWPOWER1 exactly)",
    "slope X|Y|Z enable superset vs downstream slope-Z-only",
    "wake-on-motion end-to-end incl. userspace wakeup source (downstream bma2x2 has no wake lock)",
    "INT pin polarity (INT_OUT_CTRL unprogrammed in both drivers)"
  ],
  "main_agent_checks": [
    "git diff --check",
    "review $M/patches/bma254.patch",
    "optional: rebuild the two objects to reconfirm"
  ]
}