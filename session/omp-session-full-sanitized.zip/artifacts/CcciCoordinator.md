{
  "compile": {
    "dirs": "five built-in.a rc=0",
    "objects": "19/19 rc=0, no warnings",
    "symbol_audit": "no unresolved/duplicate subsystem symbols",
    "vmlinux": "full link rc=0 on final sources; CCCI symbols present"
  },
  "dts": {
    "modified": false,
    "validated": "MD1 and MD3 fragments compiled into DTBs with scripts/dtc: exit 0, no warning from the added nodes (pre-existing mt6735.dtsi interrupt-controller warning only)",
    "final_shape": "&{/soc} overlay (no soc label in Nura dtsi), 4-cell <0 ADDR 0 SIZE> regs, lowercase node unit addresses (mdcldma@1000a000, ccif@10218000)"
  },
  "integrated_patch": "$M/patches/ccci-integration.patch (41 files, +14644, applies cleanly to HEAD)",
  "leaf_patches": [
    "$M/patches/ccci-eccci.patch",
    "$M/patches/ccci-cldma.patch",
    "$M/patches/ccci-util.patch",
    "$M/patches/ccmni.patch (alias ccci-ccmni.patch)",
    "$M/patches/ccci-c2k.patch"
  ],
  "reports": [
    "$M/logs/ccci-coordinator.md",
    "$M/logs/ccci-eccci.md",
    "$M/logs/ccci-cldma.md",
    "$M/logs/ccci-util.md",
    "$M/logs/ccmni.md",
    "$M/logs/ccci-c2k.md"
  ],
  "status": "complete",
  "subsystem": "CCCI modem (SM-G532M MT6737T ROM 3.18 -> Nura v7.0.10 arm64)",
  "summary": "Five drivers (core+CCIF+loader, CLDMA, util, CCMNI, C2K/MD3) recreated as modern arm64 code, merged with conflicts resolved, Kconfig-wired, compiled and linked. Deferred items and hardware-unverified details are enumerated in the coordinator report."
}