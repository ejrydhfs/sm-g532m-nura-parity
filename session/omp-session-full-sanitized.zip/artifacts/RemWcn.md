{
  "status": "complete",
  "area": "WCN (WMT/WLAN/FM)",
  "coordinator_report": "$M/logs/rem-wcn-coordinator.md",
  "deliverables": {
    "patches": [
      "$M/patches/rem-baseline-hooks.patch (2 lines: missing drivers/misc/Kconfig source + Makefile descent in parity-baseline-all — fold into the shared baseline; affects every area)",
      "$M/patches/rem-wcn-wmt.patch (20 files, +4674/-30)",
      "$M/patches/rem-wcn-wlan.patch (12 files, +3822/-26)",
      "$M/patches/rem-wcn-fm-i2s.patch (10 files, +1484/-6)",
      "$M/patches/rem-wcn-fm-i2s-audio.patch (7 files, +564/-13, sound/soc only)",
      "$M/patches/rem-wcn-integration.patch (all four combined, 49 files, +10544/-75, 0 binary hunks, reverse-applies to the integration tree)"
    ],
    "reports": [
      "$M/logs/rem-wcn-wmt.md",
      "$M/logs/rem-wcn-wlan.md",
      "$M/logs/rem-wcn-fm-i2s.md",
      "$M/logs/rem-wcn-fm-i2s-audio.md",
      "$M/logs/rem-wcn-coordinator.md"
    ],
    "context": "$M/REM_WCN_CONTEXT.md"
  },
  "worktrees": {
    "integration": "$M/worktrees/rem-wcn-integration (baseline + 2 hook fixup commits + all four patches, clean build)",
    "leaves": [
      "$M/worktrees/rem-wcn-wmt",
      "$M/worktrees/rem-wcn-wlan",
      "$M/worktrees/rem-wcn-fm-i2s",
      "$M/worktrees/rem-wcn-fm-i2s-audio"
    ]
  },
  "integration_verification": {
    "apply": "all four patches applied with git apply, no conflicts (file-disjoint: 49 files = exact union)",
    "config": "nura.config + scripts/config (… -e SOUND -e SND -e SND_SOC -m SND_SOC_MT6735 -m SND_SOC_MT6735_MT6331 -m SND_SOC_MT6331)",
    "clean_rebuild": "43x CC [M], 7x LD [M] (mtk_btif, mtk_wcn_wmt, mtk_wcn_wlan, mtk_wcn_fm, mtk_wcn_gps, snd-soc-mt6735-afe, snd-soc-mt6735-mt6331; mtk_wcn_bt is single-object), 0 warnings, 0 errors, W=1, log $M/logs/rem-wcn-integration_final.log",
    "gps_unblock": "baseline gps/stp_chrdev_gps.c implicit-declaration errors disappear once rem-wcn-wmt provides mtk_wcn_wmt_ic_info_get/mtk_wcn_wmt_co_clock_flag_get",
    "fm_n_guard": "machine card object contains FM strings with MTK_WCN_FM=m and none with it unset; base links retained; both W=1 clean (log rem-wcn-integration_fm_n.log)",
    "userspace": "fm_i2s --selftest PASS (37 checks), stp_dbg --selftest all 10 checks, fm_rds_decode (pre-existing) all checks"
  },
  "independent_cross_checks": [
    "AFE FM routes re-derived from mt_soc_afe_connection.c: exactly four routes (GAIN1_CONN2 bits 2/16, GAIN1_CONN bits 8/10); rejected an invented six-route revision",
    "ASRC bypass polarity AFE_CONN4 bit 30 = 1 per mt_soc_afe_control.c:2273-2274",
    "ROM fm_i2s_set @0xc063a59c is a low_ops dispatcher; fm_get_i2s_info @0xc0638e90",
    "PSM/coex/coredump ROM symbols and strings (PSM_SLEEP/HOST_AWAKE/MONITOR/EXIT, STP_DBG, BGW_DESENSE_EVT) match the ported names",
    "STP_DBG netlink numbering identical to downstream stp_dbg.c:84-100",
    "WMT feature reachability: psm/btm init from stp_core.c:1257-1282, psm from TX/RX paths, coredump from FW-assert path, wmt_coex_init from wmt_lib.c:170"
  ],
  "closed": [
    "WLAN cfg80211 station (2.4 GHz), software scan, open connect/disconnect with real firmware CMD_BSS_ACTIVATE_CTRL/UPDATE_STA_RECORD/SET_BSS_INFO sequencing and sequence-matched completion events, 802.3 data TX with real STA index, 802.11 RX conversion, get_station RCPI, lifecycle",
    "WMT PSM state machine, firmware coredump + STP_DBG netlink daemon ABI, BGW desense + LTE IDC with -ENODEV degradation, userspace stp_dbg",
    "FM I2S chip control + codec component (no competing card) + both ioctls, userspace fm_i2s",
    "FM I2S AFE DAI + single machine link on mt-snd-card with IS_ENABLED(CONFIG_MTK_WCN_FM) guard and AFE_I2S_CON 0x0018 -EBUSY exclusivity vs I2S0"
  ],
  "deferred_with_exact_missing_input": [
    "WLAN per-channel scan retune: needs CMD_ID_SCAN_REQ + scan FSM (mgmt/scan_fsm.c:377-455)",
    "WLAN multicast/promiscuous filter: no HIF filter register; needs firmware OID command path",
    "WLAN get_station rate: HIF RX header has no rate, downstream uses wlanoidQueryStaStatistics",
    "WLAN WoWLAN/MAC suspend: no WoWLAN firmware interface in this port",
    "FM ASRC 32k->44.1/48k: needs documented AFE_ASRC_CON13/14/15/16/17/20 writes (AudfDrv_Afe.h:675-682)",
    "FM vs voice arbitration: voice can start during FM and reprogram shared PMIC DAC; userspace must stop FM first"
  ],
  "blocked": "none",
  "dts": "none required; no shared .dts/.dtsi modified"
}