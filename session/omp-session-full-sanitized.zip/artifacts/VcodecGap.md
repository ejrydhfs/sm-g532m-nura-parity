{
  "subsystem": "vcodec (MT6735 VDEC + VENC + shared /dev/Vcodec core)",
  "coordinator_report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/vcodec-gap-coordinator.md",
  "baseline": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/vcodec-integration.patch",
  "combined_gap_patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/vcodec-gap-integration.patch",
  "combined_stats": "5 files, +768/-44 on top of the baseline; verified to apply cleanly on a pristine baseline-applied tree and to reproduce the integration files byte-for-byte",
  "leaves": [
    {
      "leaf": "mmdvfs-dvfs",
      "worktree": "worktrees/vcodec-gap-dvfs",
      "patch": "patches/vcodec-gap-dvfs.patch",
      "report": "logs/vcodec-gap-dvfs.md",
      "status": "closed: VDEC clock steps 273/136.5 MHz via clk_set_parent on TOP_VDEC_SEL (syspll1_d2/syspll1_d4) and full VdecDvfs monitor (4 s window, 50%/90%, 1 ms overhead) wired through new optional engine ops at INC_DEC_EMI_USER / post-LOCKHW / post-UNLOCKHW / last close; blocked: MMDVFS SMI-bandwidth+VCORE vote (no MMDVFS/vcorefs/SMI-BWC framework in Nura; ROM mmdvfs_set_step 0xc04cacdc, downstream mmdvfs_mgr.c:233-301); VENC DVFS proven not applicable"
    },
    {
      "leaf": "hibernation",
      "worktree": "worktrees/vcodec-gap-hibernation",
      "patch": "patches/vcodec-gap-hibernation.patch",
      "report": "logs/vcodec-gap-hibernation.md",
      "status": "closed: dev_pm_ops .restore_noirq on both engines calls irq_set_irq_type(irq, IRQ_TYPE_LEVEL_LOW), matching ROM vcodec_pm_restore_noirq @0xc0396198 and D1:2376-2386; sysirq set_type verified non-sleeping; mask state intentionally untouched"
    },
    {
      "leaf": "cpu-opp-limit",
      "worktree": "worktrees/vcodec-gap-cpuopp",
      "patch": "patches/vcodec-gap-cpuopp.patch",
      "report": "logs/vcodec-gap-cpuopp.md",
      "status": "closed: VCODEC_SET_CPU_OPP_LIMIT implemented with FREQ_QOS_MAX on each cpufreq policy (freq_qos add/update/remove), mask semantics [INFERENCE] (32-bit CPU mask, 0=all), replace-on-re-enable, release at last close and module exit, -EOPNOTSUPP with CPU_FREQ=n; ROM's cpu_opp_limit call is commented out and the helper exists nowhere"
    },
    {
      "leaf": "remaining-commands",
      "worktree": "worktrees/vcodec-gap-commands",
      "patch": "patches/vcodec-gap-commands.patch",
      "report": "logs/vcodec-gap-commands.md",
      "status": "closed: compat ioctl default now returns -EOPNOTSUPP for known-but-unsupported commands (matches native path); SYSRAM/pmem/ion + 11 total commands closed as 'no ROM service' (ROM jump-table disassembly of vcodec_unlocked_ioctl @0xc03974fc; ROM SYSRAM belongs to camera_sysram); blocked: ALLOC/FREE_NON_CACHE_BUFFER (ROM refuses them, D2/D3 semantics have no userspace mapping contract)"
    }
  ],
  "integration": {
    "worktree": "worktrees/vcodec-gap-integration",
    "conflicts": "one: include block of vcodec-vdec.c (ktime.h vs irq.h), resolved by keeping both; no semantic hunk conflicted",
    "coordinator_fix": "DT binding updated to the implemented clock contract (6 clocks, underscore clock-names, vdec clock-names required, matching example)"
  },
  "verification": {
    "build_env": "PATH=$M/llvmpkg/usr/bin:$M/bin; ARCH=arm64 LLVM=1; nura.config + olddefconfig + CONFIG_MTK_VCODEC_MT6735=m",
    "objects_w1": "vcodec-core.o, vcodec-vdec.o, vcodec-venc.o exit 0, 0 warnings",
    "module_link": "LD [M] vcodec-mt6735.o exit 0",
    "config_variants": "CONFIG_COMPAT=n (3 objects) exit 0; CONFIG_CPU_FREQ=n (core) exit 0",
    "checkpatch": "0 errors / 0 warnings / 0 checks on all 5 sources",
    "log": "logs/vcodec-gap-integration-build.log",
    "not_run": "full kernel build / .ko modpost (no vmlinux.o/Module.symvers in this worktree), dt_binding_check (dtschema absent), hardware probes"
  },
  "dts": "fragment only, in the coordinator report section 6: vdec node with 6 clocks/names (smi_common, vdec, smi_larb1, vdec_sel, vdec_sel_high, vdec_sel_low) and the unchanged venc node; no shared DTS file was edited",
  "deviations": [
    "CPU OPP ceiling released at last close/module exit and replaced on re-enable (ROM never applied anything)",
    "limited_cpu is a 32-bit mask, so CPUs >= 32 only covered by mask 0",
    "refused commands keep -EOPNOTSUPP/-ENOTTY instead of the ROM's unconditional 255",
    "DVFS steps skipped when DT does not describe the mux and both parents",
    "pre-existing Nura topckgen rate model reports syspll1_d2/d4 at 2x the vendor rates although mux positions are correct; documented as a shared-clock-driver follow-up"
  ],
  "userspace_only_gaps": "none; no userspace patch was needed for this subsystem"
}