{
  "subsystem": "camera",
  "status": "complete-with-documented-deferrals",
  "worktrees": {
    "camera-imgsys": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/camera-imgsys",
    "camera-seninf": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/camera-seninf",
    "camera-imx219": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/camera-imx219",
    "camera-s5k5e3yx": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/camera-s5k5e3yx",
    "camera-lens-cal": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/camera-lens-cal",
    "camera-integration": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/worktrees/camera-integration"
  },
  "patches": {
    "camera-imgsys": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/camera-imgsys.patch",
    "camera-seninf": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/camera-seninf.patch",
    "camera-imx219": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/camera-imx219.patch",
    "camera-s5k5e3yx": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/camera-s5k5e3yx.patch",
    "camera-lens-cal": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/camera-lens-cal.patch",
    "combined": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/camera-subsystem.patch"
  },
  "reports": {
    "coordinator": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-coordinator.md",
    "leaves": [
      "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-imgsys.md",
      "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-seninf.md",
      "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-imx219.md",
      "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-s5k5e3yx.md",
      "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-lens-cal.md"
    ]
  },
  "compiled": {
    "integration_objects": [
      "drivers/media/platform/mediatek/imgsys/mtk-imgsys.o",
      "drivers/media/platform/mediatek/seninf/mtk-seninf.o",
      "drivers/media/i2c/imx219.o",
      "drivers/media/i2c/s5k5e3yx.o",
      "drivers/media/i2c/dw9807-vcm.o",
      "drivers/media/i2c/imx219-eeprom.o"
    ],
    "directory_targets": [
      "drivers/media/platform/mediatek/imgsys/built-in.a",
      "drivers/media/platform/mediatek/seninf/built-in.a"
    ],
    "result": "exit 0; 0 warnings/0 errors on the normal pass and on a W=1 pass",
    "logs": [
      "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-integration-build.log",
      "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/camera-integration-w1.log"
    ]
  },
  "conflicts": [
    {
      "files": [
        "drivers/media/platform/mediatek/Kconfig",
        "drivers/media/platform/mediatek/Makefile"
      ],
      "cause": "camera-imgsys and camera-seninf both append to the same trailing hunk",
      "resolution": "applied seninf patch excluding the two parent files, then appended source \".../seninf/Kconfig\" and obj-y += seninf/ after the imgsys entries; final tree verified by olddefconfig accepting both options"
    }
  ],
  "drivers": {
    "mtk-imgsys": {
      "status": "platform driver complete for documented hardware; ISP pipeline deferred",
      "parity": "7 done / 0 partial / 8 deferred",
      "key_deferred": [
        "SMI/DMA clock",
        "Pass-2/CAMSV resets",
        "ISP/CAMSV interrupts (no documented enable/clear register)",
        "Pass1/Pass2/DSP/CQ/DMA pipeline requiring libcamdrv + ISP firmware",
        "V4L2 entity (by design)"
      ]
    },
    "mtk-seninf": {
      "status": "complete platform/media driver; D-PHY programming deferred",
      "parity": "14 done / 0 partial / 4 deferred",
      "key_deferred": [
        "MIPI D-PHY/lane/settle register programming (table only in proprietary seninf_drv; zero SENINF symbols in ROM kernel)",
        "runtime MCLK rate/parent control (DT-driven camtg)",
        "legacy /dev/camera_hw ABI",
        "ISP pipeline link"
      ]
    },
    "imx219": {
      "status": "Samsung variant complete; generic sony,imx219 path byte-identical",
      "parity": "16 done / 4 partial / 4 deferred",
      "key_deferred": [
        "sensor-side MIPI settle",
        "EEPROM/AF (separate drivers)",
        "ISP pipeline"
      ],
      "partial": [
        "exposure auto-frame-extension",
        "analogue gain raw units vs downstream ISP gain table",
        "test-pattern window size",
        "reset/powerdown share GPIO44 on this board"
      ]
    },
    "s5k5e3yx": {
      "status": "full new driver complete",
      "parity": "25 done / 0 partial / 5 deferred",
      "key_deferred": [
        "digital gain (absent downstream)",
        "hflip/vflip (#if 0 downstream)",
        "OTP/lens-shading NVM pages (MTK HAL ABI)",
        "scenario frame delays (AE/ISP)",
        "85 ns LP->HS settle (SENINF-side)"
      ]
    },
    "lens-cal": {
      "status": "DW9807 + EEPROM nvmem complete",
      "parity": "19 done / 0 partial / 2 deferred",
      "key_deferred": [
        "legacy read_imx219_eeprom_mtk_fmt block (different slave; mt6735m variant only)",
        "Samsung firmware string policy checks"
      ]
    }
  },
  "cross_driver_contract": {
    "media_device": "single, owned by mtk-seninf",
    "mclk_provider": "mtk-seninf #clock-cells=<1>, mclk0..mclk2 toggling documented ISP_MCLKn_EN bit 29; camtg is the CCF parent",
    "sensor_clocks": "imx219 clocks=<&seninf 0>; s5k5e3yx clocks=<&seninf 1>",
    "i2c_addresses_7bit": {
      "imx219": "0x1a",
      "s5k5e3yx": "0x10 (alt 0x36)",
      "dw9807": "0x0c",
      "eeprom": "0x58"
    },
    "endpoint_labels": {
      "port0": "seninf_in0 <-> imx219_out",
      "port1": "seninf_in1 <-> s5k5e3yx_out"
    }
  },
  "integration_fixes": [
    "DW9807 ring-control mode gated by OF match data so dongwoon users keep upstream 0x02=0x00",
    "SENINF MCLK now takes a runtime-PM reference in clk prepare so probe-time sensor power_on gets MCLK; SENINF RPM no longer touches camtg (avoids prepare_lock re-entrancy)",
    "SENINF report aligned to delivered vcam* supply names and active-high reset; pinctrl dedup rule added",
    "pinctrl dedup: keep SENINF camera_pins_default, drop sensor-local states in the merged DTS"
  ],
  "config_requirement": "board defconfig must enable MEDIA_SUPPORT with MEDIA_SUPPORT_FILTER disabled (or MEDIA_CAMERA_SUPPORT=y) plus VIDEO_DEV, VIDEO_V4L2_SUBDEV_API, V4L2_FWNODE, V4L2_ASYNC, VIDEO_CAMERA_SENSOR, VIDEO_MTK_IMGSYS, VIDEO_MTK_SENINF, VIDEO_IMX219, VIDEO_S5K5E3YX, VIDEO_DW9807_VCM, VIDEO_IMX219_EEPROM, NVMEM",
  "dts": "none modified; consolidated fragment and dedup rule in logs/camera-coordinator.md section 8",
  "unresolved_gaps": [
    "MIPI D-PHY/SENINF lane+settle programming unavailable (proprietary seninf_drv only) so sensor->SENINF streaming is not end-to-end functional",
    "ISP capture/Pipeline requires libcamdrv + firmware and is deferred",
    "ISP interrupts intentionally not enabled (no documented enable/clear register)",
    "hardware-only unknowns: MCLK clear semantics, MIPI error W1C convention, derived link frequencies, shared-LDO coupling, sensor reset/powerdown being one pin"
  ]
}