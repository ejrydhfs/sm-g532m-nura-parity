{
  "summary": "MT6735/MT6737T pinctrl parity: register-range, pull-type and EINT-count fixes from ROM arrays; compile-tested.",
  "files_changed": [
    "drivers/pinctrl/mediatek/pinctrl-mt6735.c"
  ],
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/pinctrl.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/pinctrl.md",
  "compile": "make ARCH=arm64 LLVM=1 ... drivers/pinctrl/mediatek/pinctrl-mt6735.o -> success (CC, no warnings)",
  "pin_table": "No pins/functions missing: all 204 ROM pins (mtk_pins_mt6735 @0xc0a5d2f4) match the header names/mux values; only GPIO61 name PCM1_CLK vs ROM PCM1_CLK[0].",
  "changes": [
    "IES/SMT: add GPIO42-44; fix GPIO163-165 iocfg3->iocfg4",
    "TDSEL: add GPIO42-44",
    "RDSEL: add GPIO42-44; fix bits for GPIO137-149; move GPIO186-189 to 0xD2C",
    "DRV: regenerate all bit offsets from ROM DRV_addr/offset/width; add GPIO47-54 1-bit fields; drop GPIO103",
    "R0/R1/PUPD: fix GPIO160-165 to ROM spec_pupd bits",
    "mt6735_pull_type: add missing GPIO59 entry (was shifting all indices >=60 and causing OOB at 202/203) and entries 204-212",
    "EINT: ap_num 224 -> 213 (vendor max_eint_num)"
  ],
  "validation": "DTS refs all resolve (10 pinmux macros, GPIO 5/7/19/85/86/146/184, EINT 3/62/76). Every table re-expanded and byte-compared against ROM gpio_cfg arrays: all match; only GPIO42-44/103 remain correctly unsupported for drive.",
  "unverified": [
    "ap_num=213 inferred from vendor DTS max_eint_num + EINT==GPIO mapping",
    "drive group scaling (DRV_GRP*) not ROM-verifiable",
    "no hardware run"
  ],
  "dts_fragment": "Not applied (shared dtsi): gpio-ranges = <&pio 0 0 204>; to expose GPIO203 as in the 204-pin ROM table."
}