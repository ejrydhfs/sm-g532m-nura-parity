{
  "driver": "drivers/gpu/drm/panel/panel-samsung-s6d78a0-gh9607501a.c",
  "files_changed": [
    "drivers/gpu/drm/panel/panel-samsung-s6d78a0-gh9607501a.c"
  ],
  "files_untouched": [
    "drivers/gpu/drm/mediatek/mtk_dsi.c",
    "drivers/gpu/drm/mediatek/mtk_drm_drv.c",
    "all DTS"
  ],
  "patch": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/patches/display.patch",
  "report": "/run/media/user/00000000-0000-4000-8000-000000000000/g532m_work/logs/display.md",
  "compile": {
    "target": "drivers/gpu/drm/panel/panel-samsung-s6d78a0-gh9607501a.o",
    "command": "make ARCH=arm64 LLVM=1 AR=ar NM=aarch64-linux-gnu-nm OBJCOPY=aarch64-linux-gnu-objcopy OBJDUMP=aarch64-linux-gnu-objdump READELF=aarch64-linux-gnu-readelf STRIP=aarch64-linux-gnu-strip -j2 W=1 <object>",
    "result": "exit 0, CC [M] no warnings",
    "checkpatch": "0 errors, 0 warnings, 0 checks (--strict -f)"
  },
  "key_findings": [
    "ROM actually uses mtk_gen_panel (symbols.txt gen_panel_*, vmlinux.strings, defconfig CONFIG_CUSTOM_KERNEL_LCM=\"mtk_gen_panel\"); panel sequences/timing live in the DTB, not vmlinux strings.",
    "Extracted ROM DTB from boot.img (MTK dt image at offset 9472000/0x908800): two runtime-selected panels, 0x286108 and 0x53b810, both with full 331-byte init sequences and identical 540x960/2-lane timing.",
    "Old driver's 53b810 sequence had wrong 0xf2 (19 04 08 08 08 14 14 00 vs ROM ...3f 23 00) and 0xf6 (93 23 15 07 07 0c vs 63 23 15 00 00 0c); 286108 variant was missing entirely.",
    "Timing corrected to hfp/hbp/hsync 35/35/28 (was 10/14/10), 64x110 mm (was 62x110), clock 37361 kHz (638x976x60).",
    "Host config parity: removed MIPI_DSI_CLOCK_NON_CONTINUOUS (ROM cont_clock=1) and MIPI_DSI_MODE_NO_EOT_PACKET (ROM DIS_EOT=0); lanes 2/RGB888/sync-pulse already correct.",
    "Sleep-in/display-off delays corrected to 50 ms/50 ms (ROM DTB disable-cmds) from 40/100 ms.",
    "Reset sequence now matches lcm_init_power (15 ms asserted incl. bias window, 10/10/30 ms).",
    "Brightness: implemented KTD3102 single-wire pulse protocol and ROM brt table (0->0, 5->2, 144->16, 255->27), default 144; HBM (306->32) not exposed.",
    "Both init tables verified byte-for-byte against the ROM DTB properties programmatically."
  ],
  "hardware_unverified": [
    "DCS panel-ID read in prepare (0xda/0xdb/0xdc) with 53b810 fallback",
    "bias rail folded into reset timing; GPIO61 as vdd_lcd_3p0 enable (Nura DTS currently uses GPIO184)",
    "extra reset pulses on resume vs ROM resume_power",
    "KTD3102 pulse timing and GPIO7/69 wiring",
    "EOT enabled vs old NO_EOT setting",
    "DSI PLL rounding (448.3 Mbps vs ROM 230 MHz step)"
  ],
  "dts_fragment_in_report": true,
  "hardware_unverified_note": "DTS fragment in report section 6: remove pwm-backlight, add backlight-ctrl-gpios=<&pio 7> and backlight-en-gpios=<&pio 69>, mux pins in panel_default, change vdd_lcd_3p0 gpio 184 -> 61."
}